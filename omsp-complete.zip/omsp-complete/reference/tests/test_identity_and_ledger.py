"""Identity, sybil resistance, onboarding, kill switch, ledger audit trail."""
import unittest

from omsp import Config, OMSPPlatform
from omsp import core
from omsp.config import (AgentFrozenError, OnboardingClosedError,
                         RateLimitedError, SybilGateError)
from tests.helpers import boost_rep, make_agent, make_platform


class TestIdentity(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()

    def test_registration_metadata_and_ownership(self):
        """[REQ-1.1] NFT-style identity with resolvable metadata URI."""
        a = make_agent(self.p, "scout", capabilities=["web research"],
                       services=[{"name": "brief", "price": 5.0, "unit": "job"}])
        meta = self.p.identity.metadata_uri(a.token_id)
        self.assertEqual(meta["id"], a.token_id)
        self.assertIn("a2a", meta["endpoints"])
        self.assertIn("mcp", meta["endpoints"])
        self.assertEqual(meta["capabilities"], ["web research"])
        self.assertTrue(meta["wallet"].startswith("0x"))
        self.assertEqual(self.p.identity.owner_of(a.token_id),
                         a._owner_kp.address)
        self.assertIn("0.2", meta["protocols"])

    def test_transfer_preserves_identity_and_history(self):
        """[REQ-1.1] Portable identity: transfer keeps token id + reputation."""
        a = make_agent(self.p, "porta")
        boost_rep(self.p, a.token_id, n=5)
        before = self.p.reputation.score(a.token_id)
        new_owner = core.KeyPair.generate()
        self.p.identity.transfer(a.token_id, a._owner_kp, new_owner)
        self.assertEqual(self.p.identity.owner_of(a.token_id), new_owner.address)
        self.assertEqual(self.p.reputation.score(a.token_id), before)
        # non-owner cannot transfer
        with self.assertRaises(Exception):
            self.p.identity.transfer(a.token_id, a._owner_kp,
                                     core.KeyPair.generate())

    def test_sybil_gate_requires_stake_or_pow(self):
        """[REQ-1.4] Registration without stake and without PoW is rejected;
        a valid PoW nonce is accepted."""
        owner = core.KeyPair.generate()
        with self.assertRaises(SybilGateError):
            self.p.identity.register(owner, "freeloader", stake=0.0)
        challenge = f"omsp-register:{owner.address}:{self.p.identity._next_id}"
        nonce = core.pow_solve(challenge, self.p.config.register_pow_bits)
        a = self.p.identity.register(owner, "worker-bee", stake=0.0,
                                     pow_nonce=nonce)
        self.assertTrue(self.p.identity.exists(a.token_id))

    def test_controlled_onboarding_bootstrap(self):
        """[REQ-9.1] Bootstrap phase admits only invited owners."""
        p = OMSPPlatform(Config(onboarding_open=False))
        outsider, insider = core.KeyPair.generate(), core.KeyPair.generate()
        p.faucet(insider.address, 20)
        p.faucet(outsider.address, 20)
        with self.assertRaises(OnboardingClosedError):
            p.identity.register(outsider, "gatecrasher", stake=10)
        p.invite(insider.address)
        a = p.identity.register(insider, "founder", stake=10)
        self.assertEqual(a.name, "founder")

    def test_kya_binding_levels(self):
        """[REQ-1.5] Owner binding with KYA levels is recorded on-ledger."""
        a = make_agent(self.p, "kyc-me")
        rec = self.p.identity.bind_owner(a.token_id, a._owner_kp,
                                         org="Acme Corp", level=2)
        self.assertEqual(rec["level"], 2)
        self.assertEqual(self.p.identity.get(a.token_id).kya_level, 2)
        self.assertTrue(self.p.ledger.query("agent.kya_bound",
                                            actor=a.token_id))

    def test_kill_switch_freeze_blocks_everything(self):
        """[REQ-7.2] Frozen agents are rejected by platform operations."""
        a = make_agent(self.p, "runaway")
        b = make_agent(self.p, "peer")
        self.p.identity.freeze(a.token_id, a._owner_kp)
        with self.assertRaises(AgentFrozenError):
            self.p.a2a.create_task(a.token_id, b.token_id,
                                   {"goal": "x", "budget": 1.0, "deadline": 9.0})
        with self.assertRaises(AgentFrozenError):
            self.p.economy.x402.pay(a.token_id, self.p.economy.x402
                                    .payment_required(payee=b.token_id, amount=1))
        self.p.identity.unfreeze(a.token_id, a._owner_kp)
        task = self.p.a2a.create_task(a.token_id, b.token_id,
                                      {"goal": "x", "budget": 1.0,
                                       "deadline": 9.0})
        self.assertEqual(task["state"], "submitted")

    def test_guardian_freeze(self):
        """[REQ-7.2] Platform guardian can also trigger the kill switch."""
        a = make_agent(self.p, "risky")
        self.p.identity.freeze(a.token_id, self.p.guardian_kp, guardian=True)
        self.assertTrue(self.p.identity.get(a.token_id).frozen)

    def test_progressive_rate_limits(self):
        """[REQ-1.4][REQ-8.3] Low-rep agents exhaust their bucket sooner than
        high-rep agents; refill restores capacity."""
        low = make_agent(self.p, "newbie")
        high = make_agent(self.p, "veteran")
        boost_rep(self.p, high.token_id, n=30)
        self.assertEqual(self.p.reputation.tier(high.token_id), "high")

        def burn(agent_id):
            n = 0
            while self.p.rate.allow(agent_id):
                n += 1
                if n > 200:
                    break
            return n

        low_n, high_n = burn(low.token_id), burn(high.token_id)
        self.assertGreater(high_n, low_n)
        with self.assertRaises(RateLimitedError):
            self.p.rate.require(low.token_id)
        self.p.clock.advance(1000)
        self.assertTrue(self.p.rate.allow(low.token_id))


class TestLedger(unittest.TestCase):
    def test_chain_verifies_and_detects_tampering(self):
        """[REQ-6.1][REQ-6.4] Hash-chained commitments are tamper-evident."""
        p = make_platform()
        make_agent(p, "honest")
        ok, bad = p.ledger.verify_chain()
        self.assertTrue(ok)
        # attacker rewrites history
        p.ledger.blocks[1]["events"][0]["data"]["name"] = "forged"
        ok, bad = p.ledger.verify_chain()
        self.assertFalse(ok)
        self.assertEqual(bad, 1)

    def test_audit_trail_queryable_by_actor_and_type(self):
        """[REQ-6.4] Full audit trail: filter by event type and actor."""
        p = make_platform()
        a = make_agent(p, "auditee")
        b = make_agent(p, "other")
        evs = p.ledger.query("agent.registered", actor=a.token_id)
        self.assertEqual(len(evs), 1)
        self.assertEqual(evs[0]["data"]["name"], "auditee")
        self.assertEqual(len(p.ledger.query("agent.registered")), 2)

    def test_signatures(self):
        """Core signature scheme round-trips and rejects forgeries."""
        kp = core.KeyPair.generate()
        msg = b"omsp settlement"
        sig = core.sign(kp, msg)
        self.assertTrue(core.verify(kp.pk, msg, sig))
        self.assertFalse(core.verify(kp.pk, b"tampered", sig))
        other = core.KeyPair.generate()
        self.assertFalse(core.verify(other.pk, msg, sig))


if __name__ == "__main__":
    unittest.main()
