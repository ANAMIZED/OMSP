'use strict';
const crypto=require('crypto');
const O=require('./engine.js');
const {Platform,seedPlatform,runDrill,DRILLS,tierOf,errors:E}=O;

let pass=0,fail=0;
function ok(cond,msg){if(cond){pass++;}else{fail++;console.error('FAIL:',msg);}}
function throws(fn,cls,msg){try{fn();fail++;console.error('FAIL (no throw):',msg);}
  catch(e){ok(e instanceof cls,msg+' — got '+e.name+': '+e.message);}}

/* sha256 correctness vs node crypto */
for(const v of ['','abc','omsp:'+'x'.repeat(200),'unicode ✓ ☃ 𝕄esh']){
  const ref=crypto.createHash('sha256').update(v,'utf8').digest('hex');
  ok(O.sha256(v)===ref,'sha256("'+v.slice(0,12)+'…") matches node crypto');
}
ok(O.leadingZeroBits('00f0')===8,'leadingZeroBits 00f0 = 8');
ok(O.leadingZeroBits('1abc')===3,'leadingZeroBits 1abc = 3');

/* fresh platform: registration gates */
const P=new Platform();
throws(()=>P.register({name:'freeloader'}),E.SybilError,'no-stake no-pow registration blocked');
const nonce=O.powSolveSync('omsp-register:miner',P.cfg.powBitsRegister);
ok(nonce!==null,'PoW solvable at register difficulty');
const miner=P.register({name:'miner',pow:nonce,caps:['mine']});
ok(!!miner,'PoW registration accepted');
const staker=P.register({name:'staker',stake:25,caps:['stake']});
ok(staker.staked===25,'stake registration locks 25 MESH');
throws(()=>P.register({name:'staker',stake:25}),E.OmspError,'duplicate name rejected');

/* x402 + replay + funds */
P.faucet(staker.id,50);
P.pay(staker.id,miner.id,5,'hello','n1',true);
ok(miner.balance===5&&staker.balance===45,'x402 transfers balances');
throws(()=>P.pay(staker.id,miner.id,5,'again','n1',true),E.ReplayError,'nonce replay rejected');
throws(()=>P.pay(miner.id,staker.id,999,'big','n2',true),E.InsufficientFunds,'overdraft rejected');

/* autonomy cap → approval → guardian approve */
let apId=null;
try{P.pay(staker.id,miner.id,120,'huge','n3');}catch(e){ok(e instanceof E.ApprovalRequired,'over-cap spend queues approval');apId=e.approvalId;}
ok(apId&&P.approvals.get(apId).state==='pending','approval pending');
P.faucet(staker.id,200);
P.approve(apId);
ok(P.approvals.get(apId).state==='approved'&&miner.balance===125,'guardian approval executes payment once');

/* escrow lifecycle + tier gate + take-rate accrual */
P.faucet(staker.id,100);
throws(()=>P.fundEscrow(staker.id,miner.id,80,[1],true),E.GateError,'low-tier provider capped at 50');
const e1=P.fundEscrow(staker.id,miner.id,40,[0.5,0.5],true);
P.releaseMilestone(e1.id);
ok(e1.state==='FUNDED','half-released escrow still FUNDED');
P.releaseMilestone(e1.id);
ok(e1.state==='RELEASED','escrow settles after final milestone');
ok(P.tasks.get(e1.task).settled,'task settled');
P.feedback(e1.task,staker.id,miner.id,5);
P.feedback(e1.task,miner.id,staker.id,4);
throws(()=>P.feedback(e1.task,staker.id,miner.id,5),E.OmspError,'duplicate feedback rejected');
throws(()=>P.feedback(e1.task,miner.id,'ghost',5),E.OmspError,'unauthorized pair rejected');
ok(miner.rep>0&&staker.rep>0,'reputation moves on settlement+feedback');

/* dispute + arbitration */
P.faucet(staker.id,60);
const e2=P.fundEscrow(staker.id,miner.id,30,[1],true);
P.dispute(e2.id,staker.id);
const beforeC=staker.balance,beforeV=miner.balance;
P.arbitrate(e2.id,0.4);
ok(Math.abs(miner.balance-(beforeV+12))<1e-9&&Math.abs(staker.balance-(beforeC+18))<1e-9,'arbitration splits remaining 40/60');

/* take-rate volume floor */
const P2=new Platform();
P2.metrics.volumeSettled=30000;
ok(Math.abs(P2.takeRate()-0.001)<1e-12,'take-rate floors at exactly 0.1% past 25k volume');
ok(Math.abs(new Platform().takeRate()-0.015)<1e-12,'base take-rate 1.5%');

/* seeded network expectations */
const S=seedPlatform();
const byName=n=>[...S.agents.values()].find(a=>a.name===n);
ok(tierOf(byName('forge').rep)==='high','forge earned high tier organically ('+byName('forge').rep.toFixed(1)+')');
ok(tierOf(byName('atlas').rep)!=='low','atlas at least mid tier ('+byName('atlas').rep.toFixed(1)+')');
ok(tierOf(byName('lens').rep)!=='low','lens at least mid tier ('+byName('lens').rep.toFixed(1)+')');
ok(S.verifyChain().ok,'seeded chain verifies ('+S.chain.length+' blocks)');
ok(S.metrics.volumeSettled>800,'warm-up settled volume > 800 ('+S.metrics.volumeSettled.toFixed(1)+')');
ok([...S.listings.values()].some(l=>l.state==='open'&&l.bids.length>=2),'open listing with live bids');
ok([...S.swarms.values()].some(s=>s.state==='active'),'active swarm mid-flight');

/* discovery + jurisdiction + resolve + hello */
ok(S.search('code')[0].agent.name==='forge','forge tops code search (visibility×rep×boost)');
ok(S.search('translate',{jurisdiction:'US'}).every(r=>r.agent.jurisdiction!=='EU'),'EU-only agent excluded from US search');
ok(S.resolve('agent://notary').tier!==undefined,'agent:// resolution returns card');
ok(S.hello(['0.2','0.9'])==='0.2','version negotiation picks highest common');
throws(()=>S.hello(['0.0']),E.VersionError,'no common version rejected');

/* social: spam gate paths, votes, rank, boost */
const commons=[...S.communities.values()][0];
const rook=S.register({name:'rook',stake:25,caps:['scrape']});
S.faucet(rook.id,10);
throws(()=>S.post(rook.id,commons.id,'gm'),E.SpamGateError,'bare low-tier post blocked');
const p1=S.post(rook.id,commons.id,'gm — paid my dues',{payFee:true});
ok(!!p1,'fee path opens the gate');
const ch=S.postChallenge(rook,commons.id);
const pn=O.powSolveSync(ch,S.cfg.powBitsPost);
ok(!!S.post(rook.id,commons.id,'gm again — mined it',{pow:pn}),'PoW path opens the gate');
const w=S.vote(byName('forge').id,p1.id,1);
ok(w>1.4,'high-rep vote carries weight ('+w.toFixed(2)+')');
throws(()=>S.vote(byName('forge').id,p1.id,1),E.OmspError,'double vote rejected');
ok(S.feed(commons.id)[0].rank>0,'feed ranks organically');
throws(()=>S.promotePost(),E.NotSupportedError,'paid amplification refused');

/* market: feasibility filter picks capable winner over cheaper infeasible bid */
S.faucet(byName('atlas').id,200);
const L2=S.postListing(byName('atlas').id,'stress-test the escrow paths',90,['code']);
S.bid(L2.id,rook.id,45);            // low tier: 45 ≤ 50 cap, but weak rep/specialty
S.bid(L2.id,byName('forge').id,80); // high tier, specialty match
const m=S.match(L2.id,true);
ok(m.winner.name==='forge','match prefers capable specialist over cheapest');
const L3=S.postListing(byName('atlas').id,'big infra rebuild',400,['code']);
S.bid(L3.id,rook.id,60);            // 60 > low-tier cap 50 → infeasible
throws(()=>S.match(L3.id,true),E.OmspError,'no feasible bids when all exceed bidder caps');

/* tools: sandbox + payment + breaker */
S.faucet(rook.id,30);
throws(()=>S.callTool(rook.id,'shell',{cmd:'ls'}),E.SandboxError,'untrusted exec denied');
const fcRes=S.callTool(byName('atlas').id,'forecast',{horizon:'7d'});
ok(fcRes.projectedVolume>0,'paid tool call returns result');
for(let i=0;i<3;i++){S.tick(12);try{S.callTool(byName('atlas').id,'forecast',{},{_forceFail:true});}catch(_e){}}
S.tick(5);
throws(()=>S.callTool(byName('atlas').id,'forecast',{}),E.BreakerOpenError,'breaker opens after repeated failures');
S.tick(31);
ok(S.callTool(byName('atlas').id,'forecast',{}).projectedVolume>0,'breaker half-open probe recovers');

/* swarm ACL + dissolution */
const sw=[...S.swarms.values()].find(s=>s.state==='active');
ok(S.swarmGet(sw.id,byName('forge').id,'db-credentials').startsWith('postgres://'),'ACL grants forge the credentials');
throws(()=>S.swarmGet(sw.id,byName('lens').id,'db-credentials'),E.AclError,'ACL denies lens the credentials');
const rem=sw.subtasks.find(x=>!x.done);
S.completeSubtask(sw.id,rem.id,rem.assignee);
ok(sw.state==='dissolved'&&sw.outcome==='goal_met','swarm dissolves on goal');
throws(()=>S.swarmGet(sw.id,byName('forge').id,'db-credentials'),E.ContextDestroyedError,'context destroyed after dissolution');
ok(S.metrics.workflows.ok>=1,'workflow success recorded');

/* governance: bounds + weighted vote + finalize applies */
throws(()=>S.propose('take_rate_base',0.05,byName('atlas').id),E.GovBoundsError,'5% proposal rejected at bounds');
const pr=S.propose('take_rate_base',0.012,byName('atlas').id);
S.govVote(pr.id,byName('forge').id,true);
S.govVote(pr.id,byName('lens').id,true);
S.govVote(pr.id,rook.id,false);
ok(S.finalize(pr.id)==='passed'&&Math.abs(S.cfg.takeRateBase-0.012)<1e-12,'passed proposal updates parameter');

/* anomaly throttle */
const spammy=S.register({name:'spammy',stake:25});
S.faucet(spammy.id,50);
let throttled=false;
for(let i=0;i<12;i++){try{S.pay(spammy.id,'treasury',0.1,'burst',O.canon(i)+'-'+i,true);}catch(e){if(e instanceof E.ThrottleError)throttled=true;}}
ok(throttled,'anomaly detector throttles bursts');

/* kill switch full sweep + tamper mechanics + premium + knowledge + referral */
S.freeze(rook.id,'test');
throws(()=>S.post(rook.id,commons.id,'x',{payFee:true}),E.FrozenError,'frozen post rejected');
S.unfreeze(rook.id);
S.tamperBlock(2);ok(!S.verifyChain().ok,'tamper breaks verification');
S.restoreBlock(2);ok(S.verifyChain().ok,'restore repairs verification');
S.subscribe(byName('forge').id,'pro');
ok(byName('forge').premium.tier==='pro','premium subscription recorded');
S.faucet(byName('babel').id,20);
S.sellKnowledge(byName('lens').id,byName('babel').id,6,'cid:telemetry-notes');
ok(S.knowledge.length===1,'knowledge licensed via x402');
const boostBefore=byName('atlas').discoveryBoost;
S.register({name:'protege',invitedBy:byName('atlas').id});
ok(byName('atlas').discoveryBoost>boostBefore,'referral raises discovery boost');
ok(byName('atlas').discoveryBoost<=1.25,'discovery boost capped at 1.25');

/* the nine drills against a fresh seeded platform */
const D=seedPlatform();
const results=DRILLS.map(n=>runDrill(D,n));
for(const r of results)ok(r.outcome==='held',`drill "${r.name}" held — ${r.detail}`);
ok(D.verifyChain().ok,'chain still verifies after full drill sweep');

console.log('\nengine tests: '+pass+' passed, '+fail+' failed');
process.exit(fail?1:0);
