"""OMSP end-to-end demonstration + adversarial drills.

Runs the blueprint's lifecycle on a seeded network -- controlled bootstrap,
discovery, auction, escrow, swarm work, x402 tool payment, settlement,
reputation, feeds -- then executes nine attack drills and verifies every
defense held. Writes demo_report.json and dashboard.html (owner dashboard /
observation mode). [REQ-7.1]
"""
from __future__ import annotations

import html
import json

from omsp import Config, OMSPPlatform
from omsp import core
from omsp.config import (AgentFrozenError, ApprovalRequired, NotSupportedError,
                         ProposalRejectedError, ReplayError, SandboxViolation,
                         SpamGateError, SwarmDissolvedError, SybilGateError)


# ----------------------------------------------------------------- scenario --

def seed_network(p: OMSPPlatform) -> dict:
    """Facebook-style dense seeding: closed bootstrap, invited high-capability
    founders, then open registration. [REQ-9.1]"""
    founders = {}
    specs = [
        ("atlas", ["research", "web search", "synthesis"], "general",
         [{"name": "research-brief", "price": 20.0, "unit": "job"}]),
        ("forge", ["code generation", "python", "review"], "general",
         [{"name": "build-module", "price": 45.0, "unit": "job"}]),
        ("lens", ["data analysis", "charts", "forecasting"], "finance",
         [{"name": "quarterly-model", "price": 60.0, "unit": "job"}]),
        ("babel", ["translation", "localization"], "general",
         [{"name": "translate-doc", "price": 8.0, "unit": "doc"}]),
        ("notary", ["validation", "attestation"], "legal",
         [{"name": "attest-work", "price": 5.0, "unit": "job"}]),
    ]
    for name, caps, vertical, services in specs:
        owner = core.KeyPair.generate()
        p.faucet(owner.address, 50)
        p.invite(owner.address)
        agent = p.identity.register(owner, name, capabilities=caps,
                                    services=services, vertical=vertical,
                                    stake=25.0, autonomy_level=3)
        p.faucet(agent.token_id, 2000)
        p.faucet(agent.token_id, 100, "OM")
        p.identity.bind_owner(agent.token_id, owner, org=f"{name}-labs",
                              level=2)
        agent._owner_kp = owner
        founders[name] = agent
    p.config.onboarding_open = True   # floodgates open only after dense core
    return founders


def warm_up(p: OMSPPlatform, f: dict) -> None:
    """Founders earn their tiers the only way the protocol allows: through
    settled work + feedback ("reputation as capital"). [REQ-8.3][REQ-4.3]"""
    def small_job(buyer, seller, desc, amount, rating):
        esc = p.economy.create_escrow(buyer.token_id, seller.token_id,
                                      [{"desc": desc, "amount": amount}])
        p.economy.fund(esc["id"])
        p.economy.submit_milestone(esc["id"], seller.token_id, 0, "0x00")
        p.economy.approve_milestone(esc["id"], buyer.token_id, 0)
        p.reputation.give_feedback(buyer.token_id, seller.token_id,
                                   esc["id"], rating)
        p.clock.advance(600)

    for i in range(13):
        small_job(f["atlas"], f["forge"], f"warmup-forge-{i}", 30.0, 92)
    for i in range(12):
        small_job(f["atlas"], f["lens"], f"warmup-lens-{i}", 30.0, 90)
        small_job(f["lens"], f["atlas"], f"brief-{i}", 20.0, 90)
    for i in range(5):
        small_job(f["atlas"], f["babel"], f"warmup-babel-{i}", 25.0, 88)
        small_job(f["atlas"], f["notary"], f"warmup-notary-{i}", 25.0, 88)


def run_lifecycle(p: OMSPPlatform, f: dict) -> dict:
    """Discovery -> auction -> escrow -> swarm -> paid tool -> settlement ->
    reputation -> community feed."""
    atlas, forge, lens, babel, notary = (f[k] for k in
                                         ("atlas", "forge", "lens", "babel",
                                          "notary"))
    # community + posts
    com = p.social.create_community(atlas.token_id, "pipeline-guild",
                                    ["etl", "collab"])
    for a in (forge, lens, babel, notary):
        p.social.join(com["id"], a.token_id)
    # anti-spam applies from day one, founders included: pay the micro-fee
    p.social.post(atlas.token_id, com["id"],
                  {"kind": "collab-invite", "capability": "etl",
                   "detail": "nightly catalog normalization, budget 100"},
                  structured=True, pay_fee=True)

    # paid MCP tool, settled over x402
    p.tools.register(lens.token_id, "forecast", "12-week demand forecast",
                     {"series": str}, lambda series: {"trend": "up", "r2": 0.91},
                     license_type="per_call", price=0.5)
    p.tools.invoke(atlas.token_id, "forecast", {"series": "catalog-volume"})

    # discovery + auction + escrow
    hits = p.directory.search("python code generation",
                              requester=atlas.token_id)
    assert hits[0]["name"] == "forge"
    lst = p.economy.post_listing(atlas.token_id,
                                 "normalize catalog + nightly etl", 100.0)
    p.economy.bid(lst["id"], forge.token_id, 90.0, "incl. tests")
    p.economy.bid(lst["id"], babel.token_id, 95.0, "outside specialty")
    match = p.economy.match(lst["id"])
    esc, task = match["escrow"], match["task"]
    p.economy.fund(esc["id"])

    # swarm does the work with ACL'd shared context
    sw = p.swarms.form(forge.token_id, [lens.token_id, babel.token_id],
                       goal="deliver etl for atlas", ttl=7200)
    sw.memory.set_acl("db-credentials", readers={forge.token_id},
                      writers={forge.token_id})
    sw.memory.write(forge.token_id, "db-credentials", "postgres://…")
    sw.memory.write(forge.token_id, "plan", ["extract", "normalize", "load"])
    sw.assign("extract", lens.token_id, "pull raw catalog")
    sw.assign("load", babel.token_id, "load localized rows")
    sw.assign("normalize", forge.token_id, "dedupe + schema-map")
    p.a2a.accept(task["id"], forge.token_id)
    p.a2a.message(task["id"], forge.token_id,
                  [{"kind": "text", "text": "swarm formed, ETA 40 min"}])
    p.clock.advance(2400)
    for st, who in (("extract", lens), ("load", babel), ("normalize", forge)):
        sw.complete_subtask(st, who.token_id)
    p.a2a.complete(task["id"], forge.token_id,
                   artifacts=[{"kind": "data", "data": {"rows": 48210}}])

    # validation, settlement, feedback
    p.validation.request(task["id"], forge.token_id, notary.token_id,
                         stake=10.0)
    p.validation.respond(task["id"], notary.token_id, valid=True,
                         proof_hash="0x" + "ab" * 16)
    winner_bid = match["listing"]["bids"][0]["price"]
    p.economy.submit_milestone(esc["id"], forge.token_id, 0, "0x" + "cd" * 16)
    p.economy.approve_milestone(esc["id"], atlas.token_id, 0)
    p.reputation.give_feedback(atlas.token_id, forge.token_id, task["id"], 95,
                               "clean, tested, on time")
    p.reputation.give_feedback(forge.token_id, atlas.token_id, task["id"], 88,
                               "clear spec")
    # knowledge sold on the side
    kn = p.social.share_knowledge(forge.token_id, "ETL runbook",
                                  "1. extract 2. normalize 3. load",
                                  license_type="paid", price=2.0)
    p.social.acquire_knowledge(babel.token_id, kn["id"])
    # subscription
    p.economy.subscribe(atlas.token_id, lens.token_id, price=15.0,
                        period=7 * 86400)
    p.tick(7 * 86400 + 1)
    return {"escrow": esc, "task": task, "community": com,
            "swarm_outcome": sw.outcome, "winner_price": winner_bid}


# ------------------------------------------------------------------- drills --

def run_drills(p: OMSPPlatform, f: dict) -> list[dict]:
    drills = []

    def record(name, ok, detail):
        drills.append({"name": name, "outcome": "held" if ok else "FAILED",
                       "detail": detail})

    # 1. sybil flood without stake or PoW
    attacker = core.KeyPair.generate()
    blocked = 0
    for i in range(15):
        try:
            p.identity.register(attacker, f"sock-{i}", stake=0.0)
        except SybilGateError:
            blocked += 1
    record("sybil flood (no stake, no PoW)", blocked == 15,
           f"{blocked}/15 registrations blocked")

    # 2. low-rep spam without PoW/fee
    p.faucet(attacker.address, 20)
    sock = p.identity.register(attacker, "sock-paid", stake=10.0)
    p.faucet(sock.token_id, 5)
    com = next(iter(p.social.communities.values()))
    p.social.join(com["id"], sock.token_id)
    try:
        p.social.post(sock.token_id, com["id"], "gm gm gm buy $SOCK")
        record("spam gate (low-rep bare post)", False, "post accepted")
    except SpamGateError:
        record("spam gate (low-rep bare post)", True,
               "rejected without PoW or fee")

    # 3. ledger tampering
    original = p.ledger.blocks[2]["events"][0]["data"].copy()
    p.ledger.blocks[2]["events"][0]["data"]["name"] = "forged"
    ok, idx = p.ledger.verify_chain()
    p.ledger.blocks[2]["events"][0]["data"] = original
    ok2, _ = p.ledger.verify_chain()
    record("ledger tamper detection", (not ok) and idx == 2 and ok2,
           f"forgery detected at block {idx}; chain re-verifies after restore")

    # 4. x402 replay
    offer = p.economy.x402.payment_required(payee=f["lens"].token_id,
                                            amount=0.1)
    payment = p.economy.x402.pay(f["atlas"].token_id, offer)
    p.economy.x402.settle(payment)
    try:
        p.economy.x402.settle(payment)
        record("x402 replay protection", False, "replay settled")
    except ReplayError:
        record("x402 replay protection", True, "nonce reuse rejected")

    # 5. dissolved-swarm context access
    sw = p.swarms.form(f["atlas"].token_id, [f["babel"].token_id],
                       goal="ephemeral", ttl=10)
    sw.memory.write(f["atlas"].token_id, "secret", "s3cr3t")
    p.tick(11)
    try:
        sw.memory.read(f["atlas"].token_id, "secret")
        record("swarm context destruction", False, "read after dissolve")
    except SwarmDissolvedError:
        record("swarm context destruction", True,
               "context destroyed on TTL dissolution")

    # 6. frozen-agent kill switch
    p.identity.freeze(sock.token_id, attacker)
    try:
        p.a2a.create_task(sock.token_id, f["atlas"].token_id,
                          {"goal": "x", "budget": 1.0, "deadline": 1.0})
        record("kill switch", False, "frozen agent acted")
    except AgentFrozenError:
        record("kill switch", True, "frozen agent rejected everywhere")

    # 7. governance fee grab beyond hard bounds
    p.economy.stake_lock(f["atlas"].token_id, 50.0)
    prop = p.economy.propose(f["atlas"].token_id, "fee_base_rate", 0.05)
    p.economy.vote(prop["id"], f["atlas"].token_id, True)
    try:
        p.economy.finalize(prop["id"])
        record("governance hard bounds", False, "5% fee applied")
    except ProposalRejectedError:
        record("governance hard bounds", True,
               "5% fee rejected; clamp [0.1%, 2%] enforced")

    # 8. untrusted agent, dangerous capability
    p.identity.unfreeze(sock.token_id, attacker)
    p.tools.register(f["forge"].token_id, "shell-x", "runs commands",
                     {"cmd": str}, lambda cmd: "ok",
                     capability_tags={"exec"})
    try:
        p.tools.invoke(sock.token_id, "shell-x", {"cmd": "rm -rf /"})
        record("sandbox least-privilege", False, "untrusted exec ran")
    except SandboxViolation:
        record("sandbox least-privilege", True,
               "untrusted agent denied 'exec' capability")

    # 9. paid feed placement
    try:
        p.social.promote_post("post-1", budget=10_000)
        record("organic-only feeds", False, "promotion accepted")
    except NotSupportedError:
        record("organic-only feeds", True, "paid amplification refused")

    return drills


# ---------------------------------------------------------------- dashboard --

def build_dashboard(p: OMSPPlatform, drills: list[dict]) -> str:
    """Owner dashboard / observation mode as a single offline HTML file.
    [REQ-7.1]"""
    rep = p.stats.report()
    ok, _ = p.ledger.verify_chain()
    tape = " › ".join(b["hash"][:10] for b in p.ledger.blocks[-14:])
    agents_rows = "".join(
        f"<tr><td>#{a.token_id}</td><td>{html.escape(a.name)}</td>"
        f"<td>{p.reputation.tier(a.token_id)}</td>"
        f"<td class='num'>{p.reputation.score(a.token_id):.1f}</td>"
        f"<td class='num'>{p.tokens.balance(a.token_id):.2f}</td>"
        f"<td>{'frozen' if a.frozen else 'active'}</td></tr>"
        for a in p.identity.all_agents())
    events_rows = "".join(
        f"<tr><td class='num'>{e['ts']:.0f}</td>"
        f"<td>{html.escape(str(e['type']))}</td>"
        f"<td>{html.escape(json.dumps(e['data'], default=str)[:96])}</td></tr>"
        for e in p.safety.observation_stream(28))
    drill_chips = "".join(
        f"<span class='stamp {'pass' if d['outcome'] == 'held' else 'fail'}'>"
        f"{html.escape(d['name'])} — {html.escape(d['outcome'])}</span>"
        for d in drills)
    wf = rep["multi_agent_workflows"]
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>OMSP node — owner console</title><style>
:root {{ --ground:#10201f; --panel:#16302d; --rule:#2a4a45; --ink:#d7e4de;
  --muted:#8aa39b; --amber:#e8b34b; --mint:#6fd0a8; --alert:#e07856; }}
* {{ box-sizing:border-box; margin:0; }}
body {{ background:var(--ground); color:var(--ink); padding:28px 20px 56px;
  font:15px/1.55 "Avenir Next","Segoe UI",system-ui,sans-serif; }}
.wrap {{ max-width:1060px; margin:0 auto; }}
header h1 {{ font-size:15px; font-weight:600; letter-spacing:.34em;
  text-transform:uppercase; }}
header .sub {{ color:var(--muted); font-size:13px; margin-top:4px; }}
.chainline {{ display:flex; gap:12px; align-items:baseline; margin-top:18px;
  border-top:1px solid var(--rule); border-bottom:1px solid var(--rule);
  padding:10px 0; overflow:hidden; }}
.chainline b {{ color:{'var(--mint)' if ok else 'var(--alert)'};
  font-size:12px; letter-spacing:.18em; text-transform:uppercase;
  flex:none; }}
.tape {{ font:12px/1 ui-monospace,"SF Mono","Cascadia Code",Menlo,monospace;
  color:var(--muted); white-space:nowrap; }}
.ledger {{ display:flex; flex-wrap:wrap; gap:0; margin:26px 0 8px;
  border-bottom:1px solid var(--rule); }}
.ledger div {{ flex:1 1 220px; padding:14px 18px 16px;
  border-top:1px solid var(--rule); }}
.ledger div + div {{ border-left:1px solid var(--rule); }}
.ledger small {{ display:block; color:var(--muted); font-size:11px;
  letter-spacing:.22em; text-transform:uppercase; margin-bottom:8px; }}
.ledger strong {{ font:26px/1 ui-monospace,"SF Mono",Menlo,monospace;
  color:var(--amber); font-weight:500; }}
h2 {{ font-size:11px; letter-spacing:.28em; text-transform:uppercase;
  color:var(--muted); margin:30px 0 10px; }}
.cols {{ display:flex; gap:28px; flex-wrap:wrap; }}
.cols > section {{ flex:1 1 380px; min-width:0; }}
table {{ width:100%; border-collapse:collapse; font-size:13px; }}
th {{ text-align:left; color:var(--muted); font-weight:500; font-size:11px;
  letter-spacing:.14em; text-transform:uppercase; padding:6px 10px;
  border-bottom:1px solid var(--rule); }}
td {{ padding:6px 10px; border-bottom:1px solid var(--panel);
  overflow-wrap:anywhere; }}
td.num {{ font-family:ui-monospace,"SF Mono",Menlo,monospace;
  color:var(--amber); }}
.stamps {{ display:flex; flex-wrap:wrap; gap:10px; }}
.stamp {{ font:11px/1 ui-monospace,Menlo,monospace; letter-spacing:.08em;
  padding:8px 12px; border:1px solid var(--mint); color:var(--mint);
  border-radius:2px; text-transform:uppercase; }}
.stamp.fail {{ border-color:var(--alert); color:var(--alert); }}
:focus-visible {{ outline:2px solid var(--amber); outline-offset:2px; }}
</style></head><body><div class="wrap">
<header><h1>Open Mesha Social Protocol</h1>
<div class="sub">Owner console · observation mode · node time
{p.clock.now():.0f}s</div></header>
<div class="chainline"><b>chain {'verified' if ok else 'BROKEN'}</b>
<div class="tape">{tape}</div></div>
<div class="ledger">
<div><small>Economic volume settled</small>
<strong>{rep['economic_volume_settled']:.2f}</strong> USDC</div>
<div><small>Multi-agent workflows</small>
<strong>{wf['successful']}/{wf['total']}</strong> successful</div>
<div><small>High-rep interaction density</small>
<strong>{rep['high_rep_interaction_density']:.2f}</strong></div>
<div><small>Treasury revenue</small>
<strong>{rep['treasury_revenue']:.2f}</strong> USDC</div>
</div>
<div class="cols">
<section><h2>Agents on this node</h2><table>
<tr><th>id</th><th>name</th><th>tier</th><th>rep</th><th>USDC</th>
<th>state</th></tr>{agents_rows}</table></section>
<section><h2>Committed event stream</h2><table>
<tr><th>t</th><th>event</th><th>data</th></tr>{events_rows}</table></section>
</div>
<h2>Adversarial drills</h2><div class="stamps">{drill_chips}</div>
</div></body></html>"""


# --------------------------------------------------------------------- main --

def main() -> dict:
    p = OMSPPlatform(Config())
    founders = seed_network(p)
    warm_up(p, founders)
    lifecycle = run_lifecycle(p, founders)
    drills = run_drills(p, founders)
    report = {
        "north_star_metrics": p.stats.report(),
        "chain_verified": p.ledger.verify_chain()[0],
        "swarm_outcome": lifecycle["swarm_outcome"],
        "escrow_state": lifecycle["escrow"]["state"],
        "winner_price": lifecycle["winner_price"],
        "forge_reputation": round(p.reputation.score(
            founders["forge"].token_id), 2),
        "drills": drills,
        "all_drills_held": all(d["outcome"] == "held" for d in drills),
    }
    with open("demo_report.json", "w") as fh:
        json.dump(report, fh, indent=2)
    with open("dashboard.html", "w") as fh:
        fh.write(build_dashboard(p, drills))
    print(json.dumps(report, indent=2))
    return report


if __name__ == "__main__":
    main()
