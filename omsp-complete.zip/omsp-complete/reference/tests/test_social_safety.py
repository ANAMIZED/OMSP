"""Communities, feeds, anti-spam, knowledge sharing, subnets, anomaly."""
import unittest

from omsp import core
from omsp.config import (AuthorizationError, NotSupportedError,
                         RateLimitedError, SpamGateError)
from tests.helpers import boost_rep, make_agent, make_platform


class TestCommunitiesAndFeed(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.founder = make_agent(self.p, "founder")
        boost_rep(self.p, self.founder.token_id, n=30)
        self.com = self.p.social.create_community(
            self.founder.token_id, "vision-models",
            purpose_tags=["computer-vision", "collab"])

    def test_capability_oriented_communities(self):
        """[REQ-5.1] Communities carry purpose tags and membership."""
        self.assertEqual(self.com["purpose_tags"],
                         ["computer-vision", "collab"])
        member = make_agent(self.p, "joiner")
        self.p.social.join(self.com["id"], member.token_id)
        self.assertIn(member.token_id,
                      self.p.social.members(self.com["id"]))
        with self.assertRaises(AuthorizationError):  # must join to post
            outsider = make_agent(self.p, "outsider")
            self.p.social.post(outsider.token_id, self.com["id"], "hi")

    def test_low_rep_posts_need_pow_or_fee(self):
        """[REQ-11.1] Economic + cryptographic anti-spam: low-rep post is
        rejected bare, accepted with valid PoW, accepted with fee."""
        rookie = make_agent(self.p, "rookie")
        self.p.social.join(self.com["id"], rookie.token_id)
        with self.assertRaises(SpamGateError):
            self.p.social.post(rookie.token_id, self.com["id"], "gm gm gm")
        challenge = (f"omsp-post:{rookie.token_id}:{self.com['id']}:"
                     f"{int(self.p.clock.now() // 86400)}")
        nonce = core.pow_solve(challenge, self.p.config.post_pow_bits)
        post = self.p.social.post(rookie.token_id, self.com["id"],
                                  "useful benchmark numbers",
                                  pow_nonce=nonce)
        self.assertTrue(post["id"].startswith("post-"))
        before = self.p.tokens.balance("TREASURY")
        self.p.social.post(rookie.token_id, self.com["id"], "more data",
                           pay_fee=True)
        self.assertAlmostEqual(self.p.tokens.balance("TREASURY"),
                               before + self.p.config.post_fee)
        # high-rep authors post freely
        self.p.social.post(self.founder.token_id, self.com["id"],
                           "weekly digest")

    def test_feed_is_reputation_weighted_utility(self):
        """[REQ-5.2] High-rep authorship and rep-weighted votes outrank
        low-rep spam of the same age."""
        rookie = make_agent(self.p, "spammy")
        voter = make_agent(self.p, "curator")
        boost_rep(self.p, voter.token_id, n=30)
        self.p.social.join(self.com["id"], rookie.token_id)
        self.p.social.join(self.com["id"], voter.token_id)
        spam = self.p.social.post(rookie.token_id, self.com["id"],
                                  "buy my thing", pay_fee=True)
        gem = self.p.social.post(self.founder.token_id, self.com["id"],
                                 "reproducible eval harness inside")
        self.p.social.vote(voter.token_id, gem["id"], +1)
        self.p.social.vote(voter.token_id, spam["id"], -1)
        feed = self.p.social.feed(voter.token_id, self.com["id"])
        ids = [f["id"] for f in feed]
        self.assertLess(ids.index(gem["id"]), ids.index(spam["id"]))

    def test_no_paid_amplification_in_feeds(self):
        """[REQ-10.4] Promotion API refuses; a 'sponsored' flag changes
        nothing in ranking."""
        with self.assertRaises(NotSupportedError):
            self.p.social.promote_post("post-1", budget=1000)
        a = self.p.social.post(self.founder.token_id, self.com["id"], "same")
        b = self.p.social.post(self.founder.token_id, self.com["id"], "same")
        self.p.social.posts[b["id"]]["sponsored"] = True  # attacker metadata
        now = self.p.clock.now()
        self.assertEqual(self.p.social._rank(self.p.social.posts[a["id"]], now),
                         self.p.social._rank(self.p.social.posts[b["id"]], now))

    def test_structured_posts_validated(self):
        """[REQ-3.4] Schema-constrained posts validate; malformed rejected."""
        ok = self.p.social.post(self.founder.token_id, self.com["id"],
                                {"kind": "capability-offer",
                                 "capability": "ocr", "detail": "99.1% acc"},
                                structured=True)
        self.assertTrue(ok["structured"])
        from omsp.config import SchemaError
        with self.assertRaises(SchemaError):
            self.p.social.post(self.founder.token_id, self.com["id"],
                               {"kind": "capability-offer"}, structured=True)


class TestKnowledge(unittest.TestCase):
    def test_licensed_knowledge_paid_over_x402(self):
        """[REQ-5.4] Paid knowledge requires an x402 settlement; free readers
        are rejected until they acquire."""
        p = make_platform()
        author = make_agent(p, "librarian")
        reader = make_agent(p, "student")
        item = p.social.share_knowledge(author.token_id, "Prompt patterns",
                                        "...body...", license_type="paid",
                                        price=1.5)
        with self.assertRaises(AuthorizationError):
            p.social.read_knowledge(reader.token_id, item["id"])
        out = p.social.acquire_knowledge(reader.token_id, item["id"])
        self.assertEqual(out["receipt"]["status"], 200)
        self.assertEqual(p.social.read_knowledge(reader.token_id, item["id"]),
                         "...body...")
        self.assertAlmostEqual(p.tokens.balance(author.token_id), 1001.5)


class TestPrivateSubnets(unittest.TestCase):
    def test_enterprise_private_subnet_hidden_everywhere(self):
        """[REQ-7.3] Private-subnet members are invisible in discovery and
        their community feed is hidden from outsiders."""
        p = make_platform()
        corp = make_agent(p, "acme-lead", capabilities=["forecasting"])
        boost_rep(p, corp.token_id, n=30)
        p.economy.set_premium(corp.token_id, "enterprise")
        com = p.social.create_community(corp.token_id, "acme-internal",
                                        ["private-ops"], private=True,
                                        subnet="acme")
        colleague = make_agent(p, "acme-analyst", capabilities=["forecasting"])
        p.social.join(com["id"], colleague.token_id,
                      invited_by=corp.token_id)
        outsider = make_agent(p, "rando")
        with self.assertRaises(AuthorizationError):
            p.social.join(com["id"], outsider.token_id)

        seen = [r["name"] for r in
                p.directory.search("forecasting",
                                   requester=outsider.token_id)]
        self.assertNotIn("acme-lead", seen)
        self.assertNotIn("acme-analyst", seen)
        seen_inside = [r["name"] for r in
                       p.directory.search("forecasting",
                                          requester=colleague.token_id)]
        self.assertIn("acme-lead", seen_inside)

        p.social.post(corp.token_id, com["id"], "internal roadmap")
        self.assertEqual(p.social.feed(outsider.token_id), [])
        self.assertEqual(len(p.social.feed(colleague.token_id)), 1)


class TestAnomaly(unittest.TestCase):
    def test_flood_triggers_throttle_then_recovers(self):
        """[REQ-11.2] Flooding past the window threshold auto-throttles the
        agent; the throttle expires after cooldown."""
        p = make_platform(anomaly_max_actions=10, rate_base_capacity=100.0)
        flooder = make_agent(p, "flooder")
        peer = make_agent(p, "peer")
        boost_rep(p, flooder.token_id, n=30)
        with self.assertRaises(RateLimitedError):
            for _ in range(40):
                p.a2a.create_task(flooder.token_id, peer.token_id,
                                  {"goal": "spam", "budget": 0.0,
                                   "deadline": 1.0})
        self.assertTrue(p.safety.throttled(flooder.token_id))
        self.assertTrue(p.ledger.query("safety.anomaly_throttle"))
        p.clock.advance(p.config.anomaly_cooldown + 1)
        self.assertFalse(p.safety.throttled(flooder.token_id))


if __name__ == "__main__":
    unittest.main()
