"""Safety & governance mechanisms.

- CircuitBreaker: CLOSED -> OPEN after N failures -> HALF_OPEN after cooldown.
  [REQ-11.2]
- AnomalyDetector: flags flooding (actions in window > threshold) and applies a
  temporary throttle that the rate limiter honors. [REQ-11.2]
- Sandbox policy: dangerous capabilities gated on trust (KYA or high rep);
  untrusted safe calls run sandbox-flagged. [REQ-6.3]
- Autonomy gradients: per-level spend caps; over-cap actions raise
  ApprovalRequired and proceed only after recorded human approval. [REQ-11.5]
- Observation stream for the human dashboard. [REQ-7.1]
"""
from __future__ import annotations

import itertools
from collections import deque

from . import core
from .config import (ApprovalRequired, AuthorizationError, CircuitOpenError,
                     SandboxViolation)


class CircuitBreaker:
    CLOSED, OPEN, HALF_OPEN = "closed", "open", "half_open"

    def __init__(self, clock, threshold: int, cooldown: float):
        self.clock = clock
        self.threshold = threshold
        self.cooldown = cooldown
        self.state = self.CLOSED
        self.failures = 0
        self.opened_at = 0.0

    def call(self, fn):
        if self.state == self.OPEN:
            if self.clock.now() - self.opened_at >= self.cooldown:
                self.state = self.HALF_OPEN
            else:
                raise CircuitOpenError("circuit open: failing fast")
        try:
            result = fn()
        except Exception:
            self.failures += 1
            if self.state == self.HALF_OPEN or self.failures >= self.threshold:
                self.state = self.OPEN
                self.opened_at = self.clock.now()
            raise
        else:
            self.failures = 0
            self.state = self.CLOSED
            return result


class Safety:
    def __init__(self, platform):
        self.p = platform
        self._breakers: dict[str, CircuitBreaker] = {}
        self._actions: dict[int, deque] = {}
        self._throttled_until: dict[int, float] = {}
        self.approvals: dict[str, dict] = {}
        self._aid = itertools.count(1)

    # ------------------------------------------------------ circuit breaker --
    def breaker(self, key: str) -> CircuitBreaker:
        cfg = self.p.config
        if key not in self._breakers:
            self._breakers[key] = CircuitBreaker(
                self.p.clock, cfg.breaker_threshold, cfg.breaker_cooldown)
        return self._breakers[key]

    # ---------------------------------------------------- anomaly detection --
    def observe_action(self, agent_id: int) -> None:
        """Record an action; flood behavior triggers a temporary throttle.
        [REQ-11.2]"""
        cfg = self.p.config
        now = self.p.clock.now()
        dq = self._actions.setdefault(agent_id, deque())
        dq.append(now)
        while dq and dq[0] < now - cfg.anomaly_window:
            dq.popleft()
        if len(dq) > cfg.anomaly_max_actions and not self.throttled(agent_id):
            self._throttled_until[agent_id] = now + cfg.anomaly_cooldown
            self.p.ledger.commit("safety.anomaly_throttle",
                                 {"agent": agent_id,
                                  "actions_in_window": len(dq),
                                  "until": self._throttled_until[agent_id]},
                                 actor=agent_id)

    def throttled(self, agent_id: int) -> bool:
        return self.p.clock.now() < self._throttled_until.get(agent_id, 0.0)

    # -------------------------------------------------------------- sandbox --
    def trusted(self, agent_id: int) -> bool:
        agent = self.p.identity.get(agent_id)
        return agent.kya_level >= 1 or self.p.reputation.score(agent_id) >= 60

    def sandbox_check(self, agent_id: int, capability_tags: set) -> bool:
        """Least-privilege execution policy. Returns True if the call must run
        sandboxed; raises for dangerous capabilities by untrusted agents.
        [REQ-6.3]"""
        from .comms import ToolRegistry
        dangerous = bool(capability_tags & ToolRegistry.DANGEROUS)
        if self.trusted(agent_id):
            return False
        if dangerous:
            raise SandboxViolation(
                f"untrusted agent {agent_id} may not use capabilities "
                f"{sorted(capability_tags & ToolRegistry.DANGEROUS)}")
        return True

    # ------------------------------------------------------------- autonomy --
    def check_spend(self, agent_id: int, amount: float) -> None:
        """Autonomy gradient: spend above the level cap requires human
        approval. [REQ-11.5]"""
        agent = self.p.identity.get(agent_id)
        cap = self.p.config.autonomy_caps.get(agent.autonomy_level, 0.0)
        if amount <= cap:
            return
        req = {"id": f"appr-{next(self._aid)}", "agent": agent_id,
               "amount": amount, "cap": cap, "state": "pending",
               "ts": self.p.clock.now()}
        self.approvals[req["id"]] = req
        self.p.ledger.commit("safety.approval_requested",
                             {"request": req["id"], "agent": agent_id,
                              "amount": amount, "cap": cap}, actor=agent_id)
        raise ApprovalRequired(req)

    def approve(self, request_id: str, owner_kp: core.KeyPair) -> dict:
        """Recorded human approval lifts the cap for this action once.
        [REQ-11.5][REQ-7.1]"""
        req = self.approvals[request_id]
        agent = self.p.identity.get(req["agent"])
        if owner_kp.address != agent.owner_address:
            raise AuthorizationError("only the agent's owner may approve")
        req["state"] = "approved"
        old_cap = self.p.config.autonomy_caps[agent.autonomy_level]
        req["restore_cap"] = old_cap
        self.p.ledger.commit("safety.approval_granted",
                             {"request": request_id, "by": owner_kp.address},
                             actor=req["agent"])
        return req

    def with_approval(self, request_id: str, fn):
        """Run fn under a one-shot lifted cap for the approved amount."""
        req = self.approvals[request_id]
        if req["state"] != "approved":
            raise AuthorizationError("approval not granted")
        agent = self.p.identity.get(req["agent"])
        caps = self.p.config.autonomy_caps
        old = caps[agent.autonomy_level]
        caps[agent.autonomy_level] = max(old, req["amount"])
        try:
            return fn()
        finally:
            caps[agent.autonomy_level] = old
            req["state"] = "consumed"

    # ---------------------------------------------------------- observation --
    def observation_stream(self, limit: int = 50) -> list[dict]:
        """Human observation mode: recent committed events. [REQ-7.1]"""
        events = []
        for block in self.p.ledger.blocks[-limit:]:
            events.extend(block["events"])
        return events[-limit:]
