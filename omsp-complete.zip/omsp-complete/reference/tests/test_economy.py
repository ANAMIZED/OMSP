"""Settlement, escrow, marketplace, fees, governance, growth mechanics."""
import unittest

from omsp.config import (ApprovalRequired, ComplianceError, GateError,
                         PaymentError, ProposalRejectedError, ReplayError)
from tests.helpers import boost_rep, make_agent, make_platform


class TestX402(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.payer = make_agent(self.p, "spender")
        self.payee = make_agent(self.p, "vendor")

    def test_402_flow_settles_with_receipt(self):
        """[REQ-4.1] 402 offer -> signed payment -> verified settlement ->
        receipt; no protocol fee on micropayments."""
        offer = self.p.economy.x402.payment_required(
            payee=self.payee.token_id, amount=0.10, resource="/report")
        self.assertEqual(offer["status"], 402)
        payment = self.p.economy.x402.pay(self.payer.token_id, offer)
        treasury_before = self.p.tokens.balance("TREASURY")
        receipt = self.p.economy.x402.settle(payment)
        self.assertEqual(receipt["status"], 200)
        self.assertAlmostEqual(self.p.tokens.balance(self.payee.token_id),
                               1000.10)
        self.assertEqual(self.p.tokens.balance("TREASURY"), treasury_before)

    def test_replay_rejected(self):
        """[REQ-4.1] Reusing a settled nonce fails."""
        offer = self.p.economy.x402.payment_required(
            payee=self.payee.token_id, amount=0.10)
        payment = self.p.economy.x402.pay(self.payer.token_id, offer)
        self.p.economy.x402.settle(payment)
        with self.assertRaises(ReplayError):
            self.p.economy.x402.settle(payment)

    def test_forged_signature_rejected(self):
        """[REQ-4.1] Tampered payment payloads fail verification."""
        offer = self.p.economy.x402.payment_required(
            payee=self.payee.token_id, amount=0.10)
        payment = self.p.economy.x402.pay(self.payer.token_id, offer)
        payment["payload"]["amount"] = 999.0
        with self.assertRaises(PaymentError):
            self.p.economy.x402.settle(payment)


class TestEscrow(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.buyer = make_agent(self.p, "client-co")
        self.seller = make_agent(self.p, "builder")
        boost_rep(self.p, self.seller.token_id, n=15)  # mid tier: cap 500

    def test_milestone_lifecycle_releases_with_fee(self):
        """[REQ-4.2][REQ-10.1] fund -> submit -> approve releases funds minus
        the take-rate; completion fires auto-reputation. [REQ-4.3]"""
        esc = self.p.economy.create_escrow(
            self.buyer.token_id, self.seller.token_id,
            [{"desc": "draft", "amount": 60.0}, {"desc": "final", "amount": 40.0}])
        self.p.economy.fund(esc["id"])
        self.assertEqual(esc["state"], "FUNDED")
        self.assertEqual(self.p.tokens.balance("ESCROW"), 100.0)

        rep_before = self.p.reputation.score(self.seller.token_id)
        self.p.economy.submit_milestone(esc["id"], self.seller.token_id, 0,
                                        "0xhash1")
        self.p.economy.approve_milestone(esc["id"], self.buyer.token_id, 0)
        self.p.economy.submit_milestone(esc["id"], self.seller.token_id, 1,
                                        "0xhash2")
        self.p.economy.approve_milestone(esc["id"], self.buyer.token_id, 1)

        self.assertEqual(esc["state"], "RELEASED")
        rate = 0.015  # base rate, low volume
        self.assertAlmostEqual(self.p.tokens.balance(self.seller.token_id),
                               1000.0 + 100.0 * (1 - rate), places=6)
        self.assertAlmostEqual(self.p.tokens.balance("TREASURY"),
                               100.0 * rate, places=6)
        self.assertGreater(self.p.reputation.score(self.seller.token_id),
                           rep_before)
        # settlement authorized optional feedback [REQ-4.3]
        self.p.reputation.give_feedback(self.buyer.token_id,
                                        self.seller.token_id, esc["id"], 92)

    def test_dispute_arbitration_refund(self):
        """[REQ-11.2][REQ-4.2] High-rep panel arbitration refunds the buyer on
        a refund majority; parties and low-rep agents can't sit."""
        arb1 = make_agent(self.p, "judge-1")
        arb2 = make_agent(self.p, "judge-2")
        arb3 = make_agent(self.p, "judge-3")
        for a in (arb1, arb2, arb3):
            boost_rep(self.p, a.token_id, n=30)
        esc = self.p.economy.create_escrow(
            self.buyer.token_id, self.seller.token_id,
            [{"desc": "job", "amount": 80.0}])
        self.p.economy.fund(esc["id"])
        self.p.economy.dispute(esc["id"], self.buyer.token_id, 0,
                               "deliverable empty")
        with self.assertRaises(Exception):  # party can't arbitrate
            self.p.economy.arbitrate(esc["id"], [self.buyer.token_id],
                                     {self.buyer.token_id: "refund"})
        panel = [arb1.token_id, arb2.token_id, arb3.token_id]
        out = self.p.economy.arbitrate(
            esc["id"], panel, {arb1.token_id: "refund",
                               arb2.token_id: "refund",
                               arb3.token_id: "release"})
        self.assertEqual(out["state"], "REFUNDED")
        self.assertAlmostEqual(self.p.tokens.balance(self.buyer.token_id),
                               1000.0)
        self.assertLess(self.p.stats.of(self.seller.token_id)["success_rate"],
                        1.0)

    def test_job_value_gated_by_reputation_tier(self):
        """[REQ-8.3] A low-tier seller cannot take jobs above the tier cap."""
        rookie = make_agent(self.p, "rookie-seller")
        with self.assertRaises(GateError):
            self.p.economy.create_escrow(self.buyer.token_id, rookie.token_id,
                                         [{"desc": "big", "amount": 400.0}])

    def test_take_rate_progressive_and_clamped(self):
        """[REQ-10.1] Volume discounts apply; rate never leaves [0.1%, 2%]."""
        s = self.seller.token_id
        self.assertAlmostEqual(self.p.economy.take_rate(s), 0.015)
        self.p.stats.record_settlement(s, 5_000)
        self.assertAlmostEqual(self.p.economy.take_rate(s), 0.0075)
        self.p.stats.record_settlement(s, 20_000)
        self.assertAlmostEqual(self.p.economy.take_rate(s), 0.003)
        self.p.stats.record_settlement(s, 200_000)
        self.assertAlmostEqual(self.p.economy.take_rate(s), 0.001)  # floor
        self.p.config.fee_base_rate = 0.02
        self.p.stats._per_agent[s]["settlements"].clear()
        self.assertLessEqual(self.p.economy.take_rate(s), 0.02)     # cap


class TestMarketplace(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.buyer = make_agent(self.p, "demand")
        self.s1 = make_agent(self.p, "cheap-low-rep")
        self.s2 = make_agent(self.p, "pricier-high-rep")
        boost_rep(self.p, self.s2.token_id, n=30)

    def test_auction_matching_wires_escrow_and_task(self):
        """[REQ-4.4][REQ-8.2] Bidding + auto-match on rep/price/success ->
        escrow + A2A task created atomically."""
        lst = self.p.economy.post_listing(self.buyer.token_id,
                                          "scrape and normalize catalog",
                                          budget=100.0)
        self.p.economy.bid(lst["id"], self.s1.token_id, 60.0)
        self.p.economy.bid(lst["id"], self.s2.token_id, 80.0)
        out = self.p.economy.match(lst["id"])
        self.assertEqual(out["listing"]["winner"], self.s2.token_id)
        self.assertEqual(out["escrow"]["total"], 80.0)
        self.assertEqual(out["task"]["to"], self.s2.token_id)
        self.assertEqual(out["escrow"]["task"], out["task"]["id"])

    def test_fixed_price_hire_from_service_catalog(self):
        """[REQ-8.2][REQ-8.1] Fixed-price hire uses the seller's catalog."""
        chef = make_agent(self.p, "chef",
                          services=[{"name": "menu-plan", "price": 15.0,
                                     "unit": "job"}])
        out = self.p.economy.hire_fixed(self.buyer.token_id, chef.token_id,
                                        "menu-plan")
        self.assertEqual(out["escrow"]["total"], 15.0)

    def test_subscription_charges_on_tick_and_cancels(self):
        """[REQ-8.2] Subscriptions charge each period; cancel stops charges."""
        sub = self.p.economy.subscribe(self.buyer.token_id, self.s2.token_id,
                                       price=10.0, period=100.0)
        self.p.tick(250.0)
        self.assertEqual(sub["charges"], 2)
        self.p.economy.cancel_subscription(sub["id"], self.buyer.token_id)
        self.p.tick(200.0)
        self.assertEqual(sub["charges"], 2)

    def test_compliance_adapter_blocks_unverified_regulated_work(self):
        """[REQ-11.6] Finance listings require KYA-verified agents."""
        with self.assertRaises(ComplianceError):
            self.p.economy.post_listing(self.buyer.token_id,
                                        "manage treasury", 50.0,
                                        vertical="finance")
        self.p.identity.bind_owner(self.buyer.token_id, self.buyer._owner_kp,
                                   org="Fund LP", level=2)
        lst = self.p.economy.post_listing(self.buyer.token_id,
                                          "manage treasury", 50.0,
                                          vertical="finance")
        self.assertEqual(lst["vertical"], "finance")
        with self.assertRaises(ComplianceError):  # sellers checked too
            self.p.economy.bid(lst["id"], self.s1.token_id, 40.0)


class TestGovernanceGrowth(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.whale = make_agent(self.p, "whale", om=100.0)
        self.p.economy.stake_lock(self.whale.token_id, 50.0)

    def test_governance_applies_in_bounds_parameter(self):
        """[REQ-10.3] Stake-weighted vote retunes a parameter inside bounds."""
        prop = self.p.economy.propose(self.whale.token_id, "fee_base_rate",
                                      0.01)
        self.p.economy.vote(prop["id"], self.whale.token_id, True)
        out = self.p.economy.finalize(prop["id"])
        self.assertEqual(out["result"], "applied")
        self.assertEqual(self.p.config.fee_base_rate, 0.01)

    def test_governance_cannot_exceed_hard_bounds(self):
        """[REQ-10.3][REQ-10.1] A 5% fee proposal is rejected: bounds are
        spec-level, above governance."""
        prop = self.p.economy.propose(self.whale.token_id, "fee_base_rate",
                                      0.05)
        self.p.economy.vote(prop["id"], self.whale.token_id, True)
        with self.assertRaises(ProposalRejectedError):
            self.p.economy.finalize(prop["id"])
        self.assertNotEqual(self.p.config.fee_base_rate, 0.05)

    def test_referral_reward_and_decaying_bounded_boost(self):
        """[REQ-9.2] Referrer earns OM; referred agent gets a bounded boost
        that decays toward 1.0."""
        newbie = make_agent(self.p, "referred",
                            referrer=self.whale.token_id)
        self.assertEqual(self.p.tokens.balance(self.whale.token_id, "OM"),
                         50.0 + self.p.config.referral_reward_om)
        b0 = self.p.economy.discovery_boost(newbie.token_id)
        self.assertGreater(b0, 1.0)
        self.assertLessEqual(b0, self.p.config.discovery_boost_cap)
        self.p.clock.advance(self.p.config.referral_boost_half_life * 5)
        b1 = self.p.economy.discovery_boost(newbie.token_id)
        self.assertLess(b1, b0)
        self.assertAlmostEqual(b1, 1.0, places=1)

    def test_premium_tiers_grant_bounded_benefits(self):
        """[REQ-10.2] Paid tiers raise rate limits + analytics + private-net
        rights; discovery boost stays under the hard cap."""
        pro = make_agent(self.p, "pro-agent")
        self.p.economy.set_premium(pro.token_id, "enterprise")
        b = self.p.economy.premium_benefits(pro.token_id)
        self.assertTrue(b["analytics"])
        self.assertTrue(b["private_subnets"])
        self.assertGreater(b["rate_mult"], 1.0)
        self.assertLessEqual(self.p.economy.discovery_boost(pro.token_id),
                             self.p.config.discovery_boost_cap)
        self.assertEqual(self.p.tokens.balance("TREASURY"), 500.0)


class TestAutonomy(unittest.TestCase):
    def test_spend_above_cap_needs_recorded_human_approval(self):
        """[REQ-11.5] L1 agent funding a 50-USDC escrow triggers approval; the
        owner's recorded approval unblocks exactly that action."""
        p = make_platform()
        junior = make_agent(p, "junior", autonomy_level=1)
        seller = make_agent(p, "vendor")
        boost_rep(p, seller.token_id, n=15)
        esc = p.economy.create_escrow(junior.token_id, seller.token_id,
                                      [{"desc": "job", "amount": 50.0}])
        with self.assertRaises(ApprovalRequired) as ctx:
            p.economy.fund(esc["id"])
        req = ctx.exception.request
        p.safety.approve(req["id"], junior._owner_kp)
        p.safety.with_approval(req["id"], lambda: p.economy.fund(esc["id"]))
        self.assertEqual(esc["state"], "FUNDED")
        self.assertTrue(p.ledger.query("safety.approval_granted"))
        # cap restored: a second big spend needs a fresh approval
        esc2 = p.economy.create_escrow(junior.token_id, seller.token_id,
                                       [{"desc": "job2", "amount": 50.0}])
        with self.assertRaises(ApprovalRequired):
            p.economy.fund(esc2["id"])


if __name__ == "__main__":
    unittest.main()
