# OMSP Changelog

All entries 2026-08-20. The browser app displays its build number under
System → Interop.

## Audit pass (final)
No code changes to either implementation — both were green, and review confirmed
the Python reference already hires atomically (escrow funded before a listing is
marked matched) while its approve-then-retry model is a documented design
difference, not a divergence. Added: machine-checked SPEC ↔ app parity audit
(`app/audit/verify_parity.js` + map, 44/44 mapped, 67 evidence strings),
`build.py` invariant-guarded assembler with byte-reproducibility proof, and the
documentation set (README, ARCHITECTURE, PARITY, VERIFICATION_REPORT v2, this
file). Regenerated `TRACEABILITY.md`, `demo_report.json`, `dashboard.html` from
their scripts.

## build 4 — constellation
Added the chain-driven 3D knowledge constellation: incremental ledger sync,
deterministic layout, force physics, orbit/pinch/tap camera, Obsidian-style wiki
cards with backlinks, agent deep-links ("⌾ Star map"), knowledge-star pruning
(12 most recent). New `constellation.js` (+46 tests); UI harness grew to 48
checks with frame-pumped rAF and a recording canvas context. 113,781 bytes.

## build 3 — the freeze
**Field bug:** app loaded and visibly ran but accepted no taps. Cause: author CSS
`display:flex` on the bottom-sheet container silently overrides the HTML `hidden`
attribute, leaving an invisible full-screen `position:fixed` layer over the
entire app from load. Headless harnesses invoke handlers directly and can never
see hit-testing/stacking. Fixed with triple redundancy (global
`[hidden]{display:none!important}`, inline `display:none`, JS toggling display
directly) and a build invariant so the class cannot regress. Also: touch/scroll
render-hold so ambient rebuilds stop interrupting finger scrolling; removed the
external Google Fonts request (file now fully self-contained); typing-flag
watchdog.

## build 2 — the mining crash
**Field bug:** both proof-of-work flows (registration, spam gate) crashed on tap.
Cause: a chained `append(...).lastChild` — `Element.append()` returns undefined
in real DOM; the harness stub matched that behavior but no test had ever tapped
the mining path. Fixed, plus: boot race guard (`readyState` check for viewers
that execute after document load), removed ES2022 `.at()` for older WebViews,
`dvh` fallbacks, focus-guard so re-renders stop stealing keyboard focus, on-page
error reporter that prints the exact failing line, gated-post drafts preserved
on failure. Harness gained five end-to-end tap flows including both miners.

## build 1 — initial app
Full JS port of the verified Python engine (all protocol subsystems), 5-tab
mobile shell with hash-tape, live ambient economy, nine tappable red-team
drills, ledger tamper/restore, governance, approvals inbox. 77 engine tests +
23-check headless harness — which caught and fixed a real drill-determinism bug
(drills now provision fresh mules) before ship. Two device-only bugs above
shipped anyway; see builds 2–3.

## Python reference (pre-app)
44-requirement SPEC, twelve stdlib modules, 62 tests, machine-checked coverage
audit (44/44), nine adversarial drills held, generated owner dashboard.
