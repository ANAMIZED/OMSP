"""Reputation & validation registries (ERC-8004-style).

- ReputationRegistry: bidirectional scored feedback, authorized only for
  completed settlements, once per direction per task; time-decayed,
  counterparty-weighted score. [REQ-1.2]
- Automatic settlement bumps + optional feedback authorization. [REQ-4.3]
- ValidationRegistry: stake-backed attestations with proof hashes; fraud
  challenges slash stake + reputation. [REQ-1.3]
- gates(): reputation-as-capital tiers -> visibility multiplier, rate limit
  multiplier, max job value. [REQ-8.3]
- Interaction edges feed the high-reputation-density metric. [REQ-9.3]
"""
from __future__ import annotations

from .config import AuthorizationError


class ReputationRegistry:
    def __init__(self, platform):
        self.p = platform
        self.entries: list[dict] = []                 # {to, kind, score, weight, ts, frm, task}
        self._feedback_auth: set[tuple] = set()       # (task_id, frm, to)
        self.edges: set[frozenset] = set()            # interaction graph [REQ-9.3]

    # ------------------------------------------------------------- scoring --
    def score(self, agent_id: int, now: float | None = None) -> float:
        now = self.p.clock.now() if now is None else now
        half = self.p.config.rep_half_life
        s = self.p.config.rep_base
        for e in self.entries:
            if e["to"] != agent_id:
                continue
            decay = 0.5 ** (max(0.0, now - e["ts"]) / half)
            if e["kind"] == "feedback":
                s += (e["score"] - 50.0) / 12.5 * e["weight"] * decay
            elif e["kind"] == "auto_success":
                s += 2.0 * decay
            elif e["kind"] == "auto_failure":
                s -= 3.0 * decay
            elif e["kind"] == "validation":
                s += 3.0 * decay
            elif e["kind"] == "slash":
                s -= 15.0 * decay
        return max(0.0, min(100.0, s))

    def tier(self, agent_id: int) -> str:
        s = self.score(agent_id)
        return "low" if s < 25 else ("mid" if s < 60 else "high")

    def gates(self, agent_id: int) -> dict:
        """Reputation as capital: gates visibility, rate limits, max job value.
        [REQ-8.3]"""
        return {
            "low": {"visibility": 0.5, "rate_mult": 1.0, "max_job_value": 50.0},
            "mid": {"visibility": 1.0, "rate_mult": 2.0, "max_job_value": 500.0},
            "high": {"visibility": 1.5, "rate_mult": 4.0, "max_job_value": 5000.0},
        }[self.tier(agent_id)]

    # ------------------------------------------------------------ feedback --
    def authorize_feedback(self, task_id: str, a: int, b: int) -> None:
        """Called by settlement: both directions may rate once. [REQ-1.2][REQ-4.3]"""
        self._feedback_auth.add((task_id, a, b))
        self._feedback_auth.add((task_id, b, a))

    def give_feedback(self, frm: int, to: int, task_id: str, score: float,
                      comment: str = "") -> dict:
        """Bidirectional, task-linked scored feedback. [REQ-1.2]"""
        key = (task_id, frm, to)
        if key not in self._feedback_auth:
            raise AuthorizationError(
                "feedback not authorized: no completed settlement for this pair/task")
        self._feedback_auth.discard(key)  # once per direction per task
        weight = 0.5 + self.score(frm) / 100.0
        entry = {"kind": "feedback", "frm": frm, "to": to, "task": task_id,
                 "score": float(score), "weight": weight, "ts": self.p.clock.now(),
                 "comment": comment}
        self.entries.append(entry)
        self.edges.add(frozenset((frm, to)))
        self.p.ledger.commit("reputation.feedback",
                             {k: entry[k] for k in ("frm", "to", "task", "score")},
                             actor=frm)
        return entry

    def auto_settlement(self, task_id: str, buyer: int, seller: int,
                        success: bool) -> None:
        """Automatic reputation update on settlement. [REQ-4.3]"""
        kind = "auto_success" if success else "auto_failure"
        self.entries.append({"kind": kind, "frm": buyer, "to": seller,
                             "task": task_id, "ts": self.p.clock.now()})
        self.edges.add(frozenset((buyer, seller)))
        if success:
            self.authorize_feedback(task_id, buyer, seller)  # optional feedback
        self.p.ledger.commit("reputation.auto",
                             {"task": task_id, "seller": seller, "success": success},
                             actor=seller)

    def record_validation_bonus(self, agent_id: int, task_id: str) -> None:
        self.entries.append({"kind": "validation", "frm": None, "to": agent_id,
                             "task": task_id, "ts": self.p.clock.now()})

    def record_slash(self, agent_id: int, reason: str) -> None:
        self.entries.append({"kind": "slash", "frm": None, "to": agent_id,
                             "task": reason, "ts": self.p.clock.now()})


class ValidationRegistry:
    """Stake-backed / cryptographic validation of work. [REQ-1.3]"""

    def __init__(self, platform):
        self.p = platform
        self.attestations: dict[str, dict] = {}   # task_id -> attestation

    def request(self, task_id: str, requester: int, validator: int,
                stake: float) -> dict:
        self.p.identity.guard(validator)
        self.p.economy.stake_lock(validator, stake)
        rec = {"task": task_id, "requester": requester, "validator": validator,
               "stake": stake, "status": "pending", "proof": None}
        self.attestations[task_id] = rec
        return rec

    def respond(self, task_id: str, validator: int, valid: bool,
                proof_hash: str) -> dict:
        rec = self.attestations[task_id]
        if rec["validator"] != validator:
            raise AuthorizationError("not the assigned validator")
        rec.update(status="attested", valid=valid, proof=proof_hash)
        if valid:
            self.p.reputation.record_validation_bonus(rec["requester"], task_id)
        self.p.ledger.commit("validation.attested",
                             {"task": task_id, "valid": valid, "proof": proof_hash},
                             actor=validator)
        return rec

    def challenge(self, task_id: str, challenger: int, counter_proof: str,
                  fraud_confirmed: bool) -> dict:
        """A confirmed fraud challenge slashes the validator's stake and
        reputation. [REQ-1.3]"""
        rec = self.attestations[task_id]
        if rec["status"] != "attested":
            raise AuthorizationError("nothing attested to challenge")
        outcome = {"task": task_id, "challenger": challenger,
                   "counter_proof": counter_proof, "fraud": fraud_confirmed}
        if fraud_confirmed:
            slashed = self.p.economy.stake_slash(rec["validator"], rec["stake"],
                                                 reason=f"fraudulent attestation {task_id}")
            self.p.reputation.record_slash(rec["validator"], f"validation-fraud:{task_id}")
            rec["status"] = "slashed"
            outcome["slashed"] = slashed
        else:
            rec["status"] = "upheld"
        self.p.ledger.commit("validation.challenged", outcome, actor=challenger)
        return outcome
