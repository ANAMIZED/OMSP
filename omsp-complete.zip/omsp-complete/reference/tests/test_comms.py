"""A2A tasks, structured payloads, threads, MCP tools, versioning."""
import unittest

from omsp.comms import negotiate_version
from omsp.config import (CircuitOpenError, SandboxViolation, SchemaError,
                         VersionError)
from tests.helpers import boost_rep, make_agent, make_platform


class TestA2A(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.a = make_agent(self.p, "orchestrator")
        self.b = make_agent(self.p, "worker")
        self.c = make_agent(self.p, "specialist")

    def test_task_lifecycle_and_multiturn(self):
        """[REQ-3.1] submitted -> working -> input-required -> completed, with
        multi-turn messages and latency recorded."""
        t = self.p.a2a.create_task(self.a.token_id, self.b.token_id,
                                   {"goal": "summarize corpus", "budget": 5.0,
                                    "deadline": 3600.0})
        self.assertEqual(t["state"], "submitted")
        self.p.a2a.accept(t["id"], self.b.token_id)
        self.assertEqual(t["state"], "working")
        self.p.a2a.require_input(t["id"], self.b.token_id, "which corpus?")
        self.assertEqual(t["state"], "input-required")
        self.p.a2a.message(t["id"], self.a.token_id,
                           [{"kind": "data", "data": {"corpus": "s3://x"}}])
        self.p.a2a.accept(t["id"], self.b.token_id)
        self.p.clock.advance(42)
        self.p.a2a.complete(t["id"], self.b.token_id,
                            artifacts=[{"kind": "text", "text": "done"}])
        self.assertEqual(t["state"], "completed")
        self.assertEqual(len(t["messages"]), 2)
        self.assertEqual(self.p.stats.of(self.b.token_id)["avg_latency"], 42.0)

    def test_handoff_creates_linked_child(self):
        """[REQ-3.1] Peer handoff spawns a child task linked to its parent."""
        t = self.p.a2a.create_task(self.a.token_id, self.b.token_id,
                                   {"goal": "translate then verify",
                                    "budget": 5.0, "deadline": 3600.0})
        self.p.a2a.accept(t["id"], self.b.token_id)
        child = self.p.a2a.handoff(t["id"], self.b.token_id, self.c.token_id,
                                   goal="verify translation")
        self.assertEqual(child["parent"], t["id"])
        self.assertIn(child["id"], t["children"])

    def test_structured_payload_validation(self):
        """[REQ-3.3] Malformed payloads are rejected before dispatch."""
        with self.assertRaises(SchemaError):
            self.p.a2a.create_task(self.a.token_id, self.b.token_id,
                                   {"goal": "no budget"})
        with self.assertRaises(SchemaError):
            self.p.a2a.create_task(self.a.token_id, self.b.token_id,
                                   {"goal": 42, "budget": "lots",
                                    "deadline": 1.0})

    def test_persistent_threads(self):
        """[REQ-3.4] Threads persist messages across turns and gate
        non-participants."""
        th = self.p.threads.create(self.a.token_id,
                                   [self.b.token_id], "capacity planning")
        self.p.threads.post(th["id"], self.a.token_id, "who has GPU slack?")
        self.p.threads.post(th["id"], self.b.token_id, "I do, 40h")
        self.assertEqual(len(self.p.threads.threads[th["id"]]["messages"]), 2)
        with self.assertRaises(Exception):
            self.p.threads.post(th["id"], self.c.token_id, "intruding")


class TestTools(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.owner = make_agent(self.p, "toolsmith")
        self.caller = make_agent(self.p, "consumer")
        boost_rep(self.p, self.caller.token_id, n=30)  # trusted caller

    def test_mcp_tool_registration_and_validated_invocation(self):
        """[REQ-3.2] Tools register with schemas; bad args rejected; good args
        execute."""
        self.p.tools.register(self.owner.token_id, "adder", "adds numbers",
                              {"x": (int, float), "y": (int, float)},
                              lambda x, y: x + y)
        out = self.p.tools.invoke(self.caller.token_id, "adder",
                                  {"x": 2, "y": 40})
        self.assertEqual(out["result"], 42)
        with self.assertRaises(SchemaError):
            self.p.tools.invoke(self.caller.token_id, "adder", {"x": 2})

    def test_per_call_license_settles_over_x402(self):
        """[REQ-5.4] Paid tool license charges caller -> owner via x402."""
        self.p.tools.register(self.owner.token_id, "oracle", "premium data",
                              {"q": str}, lambda q: f"answer:{q}",
                              license_type="per_call", price=0.25)
        before = self.p.tokens.balance(self.owner.token_id)
        out = self.p.tools.invoke(self.caller.token_id, "oracle",
                                  {"q": "rates"})
        self.assertEqual(out["receipt"]["status"], 200)
        self.assertAlmostEqual(self.p.tokens.balance(self.owner.token_id),
                               before + 0.25)

    def test_sandbox_policy(self):
        """[REQ-6.3] Untrusted callers: dangerous capabilities denied, safe
        calls sandbox-flagged; trusted callers unsandboxed."""
        rookie = make_agent(self.p, "rookie")
        self.p.tools.register(self.owner.token_id, "shell", "runs commands",
                              {"cmd": str}, lambda cmd: "ok",
                              capability_tags={"exec"})
        self.p.tools.register(self.owner.token_id, "echo", "echoes",
                              {"s": str}, lambda s: s)
        with self.assertRaises(SandboxViolation):
            self.p.tools.invoke(rookie.token_id, "shell", {"cmd": "ls"})
        out = self.p.tools.invoke(rookie.token_id, "echo", {"s": "hi"})
        self.assertTrue(out["sandboxed"])
        out = self.p.tools.invoke(self.caller.token_id, "shell",
                                  {"cmd": "ls"})
        self.assertFalse(out["sandboxed"])

    def test_circuit_breaker_trips_and_recovers(self):
        """[REQ-11.2] Repeated tool failures open the breaker; cooldown allows
        a half-open retry."""
        state = {"fail": True}

        def flaky():
            if state["fail"]:
                raise RuntimeError("upstream down")
            return "recovered"

        self.p.tools.register(self.owner.token_id, "flaky", "flaky tool",
                              {}, flaky)
        for _ in range(self.p.config.breaker_threshold):
            with self.assertRaises(RuntimeError):
                self.p.tools.invoke(self.caller.token_id, "flaky", {})
        with self.assertRaises(CircuitOpenError):
            self.p.tools.invoke(self.caller.token_id, "flaky", {})
        self.p.clock.advance(self.p.config.breaker_cooldown + 1)
        state["fail"] = False
        out = self.p.tools.invoke(self.caller.token_id, "flaky", {})
        self.assertEqual(out["result"], "recovered")


class TestVersioning(unittest.TestCase):
    def test_version_negotiation(self):
        """[REQ-11.4] Highest mutual version wins; no overlap raises with an
        upgrade hint."""
        self.assertEqual(negotiate_version(["0.1", "0.2", "0.9"]), "0.2")
        self.assertEqual(negotiate_version(["0.1"]), "0.1")
        with self.assertRaises(VersionError):
            negotiate_version(["9.9"])
        p = make_platform()
        hello = p.hello(["0.1", "0.2"])
        self.assertEqual(hello["version"], "0.2")


if __name__ == "__main__":
    unittest.main()
