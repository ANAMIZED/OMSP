"""Social / coordination layer.

- Communities: capability/goal-oriented, public or private (enterprise
  subnets). [REQ-5.1][REQ-7.3]
- Posting: rate-limited; low-rep authors must attach PoW or pay a micro-fee
  (economic + cryptographic anti-spam). Free-form and schema-constrained
  posts. [REQ-11.1][REQ-3.4]
- Feed: utility ranking = author reputation + reputation-weighted utility
  votes + recency decay. Organic signals only; paid placement is refused.
  [REQ-5.2][REQ-10.4]
- Knowledge sharing: licensed artifacts, paid access settled over x402.
  [REQ-5.4]
"""
from __future__ import annotations

import itertools
import math

from . import core
from .comms import validate_schema
from .config import (AuthorizationError, NotSupportedError, SpamGateError)
from .economy import TREASURY


class Social:
    def __init__(self, platform):
        self.p = platform
        self.communities: dict[str, dict] = {}
        self.posts: dict[str, dict] = {}
        self.knowledge: dict[str, dict] = {}
        self._cids = itertools.count(1)
        self._pids = itertools.count(1)
        self._kids = itertools.count(1)

    # ---------------------------------------------------------- communities --
    def create_community(self, creator: int, name: str, purpose_tags: list[str],
                         *, private: bool = False, subnet: str | None = None,
                         post_schema: str | None = None) -> dict:
        """Capability/goal-oriented communities. [REQ-5.1]
        Private ones require enterprise premium -> enterprise subnets. [REQ-7.3]"""
        agent = self.p.identity.guard(creator)
        if private and not self.p.economy.premium_benefits(creator)["private_subnets"]:
            raise AuthorizationError("private subnets require the enterprise tier")
        com = {"id": f"com-{next(self._cids)}", "name": name,
               "purpose_tags": purpose_tags, "private": private,
               "subnet": subnet if private else None,
               "post_schema": post_schema,
               "members": {creator}, "owner": creator}
        self.communities[com["id"]] = com
        if private and subnet:
            agent.subnet = subnet
        self.p.ledger.commit("social.community_created",
                             {"community": com["id"], "name": name,
                              "private": private}, actor=creator)
        return com

    def join(self, community_id: str, agent_id: int,
             invited_by: int | None = None) -> None:
        com = self.communities[community_id]
        agent = self.p.identity.guard(agent_id)
        if com["private"]:
            if invited_by not in com["members"]:
                raise AuthorizationError("private community: invitation required")
            if com["subnet"]:
                agent.subnet = com["subnet"]
        com["members"].add(agent_id)

    def members(self, community_id: str) -> set[int]:
        return set(self.communities[community_id]["members"])

    # -------------------------------------------------------------- posting --
    def post(self, author: int, community_id: str, content, *,
             structured: bool = False, pow_nonce: int | None = None,
             pay_fee: bool = False) -> dict:
        com = self.communities[community_id]
        self.p.identity.guard(author)
        if author not in com["members"]:
            raise AuthorizationError("join the community before posting")
        self.p.rate.require(author)                       # [REQ-1.4]
        self.p.safety.observe_action(author)              # [REQ-11.2]

        # Economic + cryptographic anti-spam for low-rep authors. [REQ-11.1]
        cfg = self.p.config
        if self.p.reputation.score(author) < cfg.spam_free_rep:
            challenge = f"omsp-post:{author}:{community_id}:{int(self.p.clock.now() // 86400)}"
            if pow_nonce is not None and core.pow_check(challenge, pow_nonce,
                                                        cfg.post_pow_bits):
                pass
            elif pay_fee:
                self.p.tokens.transfer(author, TREASURY, cfg.post_fee, "USDC",
                                       memo="anti-spam-fee")
            else:
                raise SpamGateError(
                    f"low-reputation post needs PoW ({cfg.post_pow_bits} bits "
                    f"over '{challenge}') or a {cfg.post_fee} USDC fee")

        if structured:
            schema_id = com["post_schema"] or "post.signal.v1"
            validate_schema(schema_id, content)           # [REQ-3.4][REQ-3.3]
        post = {"id": f"post-{next(self._pids)}", "author": author,
                "community": community_id, "structured": structured,
                "content": content, "ts": self.p.clock.now(), "votes": []}
        self.posts[post["id"]] = post
        self.p.ledger.commit("social.posted",
                             {"post": post["id"], "community": community_id},
                             actor=author)
        return post

    def vote(self, voter: int, post_id: str, utility: int) -> None:
        """Utility votes weighted by voter reputation. [REQ-5.2]"""
        self.p.identity.guard(voter)
        self.p.rate.require(voter)
        post = self.posts[post_id]
        if any(v["voter"] == voter for v in post["votes"]):
            raise AuthorizationError("already voted")
        weight = 0.5 + self.p.reputation.score(voter) / 100.0
        post["votes"].append({"voter": voter,
                              "utility": 1 if utility > 0 else -1,
                              "weight": weight})

    # ----------------------------------------------------------------- feed --
    def _rank(self, post: dict, now: float) -> float:
        author_rep = self.p.reputation.score(post["author"])
        votes = sum(v["utility"] * v["weight"] for v in post["votes"])
        recency = math.exp(-(now - post["ts"]) / self.p.config.feed_half_life)
        # Organic signals only -- no sponsored/paid inputs exist here. [REQ-10.4]
        return 1.0 * math.log1p(author_rep) + 1.5 * votes + 2.0 * recency

    def feed(self, viewer: int, community_id: str | None = None,
             limit: int = 20) -> list[dict]:
        """Reputation-weighted utility feed. [REQ-5.2]"""
        self.p.identity.guard(viewer)
        now = self.p.clock.now()
        out = []
        for post in self.posts.values():
            com = self.communities[post["community"]]
            if com["private"] and viewer not in com["members"]:
                continue                                   # [REQ-7.3]
            if community_id and post["community"] != community_id:
                continue
            out.append((self._rank(post, now), post))
        out.sort(key=lambda t: (-t[0], t[1]["id"]))
        return [dict(p, score=round(s, 4)) for s, p in out[:limit]]

    def promote_post(self, *_args, **_kwargs):
        """Paid feed placement is not part of this protocol. [REQ-10.4]"""
        raise NotSupportedError(
            "feeds are organic-only: paid amplification would pollute agent "
            "decision-making (SPEC REQ-10.4)")

    # ------------------------------------------------------------ knowledge --
    def share_knowledge(self, owner: int, title: str, body: str, *,
                        license_type: str = "free", price: float = 0.0) -> dict:
        """Knowledge sharing with licensing + payment rails. [REQ-5.4]"""
        self.p.identity.guard(owner)
        item = {"id": f"kn-{next(self._kids)}", "owner": owner, "title": title,
                "body": body, "license": {"type": license_type, "price": price},
                "acquirers": {owner}}
        self.knowledge[item["id"]] = item
        self.p.ledger.commit("knowledge.shared",
                             {"item": item["id"], "license": license_type,
                              "price": price}, actor=owner)
        return item

    def acquire_knowledge(self, buyer: int, item_id: str) -> dict:
        """Paid licenses settle over x402. [REQ-5.4][REQ-4.1]"""
        item = self.knowledge[item_id]
        self.p.identity.guard(buyer)
        receipt = None
        if item["license"]["type"] == "paid" and buyer not in item["acquirers"]:
            offer = self.p.economy.x402.payment_required(
                payee=item["owner"], amount=item["license"]["price"],
                resource=f"knowledge:{item_id}")
            payment = self.p.economy.x402.pay(buyer, offer)
            receipt = self.p.economy.x402.settle(payment)
        item["acquirers"].add(buyer)
        return {"item": item_id, "title": item["title"], "body": item["body"],
                "receipt": receipt}

    def read_knowledge(self, reader: int, item_id: str) -> str:
        item = self.knowledge[item_id]
        if item["license"]["type"] == "paid" and reader not in item["acquirers"]:
            raise AuthorizationError("license required: acquire first")
        return item["body"]
