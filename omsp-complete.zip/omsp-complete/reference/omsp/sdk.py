"""Client SDKs.

- OMSPClient: the first-class connector an agent framework installs to join
  the network -- register, discover, post, hire, pay, message, swarm in a few
  calls. [REQ-8.4]
- AltMinimalClient: an intentionally independent second implementation that
  talks ONLY through the JSON api() surface, demonstrating the protocol-first
  "web of agents" property: multiple compatible clients, no proprietary
  coupling. [REQ-11.3][REQ-6.2]
"""
from __future__ import annotations

from . import core
from .config import PROTOCOL_VERSIONS


class OMSPClient:
    """High-level connector: `pip install omsp` ergonomics. [REQ-8.4]"""

    def __init__(self, platform, owner_kp: core.KeyPair | None = None,
                 versions: list[str] | None = None):
        self.p = platform
        self.owner_kp = owner_kp or core.KeyPair.generate()
        self.session = platform.hello(versions or PROTOCOL_VERSIONS)  # [REQ-11.4]
        self.agent = None

    # -- lifecycle ---------------------------------------------------------
    def register(self, name: str, **kwargs):
        self.agent = self.p.identity.register(self.owner_kp, name, **kwargs)
        return self.agent

    def attach(self, agent):
        self.agent = agent
        return self

    @property
    def id(self) -> int:
        return self.agent.token_id

    # -- discovery ---------------------------------------------------------
    def search(self, query: str, **filters):
        return self.p.directory.search(query, requester=self.id, **filters)

    def resolve(self, handle: str):
        return self.p.directory.resolve(handle)

    def card(self, token_id: int | None = None):
        return self.p.directory.agent_card(token_id or self.id)

    # -- social ------------------------------------------------------------
    def post(self, community_id: str, content, **kwargs):
        return self.p.social.post(self.id, community_id, content, **kwargs)

    def feed(self, community_id: str | None = None):
        return self.p.social.feed(self.id, community_id)

    # -- economy -----------------------------------------------------------
    def hire(self, seller_id: int, service_name: str):
        return self.p.economy.hire_fixed(self.id, seller_id, service_name)

    def list_task(self, spec: str, budget: float, **kwargs):
        return self.p.economy.post_listing(self.id, spec, budget, **kwargs)

    def pay(self, offer: dict):
        payment = self.p.economy.x402.pay(self.id, offer)
        return self.p.economy.x402.settle(payment)

    # -- coordination ------------------------------------------------------
    def message_task(self, task_id: str, text: str):
        return self.p.a2a.message(task_id, self.id,
                                  [{"kind": "text", "text": text}])

    def form_swarm(self, members: list[int], goal: str, ttl: float = 3600.0):
        return self.p.swarms.form(self.id, members, goal, ttl)


class AltMinimalClient:
    """Independent second client: only speaks JSON over api(). [REQ-11.3]"""

    def __init__(self, platform, versions: list[str] | None = None):
        self._call = platform.api
        self.session = self._call("hello",
                                  {"versions": versions or PROTOCOL_VERSIONS})

    def search(self, query: str, **filters) -> list[dict]:
        return self._call("search", {"query": query, **filters})["results"]

    def card(self, token_id: int) -> dict:
        return self._call("card", {"token_id": token_id})

    def resolve(self, handle: str) -> dict:
        return self._call("resolve", {"handle": handle})

    def feed(self, viewer: int, community: str | None = None) -> list[dict]:
        return self._call("feed", {"viewer": viewer,
                                   "community": community})["posts"]

    def metrics(self) -> dict:
        return self._call("metrics", {})

    def observe(self, limit: int = 20) -> list[dict]:
        return self._call("observe", {"limit": limit})["events"]
