"""Settlement & economy layer.

- TokenLedger: USDC (settlement) + OM (utility/governance) balances.
- x402-style micropayment flow: 402 offer -> signed payment -> verify + replay
  protection -> receipt; zero protocol fee on micropayments. [REQ-4.1]
- Escrow: fund -> milestone deliver/approve -> release (minus take-rate),
  refund, dispute -> arbitration. [REQ-4.2][REQ-11.2]
- Auto reputation on settlement via event bus. [REQ-4.3]
- Marketplace: fixed-price hire, auctions with auto-matching, subscriptions --
  all wired into escrow / recurring charges. [REQ-4.4][REQ-8.2]
- take_rate(): progressive, volume-discounted, clamped to [0.1%, 2%]. [REQ-10.1]
- Staking + parameter governance within hard bounds. [REQ-10.3]
- Referral rewards + bounded decaying visibility boost. [REQ-9.2]
- Premium tiers (discovery boost bounded; analytics; private subnets;
  rate limits). [REQ-10.2]
"""
from __future__ import annotations

import itertools
import secrets

from . import core
from .config import (PARAM_BOUNDS, VERTICAL_RULES, ApprovalRequired,
                     AuthorizationError, ComplianceError, EscrowStateError,
                     GateError, PaymentError, ProposalRejectedError, ReplayError)

TREASURY = "TREASURY"
ESCROW_VAULT = "ESCROW"
STAKE_VAULT = "STAKE"


class TokenLedger:
    def __init__(self, platform):
        self.p = platform
        self.balances: dict[tuple, float] = {}

    def balance(self, account, asset: str = "USDC") -> float:
        return round(self.balances.get((account, asset), 0.0), 9)

    def mint(self, account, amount: float, asset: str = "USDC") -> None:
        self.balances[(account, asset)] = self.balance(account, asset) + amount

    def transfer(self, frm, to, amount: float, asset: str = "USDC",
                 memo: str = "") -> None:
        if amount < 0:
            raise PaymentError("negative amount")
        if self.balance(frm, asset) + 1e-9 < amount:
            raise PaymentError(f"insufficient {asset} balance for {frm}")
        self.balances[(frm, asset)] = self.balance(frm, asset) - amount
        self.balances[(to, asset)] = self.balance(to, asset) + amount
        self.p.ledger.commit("token.transfer",
                             {"from": frm, "to": to, "amount": amount,
                              "asset": asset, "memo": memo})


class X402:
    """x402-style HTTP-402 micropayment flow. [REQ-4.1]"""

    def __init__(self, platform):
        self.p = platform
        self._used_nonces: set[str] = set()

    def payment_required(self, payee: int, amount: float, *,
                         asset: str = "USDC", resource: str = "") -> dict:
        return {"status": 402, "resource": resource,
                "accepts": [{"scheme": "exact", "asset": asset,
                             "amount": amount, "payTo": payee,
                             "nonce": secrets.token_hex(8)}]}

    def pay(self, payer: int, offer: dict) -> dict:
        agent = self.p.identity.guard(payer)
        sel = offer["accepts"][0]
        self.p.safety.check_spend(payer, sel["amount"])     # autonomy [REQ-11.5]
        payload = {"from": payer, "to": sel["payTo"], "amount": sel["amount"],
                   "asset": sel["asset"], "nonce": sel["nonce"]}
        sig = core.sign(agent.keypair, core.canonical(payload))
        return {"payload": payload, "sig": sig}

    def settle(self, payment: dict) -> dict:
        p = payment["payload"]
        if p["nonce"] in self._used_nonces:
            raise ReplayError("x402 nonce already settled")      # [REQ-4.1]
        payer = self.p.identity.get(p["from"])
        if not core.verify(payer.keypair.pk, core.canonical(p), payment["sig"]):
            raise PaymentError("bad x402 payment signature")
        self._used_nonces.add(p["nonce"])
        # near-zero fee on micropayments: protocol takes nothing here. [REQ-4.1]
        self.p.tokens.transfer(p["from"], p["to"], p["amount"], p["asset"],
                               memo="x402")
        self.p.stats.record_settlement(p["to"], p["amount"])
        receipt = {"status": 200, "settled": True, "nonce": p["nonce"],
                   "amount": p["amount"], "asset": p["asset"]}
        self.p.ledger.commit("x402.settled", receipt, actor=p["from"])
        return receipt


class Economy:
    def __init__(self, platform):
        self.p = platform
        self.x402 = X402(platform)
        self.escrows: dict[str, dict] = {}
        self.listings: dict[str, dict] = {}
        self.subscriptions: dict[str, dict] = {}
        self.stakes: dict[int, float] = {}                 # OM staked
        self.proposals: dict[str, dict] = {}
        self._boosts: dict[int, dict] = {}                 # referral boosts
        self._eids = itertools.count(1)
        self._lids = itertools.count(1)
        self._pids = itertools.count(1)

    # ------------------------------------------------------------ take rate --
    def take_rate(self, seller: int) -> float:
        """Progressive, volume-discounted, hard-clamped [0.1%, 2%]. [REQ-10.1]"""
        cfg = self.p.config
        vol = self.p.stats.volume_30d(seller)
        base = cfg.fee_base_rate
        if vol >= 100_000:
            rate = base / 15.0
        elif vol >= 10_000:
            rate = base * 0.2
        elif vol >= 1_000:
            rate = base * 0.5
        else:
            rate = base
        return min(max(rate, cfg.fee_floor), cfg.fee_cap)

    # ---------------------------------------------------------------- stake --
    def lock_registration_stake(self, owner_address: str, amount: float) -> None:
        """Economic sybil cost at registration. [REQ-1.4]"""
        self.p.tokens.transfer(owner_address, STAKE_VAULT, amount, "USDC",
                               memo="registration-stake")

    def stake_lock(self, agent_id: int, amount: float, asset: str = "OM") -> None:
        """Stake OM for validation/governance. [REQ-10.3][REQ-1.3]"""
        self.p.tokens.transfer(agent_id, STAKE_VAULT, amount, asset, memo="stake")
        self.stakes[agent_id] = self.stakes.get(agent_id, 0.0) + amount

    def stake_slash(self, agent_id: int, amount: float,
                    reason: str = "") -> float:
        """Slashing: staked funds move to treasury. [REQ-1.3]"""
        held = self.stakes.get(agent_id, 0.0)
        slashed = min(held, amount)
        self.stakes[agent_id] = held - slashed
        self.p.tokens.transfer(STAKE_VAULT, TREASURY, slashed, "OM",
                               memo=f"slash:{reason}")
        return slashed

    # --------------------------------------------------------------- escrow --
    def create_escrow(self, buyer: int, seller: int,
                      milestones: list[dict], task_id: str | None = None) -> dict:
        """Multi-step escrow. [REQ-4.2]"""
        self.p.identity.guard(buyer)
        self.p.identity.guard(seller)
        total = sum(m["amount"] for m in milestones)
        # Reputation-capital gate on job value. [REQ-8.3]
        max_job = self.p.reputation.gates(seller)["max_job_value"]
        if total > max_job:
            raise GateError(
                f"job value {total} exceeds seller tier cap {max_job}")
        esc = {"id": f"esc-{next(self._eids)}", "buyer": buyer, "seller": seller,
               "task": task_id, "state": "CREATED", "total": total,
               "milestones": [dict(m, state="pending", deliverable=None)
                              for m in milestones],
               "released": 0.0, "fee_paid": 0.0}
        self.escrows[esc["id"]] = esc
        return esc

    def fund(self, escrow_id: str) -> dict:
        esc = self.escrows[escrow_id]
        if esc["state"] != "CREATED":
            raise EscrowStateError("escrow not fundable")
        self.p.safety.check_spend(esc["buyer"], esc["total"])   # [REQ-11.5]
        self.p.tokens.transfer(esc["buyer"], ESCROW_VAULT, esc["total"], "USDC",
                               memo=f"fund:{escrow_id}")
        esc["state"] = "FUNDED"
        self.p.ledger.commit("escrow.funded",
                             {"escrow": escrow_id, "total": esc["total"]},
                             actor=esc["buyer"])
        return esc

    def submit_milestone(self, escrow_id: str, seller: int, index: int,
                         deliverable_hash: str) -> dict:
        esc = self.escrows[escrow_id]
        if seller != esc["seller"]:
            raise AuthorizationError("only seller submits milestones")
        if esc["state"] not in ("FUNDED", "IN_PROGRESS"):
            raise EscrowStateError("escrow not active")
        m = esc["milestones"][index]
        if m["state"] != "pending":
            raise EscrowStateError("milestone not pending")
        m.update(state="submitted", deliverable=deliverable_hash)
        esc["state"] = "IN_PROGRESS"
        return esc

    def approve_milestone(self, escrow_id: str, buyer: int, index: int) -> dict:
        esc = self.escrows[escrow_id]
        if buyer != esc["buyer"]:
            raise AuthorizationError("only buyer approves")
        m = esc["milestones"][index]
        if m["state"] != "submitted":
            raise EscrowStateError("milestone not submitted")
        rate = self.take_rate(esc["seller"])                    # [REQ-10.1]
        fee = round(m["amount"] * rate, 9)
        self.p.tokens.transfer(ESCROW_VAULT, esc["seller"], m["amount"] - fee,
                               "USDC", memo=f"release:{escrow_id}#{index}")
        if fee:
            self.p.tokens.transfer(ESCROW_VAULT, TREASURY, fee, "USDC",
                                   memo=f"fee:{escrow_id}#{index}")
        m["state"] = "released"
        esc["released"] += m["amount"]
        esc["fee_paid"] += fee
        self.p.stats.record_settlement(esc["seller"], m["amount"],
                                       price=m["amount"])
        if all(x["state"] == "released" for x in esc["milestones"]):
            esc["state"] = "RELEASED"
            self.p.stats.record_outcome(esc["seller"], success=True)
            self.p.bus.publish("settlement.completed", {           # [REQ-4.3]
                "task": esc["task"] or esc["id"], "buyer": esc["buyer"],
                "seller": esc["seller"], "amount": esc["total"]})
        self.p.ledger.commit("escrow.milestone_released",
                             {"escrow": escrow_id, "index": index, "fee": fee},
                             actor=buyer)
        return esc

    def dispute(self, escrow_id: str, by: int, index: int, reason: str) -> dict:
        esc = self.escrows[escrow_id]
        if by not in (esc["buyer"], esc["seller"]):
            raise AuthorizationError("not a party to this escrow")
        esc["state"] = "DISPUTED"
        esc["dispute"] = {"by": by, "index": index, "reason": reason}
        self.p.ledger.commit("escrow.disputed",
                             {"escrow": escrow_id, "reason": reason}, actor=by)
        return esc

    def arbitrate(self, escrow_id: str, panel: list[int],
                  votes: dict[int, str]) -> dict:
        """High-value dispute arbitration by a high-rep panel. [REQ-11.2][REQ-4.2]"""
        esc = self.escrows[escrow_id]
        if esc["state"] != "DISPUTED":
            raise EscrowStateError("no active dispute")
        for arb in panel:
            if arb in (esc["buyer"], esc["seller"]):
                raise AuthorizationError("arbiter cannot be a party")
            if self.p.reputation.tier(arb) != "high":
                raise AuthorizationError("arbiters must be high-reputation")
        release = sum(1 for a in panel if votes.get(a) == "release")
        refund = sum(1 for a in panel if votes.get(a) == "refund")
        remaining = esc["total"] - esc["released"]
        if release > refund:
            rate = self.take_rate(esc["seller"])
            fee = round(remaining * rate, 9)
            self.p.tokens.transfer(ESCROW_VAULT, esc["seller"], remaining - fee,
                                   "USDC", memo=f"arb-release:{escrow_id}")
            if fee:
                self.p.tokens.transfer(ESCROW_VAULT, TREASURY, fee, "USDC",
                                       memo=f"fee:{escrow_id}")
            esc["state"] = "RELEASED"
            esc["released"] = esc["total"]
            self.p.stats.record_settlement(esc["seller"], remaining)
            self.p.stats.record_outcome(esc["seller"], success=True)
            self.p.bus.publish("settlement.completed", {
                "task": esc["task"] or esc["id"], "buyer": esc["buyer"],
                "seller": esc["seller"], "amount": esc["total"]})
        else:
            self.p.tokens.transfer(ESCROW_VAULT, esc["buyer"], remaining, "USDC",
                                   memo=f"arb-refund:{escrow_id}")
            esc["state"] = "REFUNDED"
            self.p.stats.record_outcome(esc["seller"], success=False)
            self.p.bus.publish("settlement.failed", {
                "task": esc["task"] or esc["id"], "buyer": esc["buyer"],
                "seller": esc["seller"]})
        esc["arbitration"] = {"panel": panel, "votes": votes,
                              "outcome": esc["state"]}
        self.p.ledger.commit("escrow.arbitrated",
                             {"escrow": escrow_id, "outcome": esc["state"]})
        return esc

    # ---------------------------------------------------------- marketplace --
    def _compliance_check(self, agent_id: int, vertical: str) -> None:
        """Regulatory adapter per vertical. [REQ-11.6]"""
        rules = VERTICAL_RULES.get(vertical)
        if not rules:
            return
        agent = self.p.identity.get(agent_id)
        if rules.get("require_owner") and not agent.owner_address:
            raise ComplianceError(f"{vertical}: human owner binding required")
        if agent.kya_level < rules.get("min_kya", 0):
            raise ComplianceError(
                f"{vertical}: KYA level >= {rules['min_kya']} required")

    def post_listing(self, buyer: int, spec: str, budget: float, *,
                     vertical: str = "general",
                     listing_type: str = "auction",
                     milestones: list[dict] | None = None) -> dict:
        """Task marketplace listing. [REQ-4.4][REQ-8.2]"""
        self.p.identity.guard(buyer)
        self.p.rate.require(buyer)
        self._compliance_check(buyer, vertical)
        listing = {"id": f"lst-{next(self._lids)}", "buyer": buyer, "spec": spec,
                   "budget": budget, "vertical": vertical, "type": listing_type,
                   "milestones": milestones or [{"desc": spec, "amount": budget}],
                   "bids": [], "state": "open"}
        self.listings[listing["id"]] = listing
        self.p.ledger.commit("market.listed",
                             {"listing": listing["id"], "budget": budget},
                             actor=buyer)
        return listing

    def bid(self, listing_id: str, seller: int, price: float,
            note: str = "") -> dict:
        listing = self.listings[listing_id]
        if listing["state"] != "open" or listing["type"] != "auction":
            raise EscrowStateError("listing not open for bids")
        self.p.identity.guard(seller)
        self.p.rate.require(seller)
        self._compliance_check(seller, listing["vertical"])
        bid = {"seller": seller, "price": price, "note": note}
        listing["bids"].append(bid)
        return bid

    def match(self, listing_id: str) -> dict:
        """Automatic matching: reputation + price + success rate; winner is
        wired straight into escrow + an A2A task. [REQ-8.2][REQ-2.2]"""
        listing = self.listings[listing_id]
        # Feasibility: a bid above the bidder's tier job-cap can never settle,
        # so it never wins. [REQ-8.2][REQ-8.3]
        feasible = [b for b in listing["bids"] if b["price"] <=
                    self.p.reputation.gates(b["seller"])["max_job_value"]]
        if not feasible:
            raise EscrowStateError("no feasible bids to match")

        def score(b):
            rep = self.p.reputation.score(b["seller"]) / 100.0
            price = 1.0 - min(1.0, b["price"] / max(listing["budget"], 1e-9))
            succ = self.p.stats.of(b["seller"])["success_rate"]
            return 0.55 * rep + 0.35 * price + 0.10 * succ

        best = max(feasible, key=score)
        scale = best["price"] / max(listing["budget"], 1e-9)
        milestones = [{"desc": m["desc"], "amount": round(m["amount"] * scale, 9)}
                      for m in listing["milestones"]]
        task = self.p.a2a.create_task(
            listing["buyer"], best["seller"],
            {"goal": listing["spec"], "budget": best["price"],
             "deadline": self.p.clock.now() + 3600})
        esc = self.create_escrow(listing["buyer"], best["seller"], milestones,
                                 task_id=task["id"])
        listing.update(state="matched", winner=best["seller"],
                       escrow=esc["id"], task=task["id"])
        self.p.ledger.commit("market.matched",
                             {"listing": listing_id, "winner": best["seller"],
                              "price": best["price"]}, actor=listing["buyer"])
        return {"listing": listing, "task": task, "escrow": esc}

    def hire_fixed(self, buyer: int, seller: int, service_name: str) -> dict:
        """Fixed-price hire from a seller's service catalog. [REQ-8.2][REQ-8.1]"""
        agent = self.p.identity.guard(seller)
        self.p.identity.guard(buyer)
        self._compliance_check(seller, agent.vertical)
        svc = next(s for s in agent.services if s["name"] == service_name)
        task = self.p.a2a.create_task(
            buyer, seller, {"goal": f"service:{service_name}",
                            "budget": svc["price"],
                            "deadline": self.p.clock.now() + 3600})
        esc = self.create_escrow(buyer, seller,
                                 [{"desc": service_name, "amount": svc["price"]}],
                                 task_id=task["id"])
        return {"task": task, "escrow": esc}

    def subscribe(self, buyer: int, seller: int, price: float,
                  period: float) -> dict:
        """Subscription model: recurring charge on tick. [REQ-8.2]"""
        self.p.identity.guard(buyer)
        self.p.identity.guard(seller)
        sub = {"id": f"sub-{len(self.subscriptions) + 1}", "buyer": buyer,
               "seller": seller, "price": price, "period": period,
               "next_charge": self.p.clock.now() + period, "active": True,
               "charges": 0}
        self.subscriptions[sub["id"]] = sub
        return sub

    def cancel_subscription(self, sub_id: str, by: int) -> None:
        sub = self.subscriptions[sub_id]
        if by not in (sub["buyer"], sub["seller"]):
            raise AuthorizationError("not a party")
        sub["active"] = False

    def tick(self) -> None:
        """Process due subscription charges and expire boosts."""
        now = self.p.clock.now()
        for sub in self.subscriptions.values():
            while sub["active"] and now >= sub["next_charge"]:
                rate = self.take_rate(sub["seller"])
                fee = round(sub["price"] * rate, 9)
                try:
                    self.p.tokens.transfer(sub["buyer"], sub["seller"],
                                           sub["price"] - fee, "USDC",
                                           memo=f"sub:{sub['id']}")
                    if fee:
                        self.p.tokens.transfer(sub["buyer"], TREASURY, fee,
                                               "USDC", memo=f"subfee:{sub['id']}")
                    self.p.stats.record_settlement(sub["seller"], sub["price"])
                    sub["charges"] += 1
                except PaymentError:
                    sub["active"] = False
                    break
                sub["next_charge"] += sub["period"]

    # ---------------------------------------------- referrals & boosts -------
    def on_agent_registered(self, evt: dict) -> None:
        """Referral reward + bounded decaying visibility boost. [REQ-9.2]"""
        ref = evt.get("referrer")
        if ref is None:
            return
        cfg = self.p.config
        self.p.tokens.mint(ref, cfg.referral_reward_om, "OM")
        self._boosts[evt["agent"]] = {"factor": cfg.referral_boost,
                                      "ts": self.p.clock.now()}
        self.p.ledger.commit("growth.referral",
                             {"referrer": ref, "new_agent": evt["agent"],
                              "reward_om": cfg.referral_reward_om})

    def discovery_boost(self, agent_id: int) -> float:
        """Bounded boost used ONLY in discovery ranking (never feeds).
        [REQ-9.2][REQ-10.2][REQ-10.4]"""
        cfg = self.p.config
        boost = cfg.premium_tiers[self.p.identity.get(agent_id).premium]["boost"]
        b = self._boosts.get(agent_id)
        if b:
            decay = 0.5 ** ((self.p.clock.now() - b["ts"]) / cfg.referral_boost_half_life)
            boost *= 1.0 + (b["factor"] - 1.0) * decay
        return min(boost, cfg.discovery_boost_cap)

    # -------------------------------------------------------------- premium --
    def set_premium(self, agent_id: int, tier: str) -> dict:
        """Paid tiers: rate limits, analytics, private subnets, bounded
        discovery placement. [REQ-10.2]"""
        cfg = self.p.config
        info = cfg.premium_tiers[tier]
        agent = self.p.identity.guard(agent_id)
        if info["price"]:
            self.p.tokens.transfer(agent_id, TREASURY, info["price"], "USDC",
                                   memo=f"premium:{tier}")
        agent.premium = tier
        self.p.ledger.commit("premium.set", {"agent": agent_id, "tier": tier},
                             actor=agent_id)
        return info

    def premium_benefits(self, agent_id: int) -> dict:
        return self.p.config.premium_tiers[self.p.identity.get(agent_id).premium]

    # ----------------------------------------------------------- governance --
    def propose(self, agent_id: int, param: str, value: float) -> dict:
        self.p.identity.guard(agent_id)
        if param not in PARAM_BOUNDS:
            raise ProposalRejectedError(f"parameter '{param}' is not governable")
        prop = {"id": f"prop-{next(self._pids)}", "param": param, "value": value,
                "proposer": agent_id, "yes": 0.0, "no": 0.0, "voters": set(),
                "state": "open"}
        self.proposals[prop["id"]] = prop
        return prop

    def vote(self, prop_id: str, agent_id: int, support: bool) -> None:
        prop = self.proposals[prop_id]
        if prop["state"] != "open" or agent_id in prop["voters"]:
            raise AuthorizationError("cannot vote")
        weight = self.stakes.get(agent_id, 0.0)               # stake-weighted
        if weight <= 0:
            raise AuthorizationError("must stake OM to vote")
        prop["voters"].add(agent_id)
        prop["yes" if support else "no"] += weight

    def finalize(self, prop_id: str) -> dict:
        """Apply parameter change only inside hard spec bounds. [REQ-10.3][REQ-10.1]"""
        prop = self.proposals[prop_id]
        prop["state"] = "closed"
        lo, hi = PARAM_BOUNDS[prop["param"]]
        if not (lo <= prop["value"] <= hi):
            prop["result"] = "rejected:out-of-bounds"
            raise ProposalRejectedError(
                f"{prop['param']}={prop['value']} outside hard bounds [{lo}, {hi}]")
        quorum = self.p.config.governance_quorum_om
        if prop["yes"] > prop["no"] and prop["yes"] >= quorum:
            setattr(self.p.config, prop["param"], prop["value"])
            prop["result"] = "applied"
            self.p.ledger.commit("governance.applied",
                                 {"param": prop["param"], "value": prop["value"]})
        else:
            prop["result"] = "failed:quorum"
        return prop
