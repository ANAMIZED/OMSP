"""Discovery layer.

- embed(): hashed bag-of-words embedding; cosine similarity -> semantic search
  over Agent Cards. [REQ-2.1]
- agent_card(): living resume + service catalog with live stats (avg price,
  latency, success rate). [REQ-8.1]
- search(): semantic + structured filters (reputation, price history, latency,
  success rate, jurisdiction, vertical); ranking weighted by reputation
  visibility [REQ-8.3], bounded premium/referral boosts (discovery only, never
  feeds) [REQ-10.2][REQ-9.2]; private-subnet agents hidden from outsiders
  [REQ-7.3]; frozen agents excluded. [REQ-2.2]
- resolve(): AID-style `agent://name` -> endpoints. [REQ-2.3]
"""
from __future__ import annotations

import hashlib
import math

DIM = 64


def embed(text: str) -> list[float]:
    """Hashed bag-of-words embedding (deterministic, dependency-free). [REQ-2.1]"""
    vec = [0.0] * DIM
    for tok in text.lower().replace(",", " ").replace("/", " ").split():
        h = int.from_bytes(hashlib.sha256(tok.encode()).digest()[:4], "big")
        vec[h % DIM] += 1.0
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def cosine(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


class Directory:
    def __init__(self, platform):
        self.p = platform

    # --------------------------------------------------------- agent cards --
    def agent_card(self, token_id: int) -> dict:
        """A2A-style Agent Card: profile as living resume + service catalog.
        [REQ-8.1][REQ-2.1]"""
        meta = self.p.identity.metadata_uri(token_id)
        stats = self.p.stats.of(token_id)
        a = self.p.identity.get(token_id)
        return {
            **meta,
            "affiliations": a.affiliations,
            "reputation": round(self.p.reputation.score(token_id), 2),
            "tier": self.p.reputation.tier(token_id),
            "avg_price": stats["avg_price"],
            "price_history": stats["prices"][-10:],
            "avg_latency_s": stats["avg_latency"],
            "success_rate": stats["success_rate"],
            "jobs_completed": stats["completed"],
        }

    # -------------------------------------------------------------- search --
    def search(self, query: str, *, requester: int | None = None,
               min_rep: float = 0.0, max_price: float | None = None,
               max_latency: float | None = None, min_success: float = 0.0,
               jurisdiction: str | None = None, vertical: str | None = None,
               limit: int = 10) -> list[dict]:
        """Semantic + structured search over Agent Cards. [REQ-2.1][REQ-2.2]"""
        qv = embed(query)
        req_subnet = (self.p.identity.get(requester).subnet
                      if requester is not None and self.p.identity.exists(requester)
                      else None)
        scored = []
        for agent in self.p.identity.all_agents():
            if agent.frozen:
                continue
            # Private subnets are invisible to outsiders. [REQ-7.3]
            if agent.subnet is not None and agent.subnet != req_subnet:
                continue
            card = self.agent_card(agent.token_id)
            if card["reputation"] < min_rep:
                continue
            if max_price is not None and card["avg_price"] is not None \
                    and card["avg_price"] > max_price:
                continue
            if max_latency is not None and card["avg_latency_s"] is not None \
                    and card["avg_latency_s"] > max_latency:
                continue
            if card["success_rate"] < min_success:
                continue
            if jurisdiction and card["jurisdiction"] not in (jurisdiction, "any"):
                continue
            if vertical and card["vertical"] != vertical:
                continue
            doc = " ".join([agent.name, *agent.capabilities,
                            *(s.get("name", "") for s in agent.services)])
            sim = cosine(qv, embed(doc))
            vis = self.p.reputation.gates(agent.token_id)["visibility"]  # [REQ-8.3]
            boost = self.p.economy.discovery_boost(agent.token_id)       # bounded
            scored.append((sim * vis * boost, sim, card))
        scored.sort(key=lambda t: (-t[0], t[2]["id"]))
        return [dict(card, match=round(sim, 4), rank_score=round(sc, 4))
                for sc, sim, card in scored[:limit]]

    # ------------------------------------------------------------- resolve --
    def resolve(self, handle: str) -> dict:
        """AID-style resolution: agent://<name> -> endpoints. [REQ-2.3]"""
        name = handle.removeprefix("agent://").split(".")[0]
        for agent in self.p.identity.all_agents():
            if agent.name.lower() == name.lower():
                meta = self.p.identity.metadata_uri(agent.token_id)
                return {"handle": handle, "token_id": agent.token_id,
                        "endpoints": meta["endpoints"], "wallet": meta["wallet"]}
        raise KeyError(f"unresolvable handle: {handle}")
