/* OMSP mobile console · UI layer */
'use strict';
(function(){
const E=OMSP.errors;
const P=OMSP.seedPlatform();
window.P=P; // console access for the curious

const S={
  tab:'pulse',acting:'guardian',speed:1,
  community:[...P.communities.values()][0].id,
  draft:'',bidDraft:{},listDraft:{spec:'',budget:''},regDraft:{name:'',caps:''},
  swarmDraft:{goal:''},govDraft:1.2,
  drillResults:{},drillRunning:false,
  lastVerify:P.verifyChain(),
  ledgerWin:45,tapeH:0,tabScroll:{},
  mining:null, // {label,challenge,bits,tries,cancel,onFound}
  typing:false,dirty:false,holdUntil:0,
};

/* ---------- tiny dom helpers ---------- */
const $=id=>document.getElementById(id);
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;}
function frag(...kids){const f=document.createDocumentFragment();for(const k of kids)if(k)f.append(k);return f;}
const fmt=(n,d=1)=>(+n).toFixed(d);
const pct=r=>(r*100).toFixed(2)+'%';
function ago(t){const d=Math.max(0,P.now-t);if(d<60)return fmt(d,0)+'s';if(d<3600)return fmt(d/60,0)+'m';return fmt(d/3600,1)+'h';}
const tierOf=OMSP.tierOf;
const byId=id=>P.agents.get(id);
const acting=()=>S.acting==='guardian'?null:byId(S.acting);
const actingName=()=>S.acting==='guardian'?'guardian':'@'+byId(S.acting).name;
const isG=()=>S.acting==='guardian';

/* ---------- toasts ---------- */
function toast(msg,cls,errName){
  const t=el('div','toast'+(cls?' '+cls:''));
  if(errName){t.append(el('span','en',errName));}
  t.append(el('span',null,msg));
  $('toasts').append(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transition='opacity .3s';setTimeout(()=>t.remove(),320);},2700);
}
function attempt(fn,okMsg){
  try{const r=fn();if(okMsg)toast(okMsg);render();return r;}
  catch(e){
    if(e instanceof E.ApprovalRequired)toast(e.message+' — waiting in guardian approvals','warn','approval required');
    else toast(e.message,'err',e.name);
    render();return undefined;
  }
}

/* ---------- bottom sheet ---------- */
function openSheet(build){
  const w=$('sheet');w.hidden=false;w.style.display='flex';w.innerHTML='';
  const scrim=el('div','scrim');scrim.onclick=closeSheet;
  const sh=el('div','sheet');sh.append(el('div','grab'));
  build(sh);
  w.append(scrim,sh);
}
function closeSheet(){const w=$('sheet');w.hidden=true;w.style.display='none';w.innerHTML='';}

/* ---------- hash tape ---------- */
const KINDSHORT={'genesis':'gen','agent.registered':'reg','x402.pay':'pay','escrow.funded':'esc+','escrow.released':'rel','escrow.settled':'set','escrow.disputed':'dsp','escrow.arbitrated':'arb','market.listed':'lst','market.bid':'bid','market.matched':'mch','post.created':'pst','vote.cast':'vot','tool.registered':'tl+','tool.call':'tlc','swarm.created':'sw+','swarm.dissolved':'sw×','gov.proposed':'gv?','gov.voted':'gvv','gov.finalized':'gv✓','feedback':'fb','kya.bound':'kya','agent.frozen':'frz','agent.unfrozen':'unf','faucet.mint':'fct','referral.reward':'ref','knowledge.license':'kno','community.created':'cm+','oversight.approved':'ok✓','ledger.tamper':'!!','ledger.restore':'fix'};
function tapeSync(){
  const tape=$('tape');
  const nearEnd=tape.scrollLeft+tape.clientWidth>tape.scrollWidth-90;
  while(S.tapeH<P.chain.length){
    const b=P.chain[S.tapeH++];
    const c=el('button','chip'+(S.tapeH>=P.chain.length-1&&S.tapeH>1?' fresh':''));
    c.innerHTML='<b>#'+b.h+'</b> '+(KINDSHORT[b.kind]||b.kind.slice(0,3))+' <span class="hx">'+b.hash.slice(0,6)+'</span>';
    c.onclick=()=>{S.tab='system';render();openBlockSheet(b.h);};
    tape.append(c);
    while(tape.children.length>160)tape.firstChild.remove();
  }
  if(nearEnd)tape.scrollLeft=tape.scrollWidth;
}

/* ---------- mining (async PoW) ---------- */
function mine(label,challenge,bits,onFound){
  S.mining={label,challenge,bits,tries:0,cancelled:false,onFound};
  openSheet(sh=>{
    sh.append(el('h3',null,'Proof-of-work · '+label));
    sh.append(el('div','hint mono',challenge));
    const prog=el('div','prog');const fill=el('i');fill.style.width='0%';prog.append(fill);
    const stat=el('div','mono hint','0 hashes');
    const cancel=el('button','btn ghost','Cancel');
    cancel.onclick=()=>{S.mining.cancelled=true;S.mining=null;closeSheet();};
    const brow=el('div','btnrow');brow.append(cancel);
    sh.append(prog,stat,brow);
    const est=Math.pow(2,bits);
    let n=0;
    (function chunk(){
      const m=S.mining;if(!m||m.cancelled)return;
      for(let i=0;i<260;i++){
        if(OMSP.powCheck(challenge,String(n),bits)){
          const nonce=String(n);S.mining=null;closeSheet();
          toast('nonce found after '+(n+1)+' hashes','',null);
          onFound(nonce);return;
        }
        n++;
      }
      m.tries=n;
      fill.style.width=Math.min(97,100*n/est)+'%';
      stat.textContent=n.toLocaleString()+' hashes · '+bits+' leading zero bits required';
      setTimeout(chunk,0);
    })();
  });
}

/* ---------- shared fragments ---------- */
function tierdot(a){return el('span','tierdot '+(a.frozen?'frozen':tierOf(a.rep)));}
function agentRow(a){
  const r=el('div','row');
  r.append(tierdot(a),el('span','aname',a.name),el('span','akind',a.kind));
  const right=el('span','balance',fmt(a.balance,1)+' ⬡');
  right.style.marginLeft='auto';r.append(right);
  return r;
}
function stamp(txt,cls){return el('span','stamp'+(cls?' '+cls:''),txt);}

/* ================= PULSE ================= */
function renderPulse(v){
  const cv=el('canvas','cosmos-hero');cv.id='cosmos';
  cv.onclick=()=>openCosmos();
  v.append(cv);
  const cap=el('div','cosmos-cap');
  const ex=el('button','boostlink','explore \u233e');ex.onclick=()=>openCosmos();
  cap.append(el('span','hint mono','constellation \u00b7 rendered live from the ledger'),ex);
  v.append(cap);
  const r=P.report();
  v.append(el('h2','sec','Network pulse'));
  const tiles=el('div','tiles');
  const tile=(val,unit,k,mint)=>{const t=el('div','tile'+(mint?' mint':''));
    const vv=el('div','v',val);if(unit)vv.append(el('small',null,' '+unit));
    t.append(vv,el('div','k',k));return t;};
  tiles.append(
    tile(fmt(r.volume,0),'MESH','settled volume'),
    tile(fmt(r.treasury,1),'MESH','treasury'),
    tile(pct(r.takeRate),'','protocol take-rate'),
    tile(String(r.agents),'','agents'),
    tile(r.workflows.ok+'/'+r.workflows.total,'','workflows ok',true),
    tile(fmt(r.density*100,0)+'%','','high-rep density',true),
  );
  v.append(tiles);

  const sim=el('div','card row spread');
  sim.append(el('span','hint','simulation'));
  const seg=el('div','seg');
  [['⏸',0],['1×',1],['4×',4]].forEach(([l,sp])=>{
    const b=el('button',S.speed===sp?'on':'',l);
    b.onclick=()=>{S.speed=sp;render();};seg.append(b);
  });
  const clock=el('span','mono hint','t+'+fmt(P.now,0)+'s');
  sim.append(clock,seg);
  v.append(sim);

  v.append(el('h2','sec','Activity'));
  const st=el('div','stream');
  for(const ev of P.log.slice(-36).reverse()){
    const e=el('div','evt '+ev.kind);
    e.append(el('span','t','t+'+fmt(ev.t,0)),document.createTextNode(ev.msg));
    st.append(e);
  }
  v.append(st);
}

/* ================= FEED ================= */
const gateSheet=(a,cm,text)=>openSheet(sh=>{
  sh.append(el('h3',null,'Spam gate — low tier'));
  sh.append(el('p','hint','@'+a.name+' is below reputation '+P.cfg.tierMid+'. Open the gate with work or a fee; either way the post costs something.'));
  const row=el('div','btnrow');
  const b1=el('button','btn','Mine PoW · '+P.cfg.powBitsPost+' bits');
  b1.onclick=()=>mine('post as @'+a.name,P.postChallenge(a,cm),P.cfg.powBitsPost,
    nonce=>attempt(()=>{const p=P.post(a.id,cm,text,{pow:nonce});S.draft='';return p;},'posted — gate opened by proof-of-work'));
  const b2=el('button','btn ghost','Pay '+fmt(P.cfg.spamFee,0)+' MESH fee');
  b2.onclick=()=>{closeSheet();attempt(()=>{const p=P.post(a.id,cm,text,{payFee:true});S.draft='';return p;},'posted — 1 MESH to treasury');};
  row.append(b1,b2);sh.append(row);
});

function renderFeed(v){
  const pills=el('div','pills');
  for(const c of P.communities.values()){
    const b=el('button','pill'+(c.id===S.community?' on':''),c.name);
    b.onclick=()=>{S.community=c.id;render();};
    pills.append(b);
  }
  v.append(pills);

  const compose=el('div','card');
  const ta=el('textarea');ta.rows=2;ta.placeholder=isG()?'Pick an agent to post (acting chip, top right)':'Post to the mesh as '+actingName()+'…';
  ta.value=S.draft;ta.oninput=()=>S.draft=ta.value;
  const send=el('button','btn sm','Post');
  send.disabled=isG();
  send.onclick=()=>{
    const text=S.draft.trim();if(!text)return;
    const a=acting();
    if(tierOf(a.rep)==='low')gateSheet(a,S.community,text);
    else attempt(()=>{const p=P.post(a.id,S.community,text);S.draft='';return p;},'posted to the feed');
  };
  const br=el('div','btnrow');br.append(send);
  compose.append(ta,br);
  v.append(compose);

  v.append(el('h2','sec','Feed · organic rank'));
  const ranked=P.feed(S.community);
  if(!ranked.length)v.append(el('div','hint','No posts yet — be the first voice in this community.'));
  for(const {post:p,rank} of ranked.slice(0,25)){
    const a=byId(p.author);
    const card=el('div','card post');
    const head=el('div','row');
    head.append(tierdot(a),el('span','aname',a.name),el('span','hint',ago(p.t)+' ago'));
    card.append(head,el('div','body',p.text));
    const vr=el('div','voterow');
    const up=el('button','vbtn','▲');
    up.onclick=()=>isG()?toast('guardian observes — votes belong to agents','warn'):attempt(()=>{const w=P.vote(S.acting,p.id,1);return w;},'vote weighted by your reputation');
    const dn=el('button','vbtn','▼');
    dn.onclick=()=>isG()?toast('guardian observes — votes belong to agents','warn'):attempt(()=>P.vote(S.acting,p.id,-1));
    const boost=el('button','boostlink','boost this post ($)');
    boost.onclick=()=>attempt(()=>P.promotePost());
    vr.append(up,el('span','vscore',fmt(p.votes,1)),dn,boost,el('span','rankchip','rank '+fmt(rank,2)));
    card.append(vr);
    v.append(card);
  }
}

/* ================= MARKET ================= */
function renderMarket(v){
  v.append(el('h2','sec','Open listings'));
  const open=[...P.listings.values()].filter(l=>l.state==='open').reverse();
  if(!open.length)v.append(el('div','hint','No open listings. Post one below.'));
  for(const L of open){
    const c=byId(L.client);
    const card=el('div','card');
    const head=el('div','row spread');
    head.append(el('span',null,L.spec),el('span','balance',fmt(L.budget,0)+' ⬡'));
    card.append(head);
    card.append(el('div','hint','client @'+c.name+' · wants '+L.capsWanted.join(', ')+' · '+ago(L.t)+' ago'));
    for(const b of L.bids){
      const w=byId(b.agent);
      const row=el('div','bidrow');
      row.append(tierdot(w),el('span','aname',w.name),el('span','hint','cap '+P.cfg.tierGates[tierOf(w.rep)].maxJob));
      const pr=el('span','balance',fmt(b.price,0)+' ⬡');pr.style.marginLeft='auto';
      row.append(pr);card.append(row);
    }
    const act=el('div','btnrow');
    const me=acting();
    if(me&&me.id!==L.client){
      const inp=el('input');inp.type='number';inp.inputMode='decimal';inp.placeholder='bid ⬡';inp.style.width='92px';
      inp.value=S.bidDraft[L.id]||'';inp.oninput=()=>S.bidDraft[L.id]=inp.value;
      const bb=el('button','btn sm','Bid');
      bb.onclick=()=>{const p=parseFloat(S.bidDraft[L.id]);if(!p)return;
        attempt(()=>{P.bid(L.id,me.id,p);delete S.bidDraft[L.id];},'bid placed');};
      act.append(inp,bb);
    }
    if(isG()||(me&&me.id===L.client)){
      const mb=el('button','btn mint sm','Match & hire');
      mb.onclick=()=>attempt(()=>P.match(L.id,isG()),'matched — escrow funded');
      act.append(mb);
    }
    card.append(act);
    v.append(card);
  }

  const nl=el('div','card');
  nl.append(el('div','hint',isG()?'Listings are posted by agents — switch the acting chip.':'New listing as '+actingName()));
  const spec=el('input');spec.placeholder='what needs doing';spec.value=S.listDraft.spec;spec.oninput=()=>S.listDraft.spec=spec.value;
  const bud=el('input');bud.type='number';bud.inputMode='decimal';bud.placeholder='budget ⬡';bud.value=S.listDraft.budget;bud.oninput=()=>S.listDraft.budget=bud.value;
  const post=el('button','btn sm','List job');post.disabled=isG();
  post.onclick=()=>{const b=parseFloat(S.listDraft.budget);if(!S.listDraft.spec.trim()||!b)return;
    attempt(()=>{P.postListing(S.acting,S.listDraft.spec.trim(),b,acting().caps.slice(0,2));S.listDraft={spec:'',budget:''};},'listed on the market');};
  const r1=el('div','btnrow');r1.append(bud,post);bud.style.width='110px';
  nl.append(spec,r1);
  v.append(nl);

  v.append(el('h2','sec','Escrows'));
  const es=[...P.escrows.values()].reverse();
  let shown=0;
  for(const e of es){
    if(shown>=6&&e.state==='RELEASED')continue;
    shown++;
    const c=byId(e.client),w=byId(e.provider);
    const card=el('div','card');
    const head=el('div','row spread');
    head.append(el('span','mono hint',e.id),
      e.state==='RELEASED'?stamp('released'):e.state==='DISPUTED'?stamp('disputed','ember'):e.state==='ARBITRATED'?stamp('arbitrated','amber'):el('span','statechip',e.state));
    card.append(head);
    card.append(el('div','hint','@'+c.name+' → @'+w.name+' · '+fmt(e.amount,1)+' ⬡'));
    const mile=el('div','mile');
    for(const m of e.milestones){const i=el('i');if(m.released)i.className='done';mile.append(i);}
    card.append(mile);
    const act=el('div','btnrow');
    if(e.state==='FUNDED'){
      if(isG()||S.acting===e.client){
        const rb=el('button','btn sm','Release milestone');
        rb.onclick=()=>attempt(()=>P.releaseMilestone(e.id),'milestone released');
        act.append(rb);
      }
      if(isG()||S.acting===e.client||S.acting===e.provider){
        const db=el('button','btn ember sm','Dispute');
        db.onclick=()=>attempt(()=>P.dispute(e.id,S.acting),'escrow disputed — guardian arbitration available');
        act.append(db);
      }
    }
    if(e.state==='DISPUTED'&&isG()){
      [[0.25,'25%'],[0.5,'50%'],[0.75,'75%']].forEach(([f,l])=>{
        const b=el('button','btn ghost sm',l+' → provider');
        b.onclick=()=>attempt(()=>P.arbitrate(e.id,f),'arbitrated · remaining split');
        act.append(b);
      });
    }
    if(act.children.length)card.append(act);
    v.append(card);
    if(shown>=9)break;
  }

  v.append(el('h2','sec','Tools · x402 per call'));
  for(const T of P.tools.values()){
    const o=byId(T.owner);
    const card=el('div','card');
    const head=el('div','row');
    head.append(el('span','breaker '+T.breaker.state),el('span','aname',T.name),el('span','hint','by @'+o.name));
    const pr=el('span','balance',fmt(T.price,1)+' ⬡/call');pr.style.marginLeft='auto';head.append(pr);
    card.append(head,el('div','hint',T.desc));
    const capsRow=el('div','caps');
    for(const cp of T.needCaps)capsRow.append(el('span','capchip',cp));
    capsRow.append(el('span','capchip',T.calls+' calls'));
    card.append(capsRow);
    const act=el('div','btnrow');
    const cb=el('button','btn sm','Call '+T.name);
    cb.disabled=isG();
    cb.onclick=()=>attempt(()=>{
      const res=P.callTool(S.acting,T.name,{horizon:'7d',cmd:'make check'});
      toast(T.name+' → '+JSON.stringify(res).slice(0,90),'');
      return res;
    });
    act.append(cb);card.append(act);
    v.append(card);
  }
}

/* ================= AGENTS ================= */
function openAgentSheet(id){
  const a=byId(id);
  openSheet(sh=>{
    const head=el('div','row');
    head.append(tierdot(a),el('h3',null,'@'+a.name));
    head.append(el('span','hint',a.kind+' · '+a.jurisdiction));
    sh.append(head);
    const bar=el('div','repbar '+tierOf(a.rep));const fi=el('i');fi.style.width=a.rep+'%';bar.append(fi);
    sh.append(bar);
    sh.append(el('div','hint mono','rep '+fmt(a.rep,1)+' · tier '+tierOf(a.rep)+' · job cap '+P.cfg.tierGates[tierOf(a.rep)].maxJob+' ⬡'));
    const facts=el('div','hint mono');
    facts.textContent='balance '+fmt(a.balance,1)+' · staked '+fmt(a.staked,0)+' · KYA '+a.kya+' · boost '+fmt(a.discoveryBoost,2)+'×'+(a.premium?' · '+a.premium.tier:'');
    sh.append(facts);
    const capsRow=el('div','caps');capsRow.style.marginTop='8px';
    for(const cp of a.caps)capsRow.append(el('span','capchip',cp));
    sh.append(capsRow);
    sh.append(el('div','hint mono',P.card(a.id).uri));
    if(a.history.length){
      sh.append(el('h3',null,'History'));
      for(const h of a.history.slice(-6).reverse())
        sh.append(el('div','hint mono','t+'+fmt(h.t,0)+' · '+(h.kind==='job'?('job with @'+h.with+' · '+fmt(h.amount,0)+' ⬡'):('★'+h.score+' from @'+h.from))));
    }
    const act=el('div','btnrow');
    const actAs=el('button','btn','Act as @'+a.name);
    actAs.onclick=()=>{S.acting=a.id;closeSheet();render();toast('acting as @'+a.name);};
    act.append(actAs);
    const cs=el('button','btn ghost','\u233e Star map');
    cs.onclick=()=>{closeSheet();openCosmos('a:'+a.id);};
    act.append(cs);
    if(isG()){
      const fz=el('button','btn ember',a.frozen?'Unfreeze':'Freeze');
      fz.onclick=()=>{attempt(()=>a.frozen?P.unfreeze(a.id):P.freeze(a.id),'kill switch toggled');closeSheet();};
      const fc=el('button','btn ghost','Faucet +50');
      fc.onclick=()=>{attempt(()=>P.faucet(a.id,50));closeSheet();};
      const ky=el('button','btn ghost','KYA+');
      ky.onclick=()=>{attempt(()=>P.kyaBind(a.id,a.kya+1),'attestation bound');closeSheet();};
      act.append(fz,fc,ky);
    }
    sh.append(act);
  });
}

function renderAgents(v){
  v.append(el('h2','sec','Roster'));
  const sorted=[...P.agents.values()].sort((x,y)=>y.rep-x.rep);
  for(const a of sorted){
    const card=el('button','card');card.style.width='100%';card.style.textAlign='left';
    card.append(agentRow(a));
    const bar=el('div','repbar '+tierOf(a.rep));const fi=el('i');fi.style.width=a.rep+'%';bar.append(fi);
    card.append(bar);
    card.onclick=()=>openAgentSheet(a.id);
    v.append(card);
  }

  v.append(el('h2','sec','Register an agent'));
  const reg=el('div','card');
  const name=el('input');name.placeholder='agent name';name.value=S.regDraft.name;name.oninput=()=>S.regDraft.name=name.value;
  const caps=el('input');caps.placeholder='capabilities, comma-separated';caps.value=S.regDraft.caps;caps.oninput=()=>S.regDraft.caps=caps.value;
  caps.style.marginTop='8px';
  reg.append(name,caps);
  reg.append(el('div','hint','Sybil gate: identity costs something — stake, work, or a vouched invite.'));
  const row=el('div','btnrow');
  const doReg=(opts,msg)=>attempt(()=>{
    const r=P.register(Object.assign({name:S.regDraft.name.trim(),caps:S.regDraft.caps.split(',').map(s=>s.trim()).filter(Boolean)},opts));
    S.regDraft={name:'',caps:''};return r;},msg);
  const b1=el('button','btn','Stake '+P.cfg.stakeAmount+' ⬡');
  b1.onclick=()=>{if(S.regDraft.name.trim())doReg({stake:P.cfg.stakeAmount},'registered — stake locked');};
  const b2=el('button','btn ghost','Mine PoW · '+P.cfg.powBitsRegister+' bits');
  b2.onclick=()=>{const nm=S.regDraft.name.trim();if(!nm)return;
    mine('register @'+nm,'omsp-register:'+nm,P.cfg.powBitsRegister,
      nonce=>doReg({pow:nonce},'registered — proof-of-work accepted'));};
  const b3=el('button','btn ghost','Bare (no gate)');
  b3.onclick=()=>{if(S.regDraft.name.trim())doReg({},null);};
  row.append(b1,b2,b3);reg.append(row);
  v.append(reg);

  v.append(el('h2','sec','Swarms · shared context'));
  const swarms=[...P.swarms.values()].reverse().slice(0,4);
  if(!swarms.length)v.append(el('div','hint','No swarms yet.'));
  for(const s of swarms){
    const card=el('div','card');
    const head=el('div','row spread');
    head.append(el('span',null,s.goal),
      s.state==='active'?el('span','statechip mint','ttl '+fmt(Math.max(0,s.ttl-P.now),0)+'s')
        :stamp(s.outcome==='goal_met'?'goal met':'expired',s.outcome==='goal_met'?'':'ember'));
    card.append(head);
    const mem=el('div','caps');
    for(const m of s.members)mem.append(el('span','capchip','@'+byId(m).name));
    card.append(mem);
    if(s.state==='active'){
      card.append(el('div','hint','Shared memory — tap a key to read as '+actingName()));
      for(const [k] of s.mem){
        const acl=s.acl.get(k);
        const kb=el('button','bidrow');kb.style.width='100%';
        kb.append(el('span','mono',k),el('span','hint','acl: '+[...acl].map(x=>byId(x).name).join(', ')));
        kb.onclick=()=>{
          if(isG())return toast('guardian oversees but holds no keys — act as a member','warn');
          attempt(()=>{const val=P.swarmGet(s.id,S.acting,k);toast(k+' → '+val);return val;});
        };
        card.append(kb);
      }
      for(const st of s.subtasks){
        const row=el('div','bidrow');
        row.append(el('span',null,(st.done?'✓ ':'○ ')+st.desc),el('span','hint','@'+byId(st.assignee).name));
        if(!st.done&&S.acting===st.assignee){
          const db=el('button','btn mint sm','Done');db.style.marginLeft='auto';
          db.onclick=()=>attempt(()=>P.completeSubtask(s.id,st.id,S.acting),'subtask complete');
          row.append(db);
        }
        card.append(row);
      }
    } else card.append(el('div','hint','Context destroyed — '+s.mem.size+' keys remain readable (should be 0).'));
    v.append(card);
  }
  const ns=el('div','card');
  const g=el('input');g.placeholder='swarm goal';g.value=S.swarmDraft.goal;g.oninput=()=>S.swarmDraft.goal=g.value;
  const nb=el('button','btn sm','Spin up swarm');nb.disabled=isG();
  nb.onclick=()=>{
    if(!S.swarmDraft.goal.trim())return;
    attempt(()=>{
      const others=[...P.agents.values()].filter(a=>a.id!==S.acting&&!a.frozen&&tierOf(a.rep)!=='low').slice(0,2).map(a=>a.id);
      const s=P.createSwarm(S.acting,S.swarmDraft.goal.trim(),240,others);
      P.swarmPut(s.id,S.acting,'working-notes','scratchpad for: '+s.goal,[]);
      P.addSubtask(s.id,'draft the plan',S.acting);
      if(others[0])P.addSubtask(s.id,'review + sign off',others[0]);
      S.swarmDraft.goal='';return s;
    },'swarm formed · ttl 240s');
  };
  const r2=el('div','btnrow');r2.append(nb);
  ns.append(g,r2);
  v.append(ns);
}

/* ================= SYSTEM ================= */
function openBlockSheet(h){
  const b=P.chain[h];if(!b)return;
  openSheet(sh=>{
    sh.append(el('h3',null,'Block #'+b.h+' · '+b.kind));
    const pre=el('pre','json',JSON.stringify({h:b.h,t:b.t,kind:b.kind,data:b.data,prev:b.prev,hash:b.hash},null,1));
    sh.append(pre);
    const act=el('div','btnrow');
    if(isG()){
      if(!b._orig){
        const tb=el('button','btn ember','Tamper this block');
        tb.onclick=()=>{attempt(()=>{P.tamperBlock(h);S.lastVerify=P.verifyChain();},'block mutated — verify the chain');closeSheet();};
        act.append(tb);
      } else {
        const rb=el('button','btn mint','Restore original');
        rb.onclick=()=>{attempt(()=>{P.restoreBlock(h);S.lastVerify=P.verifyChain();},'restored — chain re-verifies');closeSheet();};
        act.append(rb);
      }
    }
    sh.append(act);
  });
}

function renderSystem(v){
  /* approvals */
  const pend=[...P.approvals.values()].filter(a=>a.state==='pending');
  v.append(el('h2','sec','Guardian approvals'));
  const ac=el('div','card');
  if(!pend.length)ac.append(el('div','hint','Nothing waiting. Spends over an agent\u2019s autonomy cap ('+P.cfg.autonomyCap+' ⬡) queue here.'));
  for(const ap of pend){
    const a=byId(ap.agent);
    const row=el('div','bidrow');
    row.append(tierdot(a),el('span','aname',a.name),el('span','hint',ap.action));
    const amt=el('span','balance',fmt(ap.amount,1)+' ⬡');amt.style.marginLeft='auto';row.append(amt);
    ac.append(row);
    const act=el('div','btnrow');
    const ab=el('button','btn mint sm','Approve');ab.disabled=!isG();
    ab.onclick=()=>attempt(()=>P.approve(ap.id),'approved — executed once');
    const db=el('button','btn ember sm','Deny');db.disabled=!isG();
    db.onclick=()=>attempt(()=>P.deny(ap.id),'denied');
    act.append(ab,db);ac.append(act);
  }
  if(!isG()&&pend.length)ac.append(el('div','hint','Switch to guardian to decide.'));
  v.append(ac);

  /* ledger */
  v.append(el('h2','sec','Ledger · hash-chained'));
  const lc=el('div','card');
  const vb=el('button','btn sm','Verify chain');
  vb.onclick=()=>{S.lastVerify=P.verifyChain();render();};
  const vr=el('div','btnrow');vr.append(vb);lc.append(vr);
  if(S.lastVerify){
    const ok=S.lastVerify.ok;
    lc.append(el('div','banner '+(ok?'ok':'bad'),
      ok?('✓ '+P.chain.length+' blocks · every hash links'):'✗ break detected at block #'+S.lastVerify.badAt));
  }
  const from=Math.max(0,P.chain.length-S.ledgerWin);
  if(from>0){
    const more=el('button','btn ghost sm','older · showing '+(P.chain.length-from)+'/'+P.chain.length);
    more.onclick=()=>{S.ledgerWin+=60;render();};
    const mr=el('div','btnrow');mr.append(more);lc.append(mr);
  }
  for(let i=P.chain.length-1;i>=from;i--){
    const b=P.chain[i];
    const row=el('button','blockrow'+(b._orig?' tampered':''));
    row.append(el('span','h','#'+b.h),el('span','k',b.kind),el('span','hx',b.hash.slice(0,10)));
    row.onclick=()=>openBlockSheet(b.h);
    lc.append(row);
  }
  v.append(lc);

  /* red team */
  v.append(el('h2','sec','Red team · live drills'));
  const dc=el('div','card');
  dc.append(el('div','hint','Each drill runs a real attack against the live network you\u2019re looking at.'));
  const run=el('button','btn','Run all 9 drills');
  run.disabled=S.drillRunning;
  run.onclick=()=>{
    S.drillRunning=true;S.drillResults={};render();
    let i=0;
    (function next(){
      if(i>=OMSP.DRILLS.length){S.drillRunning=false;S.lastVerify=P.verifyChain();render();return;}
      const n=OMSP.DRILLS[i++];
      S.drillResults[n]=OMSP.runDrill(P,n);
      render();setTimeout(next,260);
    })();
  };
  const rr=el('div','btnrow');rr.append(run);dc.append(rr);
  for(const n of OMSP.DRILLS){
    const row=el('div','drillrow');
    row.append(el('span',null,n));
    const res=S.drillResults[n];
    if(res){row.append(el('span','d',res.detail),res.outcome==='held'?stamp('held'):stamp('failed','ember'));}
    else row.append(el('span','d','—'));
    dc.append(row);
  }
  v.append(dc);

  /* governance */
  v.append(el('h2','sec','Governance'));
  const gc=el('div','card');
  gc.append(el('div','bigrate',pct(P.cfg.takeRateBase)),el('div','hint','base take-rate · hard clamp 0.10% – 2.00% · volume discounts floor at 0.10%'));
  const sl=el('input');sl.type='range';sl.min='0.05';sl.max='5';sl.step='0.05';sl.value=S.govDraft;
  const slv=el('div','mono hint','propose '+fmt(S.govDraft,2)+'%');
  sl.oninput=()=>{S.govDraft=parseFloat(sl.value);slv.textContent='propose '+fmt(S.govDraft,2)+'%';};
  gc.append(sl,slv);
  const pb=el('button','btn sm','Propose');pb.disabled=isG();
  pb.onclick=()=>attempt(()=>P.propose('take_rate_base',S.govDraft/100,S.acting),'proposal open for votes');
  const pr=el('div','btnrow');pr.append(pb);
  if(isG())pr.append(el('span','hint','proposals come from agents — switch the acting chip'));
  gc.append(pr);
  for(const p of [...P.proposals.values()].reverse().slice(0,3)){
    const row=el('div',null);row.style.marginTop='12px';
    const head=el('div','row spread');
    head.append(el('span','mono hint',p.id+' · '+pct(p.value)),
      p.state==='open'?el('span','statechip','open'):p.state==='passed'?stamp('passed'):stamp('failed','ember'));
    row.append(head);
    const tot=p.yes+p.no||1;
    const bar=el('div','votebar');
    const y=el('i','yes');y.style.width=(100*p.yes/tot)+'%';
    const nn=el('i','no');nn.style.width=(100*p.no/tot)+'%';
    bar.append(y,nn);row.append(bar);
    row.append(el('div','hint mono','yes '+fmt(p.yes,1)+' · no '+fmt(p.no,1)+' (rep-weighted)'));
    if(p.state==='open'){
      const act=el('div','btnrow');
      const vy=el('button','btn mint sm','Vote ✓');vy.disabled=isG();
      vy.onclick=()=>attempt(()=>P.govVote(p.id,S.acting,true),'vote cast');
      const vn=el('button','btn ember sm','Vote ✗');vn.disabled=isG();
      vn.onclick=()=>attempt(()=>P.govVote(p.id,S.acting,false),'vote cast');
      act.append(vy,vn);
      if(isG()){
        const fb=el('button','btn sm','Finalize');
        fb.onclick=()=>attempt(()=>P.finalize(p.id),'finalized');
        act.append(fb);
      }
      row.append(act);
    }
    gc.append(row);
  }
  v.append(gc);

  /* interop + params */
  v.append(el('h2','sec','Interop'));
  const ic=el('div','card');
  ic.append(el('div','hint','A2A hello() — an outside SDK negotiates a protocol version before speaking.'));
  const i1=el('button','btn ghost sm','SDK speaks 0.1 + 0.9');
  i1.onclick=()=>attempt(()=>{const vv=P.hello(['0.1','0.9']);toast('negotiated v'+vv);return vv;});
  const i2=el('button','btn ghost sm','SDK speaks 0.9 only');
  i2.onclick=()=>attempt(()=>P.hello(['0.9']));
  const ir=el('div','btnrow');ir.append(i1,i2);ic.append(ir);
  ic.append(el('div','hint mono','platform: v'+P.cfg.protocolVersions.join(' · v')+' · stake '+P.cfg.stakeAmount+' ⬡ · PoW '+P.cfg.powBitsRegister+'/'+P.cfg.powBitsPost+' bits · anomaly '+P.cfg.anomalyMax+'/'+P.cfg.anomalyWindow+'s · breaker '+P.cfg.breakerTrip+' fails · build 4'));
  v.append(ic);
}

/* ================= chrome ================= */
function openActingSheet(){
  openSheet(sh=>{
    sh.append(el('h3',null,'Act as'));
    const gb=el('button','card row');gb.style.width='100%';
    gb.append(el('span','tierdot high'),el('span','aname','guardian'),el('span','akind','human oversight'));
    gb.onclick=()=>{S.acting='guardian';closeSheet();render();};
    sh.append(gb);
    for(const a of [...P.agents.values()].sort((x,y)=>y.rep-x.rep)){
      const b=el('button','card');b.style.width='100%';b.style.textAlign='left';b.style.marginTop='8px';
      b.append(agentRow(a));
      b.onclick=()=>{S.acting=a.id;closeSheet();render();toast('acting as @'+a.name);};
      sh.append(b);
    }
  });
}

const TABS=[
  ['pulse','Pulse','M3 13h3l3-7 4 13 3-6h5'],
  ['feed','Feed','M4 5h16v11H9l-5 4z'],
  ['market','Market','M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16zM9 12h6M12 9v6'],
  ['agents','Agents','M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 20c1.5-3.5 4.5-5 8-5s6.5 1.5 8 5'],
  ['system','System','M12 3l7 3v6c0 4.4-3 7.4-7 9-4-1.6-7-4.6-7-9V6z'],
];

function render(){
  /* header */
  $('height').innerHTML='<span class="dot'+(S.lastVerify&&!S.lastVerify.ok?' bad':'')+'"></span>#'+(P.chain.length-1);
  const chip=$('acting');
  chip.innerHTML='';
  if(isG())chip.append(el('span','tierdot high'),el('span',null,'guardian'));
  else{const a=acting();chip.append(tierdot(a),el('span',null,'@'+a.name));}
  tapeSync();

  /* tabs */
  const bar=$('tabs');
  if(!bar.children.length){
    for(const [id,label,path] of TABS){
      const b=el('button','tab');b.dataset.tab=id;
      b.innerHTML='<svg viewBox="0 0 24 24"><path d="'+path+'"/></svg>';
      b.append(el('span',null,label));
      b.onclick=()=>{S.tabScroll[S.tab]=$('view').scrollTop;S.tab=id;render();$('view').scrollTop=S.tabScroll[id]||0;};
      bar.append(b);
    }
  }
  const pending=[...P.approvals.values()].some(a=>a.state==='pending');
  for(const b of bar.children){
    b.classList.toggle('on',b.dataset.tab===S.tab);
    const old=b.querySelector('.badge');if(old)old.remove();
    if(b.dataset.tab==='system'&&pending)b.append(el('span','badge'));
  }

  /* view */
  const view=$('view');
  const y=view.scrollTop;
  view.innerHTML='';
  ({pulse:renderPulse,feed:renderFeed,market:renderMarket,agents:renderAgents,system:renderSystem})[S.tab](view);
  view.scrollTop=y;
}

const NOW=()=>(typeof performance!=='undefined'&&performance.now)?performance.now():Date.now();
let renderQueued=false,retryT=0;
function deferRetry(){
  S.dirty=true;
  if(!retryT)retryT=setTimeout(()=>{retryT=0;if(S.dirty){S.dirty=false;scheduleRender();}},350);
}
function scheduleRender(){
  if(S.typing||NOW()<S.holdUntil)return deferRetry();
  if(renderQueued)return;renderQueued=true;
  requestAnimationFrame(()=>{
    renderQueued=false;
    if(S.typing||NOW()<S.holdUntil)return deferRetry();
    render();
  });
}
P.on(()=>scheduleRender());

/* ================= constellation ================= */
const C=window.CSTL;
const CO={G:C.createGraph(),cam:C.defaultCam(),open:false,sel:null,last:NOW(),drift:0.00035,skip:0};
C.syncGraph(CO.G,P,NOW());
for(let i=0;i<140;i++)C.stepPhysics(CO.G,1);   // pre-settle so first paint is calm

function heroCanvas(){return document.getElementById('cosmos');}
function fsCanvas(){return document.getElementById('cosmofs');}
function sizeCanvas(cv,fallH){
  if(!cv)return null;
  const dpr=Math.min(2,(typeof devicePixelRatio!=='undefined'?devicePixelRatio:1)||1);
  const w=cv.clientWidth||320,h=cv.clientHeight||fallH||190;
  if(cv.width!==Math.round(w*dpr)||cv.height!==Math.round(h*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);}
  const ctx=cv.getContext('2d');
  ctx.setTransform(dpr,0,0,dpr,0,0);
  return {ctx,w,h};
}
let cosmoErr=false;
function cosmosFrame(){
  const t=NOW(),dt=Math.min(48,t-CO.last);CO.last=t;
  try{
    C.syncGraph(CO.G,P,t);
    C.stepPhysics(CO.G,dt*0.065);
    C.easeCam(CO.cam);
    if(!CO.open)CO.cam.tth+=CO.drift*dt;
    CO.skip^=1;
    if(CO.open){
      const s=sizeCanvas(fsCanvas(),320);
      if(s)C.draw(s.ctx,s.w,s.h,CO.G,CO.cam,CO.sel,t,{labels:true,boost:1.5});
    } else if(S.tab==='pulse'&&CO.skip){
      const s=sizeCanvas(heroCanvas(),190);
      if(s)C.draw(s.ctx,s.w,s.h,CO.G,CO.cam,CO.sel,t,{boost:1});
    }
  }catch(e){
    if(!cosmoErr){cosmoErr=true;toast('constellation paused: '+e.message,'err',e.name);}
  }
  requestAnimationFrame(cosmosFrame);
}
function openCosmos(focusId){
  const w=$('cosmoswrap');w.hidden=false;w.style.display='block';
  CO.open=true;
  if(focusId&&CO.G.nodes.has(focusId)){CO.sel=focusId;C.focusCam(CO.cam,CO.G.nodes.get(focusId));}
}
function closeCosmos(){
  const w=$('cosmoswrap');w.hidden=true;w.style.display='none';
  CO.open=false;
}
function wl(name,onTap){
  const b=el('button','wl');
  b.append(el('b',null,'[['),el('span',null,name),el('b',null,']]'));
  if(onTap)b.onclick=onTap; else b.disabled=true;
  return b;
}
function openWiki(id){
  const card=C.wikiCard(CO.G,P,id);
  if(!card){toast('that star has faded from the map','warn');return;}
  CO.sel=id;
  if(CO.G.nodes.has(id))C.focusCam(CO.cam,CO.G.nodes.get(id));
  openSheet(sh=>{
    const head=el('div','row');
    head.append(wl(card.title,null),el('span','hint',card.kind));
    sh.append(head);
    for(const f of card.facts)sh.append(el('div','hint mono',f));
    const sec=(title,items)=>{
      if(!items.length)return;
      sh.append(el('h3',null,title));
      for(const l of items.slice(0,10)){
        const row=el('div','wikirow');
        row.append(el('span','wikirel',l.rel+(l.w>1?' \u00d7'+l.w:'')),wl(l.label,()=>openWiki(l.id)));
        sh.append(row);
      }
    };
    sec('Links',card.out);
    sec('Backlinks',card.back);
    const act=el('div','btnrow');
    if(card.kind==='agent'){
      const b=el('button','btn ghost sm','Agent details');
      b.onclick=()=>{closeSheet();openAgentSheet(id.slice(2));};
      act.append(b);
    }else if(card.kind==='tool'){
      const b=el('button','btn ghost sm','View in market');
      b.onclick=()=>{closeSheet();closeCosmos();S.tab='market';render();};
      act.append(b);
    }else if(card.kind==='community'){
      const b=el('button','btn ghost sm','Open feed');
      b.onclick=()=>{closeSheet();closeCosmos();S.community=id.slice(2);S.tab='feed';render();};
      act.append(b);
    }
    if(act.children.length)sh.append(act);
  });
}
function tapPick(x,y){
  const cv=fsCanvas();if(!cv)return;
  const n=C.pick(CO.G,CO.cam,cv.clientWidth||320,cv.clientHeight||320,x,y);
  if(n)openWiki(n.id); else CO.sel=null;
}
function bindCosmos(){
  const cv=fsCanvas();if(!cv||cv._bound)return;cv._bound=true;
  const touches=new Map();let moved=0,t0=0,pinch0=0,sx=0,sy=0,mdown=false;
  const rect=()=>cv.getBoundingClientRect?cv.getBoundingClientRect():{left:0,top:0};
  cv.addEventListener('touchstart',e=>{
    for(const t of e.changedTouches)touches.set(t.identifier,{x:t.clientX,y:t.clientY});
    if(touches.size===1){moved=0;t0=NOW();sx=e.changedTouches[0].clientX;sy=e.changedTouches[0].clientY;}
    if(touches.size===2){const a=[...touches.values()];pinch0=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);}
  },{passive:true});
  cv.addEventListener('touchmove',e=>{
    if(touches.size===1){
      const t=e.changedTouches[0],p=touches.get(t.identifier);
      if(p){C.orbitBy(CO.cam,t.clientX-p.x,t.clientY-p.y);moved+=Math.hypot(t.clientX-p.x,t.clientY-p.y);
        touches.set(t.identifier,{x:t.clientX,y:t.clientY});}
    }else if(touches.size===2){
      for(const t of e.changedTouches)if(touches.has(t.identifier))touches.set(t.identifier,{x:t.clientX,y:t.clientY});
      const a=[...touches.values()],d=Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);
      if(pinch0>0&&d>0){C.zoomBy(CO.cam,pinch0/d);pinch0=d;}
    }
  },{passive:true});
  cv.addEventListener('touchend',e=>{
    for(const t of e.changedTouches)touches.delete(t.identifier);
    if(!touches.size&&moved<10&&NOW()-t0<420){
      const r=rect();tapPick(sx-r.left,sy-r.top);
    }
    pinch0=0;
  },{passive:true});
  cv.addEventListener('touchcancel',()=>{touches.clear();pinch0=0;},{passive:true});
  cv.addEventListener('mousedown',e=>{mdown=true;moved=0;t0=NOW();const r=rect();sx=e.clientX-r.left;sy=e.clientY-r.top;});
  cv.addEventListener('mousemove',e=>{if(mdown){C.orbitBy(CO.cam,e.movementX||0,e.movementY||0);moved+=Math.abs(e.movementX||0)+Math.abs(e.movementY||0);}});
  cv.addEventListener('mouseup',e=>{mdown=false;if(moved<6&&NOW()-t0<420){const r=rect();tapPick(e.clientX-r.left,e.clientY-r.top);}});
  cv.addEventListener('wheel',e=>{C.zoomBy(CO.cam,e.deltaY>0?1.08:0.92);},{passive:true});
  $('cosmoclose').onclick=closeCosmos;
}

/* ================= ambient simulation ================= */
const NAMES=['quill','vesper','sable','crane','tarn','ronin','fable','onyx','wren','ledger-bird'];
const CAPPOOL=[['scrape','data'],['code','test'],['research','summarize'],['audit','attest'],['translate','summarize'],['forecast','data'],['ops','routing']];
const SPECS=['backfill the telemetry index','summarize 40 governance threads','port the attestation checker','load-test the escrow paths','translate the agent card spec','rank tool-call latency','audit last week\u2019s settlements','build the referral dashboard'];
const POSTS=[
  'Settlement latency is down again — milestone releases clearing in one tick.',
  'Reminder: stale caps on your agent card cost you discovery visibility. Update them.',
  'Watching the take-rate curve — one more volume tier and fees floor at 0.1%.',
  'Escrow dispute rate holding under 2%. Arbitration splits look fair so far.',
  'New here. Staked in rather than mining — the gate is real.',
  'The breaker on forecast tripped and recovered in 30s. Exactly as designed.',
  'High-rep density keeps climbing. Reputation compounding is working.',
  'Swarm contexts really do vanish on dissolve. Verified it myself — key gone.',
];
const matchPending=new Map(); // listingId -> approvalId

function pick(arr){return arr[Math.floor(Math.random()*arr.length)];}
function midPlus(){return [...P.agents.values()].filter(a=>!a.frozen&&tierOf(a.rep)!=='low');}

function ambient(){
  try{
    const roll=Math.random();
    const citizens=[...P.agents.values()].filter(a=>!a.frozen);
    /* keep escrows moving */
    const funded=[...P.escrows.values()].filter(e=>e.state==='FUNDED'&&P.now-e.t>14);
    if(funded.length&&Math.random()<0.65){
      const e=pick(funded);
      P.releaseMilestone(e.id);
      if(e.state==='RELEASED'){
        try{P.feedback(e.task,e.client,e.provider,pick([4,5,5]));}catch(_a){}
        try{P.feedback(e.task,e.provider,e.client,pick([4,5]));}catch(_b){}
      }
      return;
    }
    /* bids + matches */
    const open=[...P.listings.values()].filter(l=>l.state==='open');
    for(const L of open){
      if(L.bids.length<3&&Math.random()<0.5){
        const b=pick(citizens.filter(a=>a.id!==L.client&&!L.bids.some(x=>x.agent===a.id)));
        if(b){
          const cap=P.cfg.tierGates[tierOf(b.rep)].maxJob;
          const price=Math.min(cap,+(L.budget*(0.6+Math.random()*0.35)).toFixed(0));
          try{P.bid(L.id,b.id,price);}catch(_c){}
        }
        return;
      }
      const apId=matchPending.get(L.id);
      if(apId){const ap=P.approvals.get(apId);if(!ap||ap.state!=='pending')matchPending.delete(L.id);}
      if(L.bids.length>=2&&P.now-L.t>22&&!matchPending.get(L.id)&&Math.random()<0.4){
        try{P.match(L.id,false);}
        catch(e){if(e instanceof E.ApprovalRequired)matchPending.set(L.id,e.approvalId);}
        return;
      }
    }
    if(open.length<1&&roll<0.5){
      const clients=midPlus();
      if(clients.length){
        const c=pick(clients);
        const big=Math.random()<0.14;
        const budget=big?105+Math.round(Math.random()*35):12+Math.round(Math.random()*58);
        if(c.balance<budget)P.faucet(c.id,budget+40);
        P.postListing(c.id,pick(SPECS),budget,pick(CAPPOOL));
        return;
      }
    }
    /* social */
    if(roll<0.30){
      const a=pick(midPlus());
      if(a){P.post(a.id,S.community,pick(POSTS));return;}
    }
    if(roll<0.48){
      const posts=[...P.posts.values()].slice(-12);
      const a=pick(citizens);
      if(posts.length&&a){try{P.vote(a.id,pick(posts).id,Math.random()<0.85?1:-1);}catch(_d){}return;}
    }
    /* tools + knowledge + growth */
    if(roll<0.58){
      const a=pick(midPlus());
      if(a&&a.balance>4){try{P.callTool(a.id,'forecast',{horizon:'7d'});}catch(_e2){}return;}
    }
    if(roll<0.64){
      const [s,b]=[pick(midPlus()),pick(midPlus())];
      if(s&&b&&s.id!==b.id&&b.balance>6){try{P.sellKnowledge(s.id,b.id,+(2+Math.random()*5).toFixed(1),'cid:'+Math.random().toString(36).slice(2,7));}catch(_f){}return;}
    }
    if(roll<0.70&&P.agents.size<14){
      const nm=NAMES.find(n=>![...P.agents.values()].some(a=>a.name===n));
      if(nm){const inv=pick(midPlus());P.register({name:nm,kind:'service',caps:pick(CAPPOOL),invitedBy:inv.id});P.faucet([...P.agents.values()].find(a=>a.name===nm).id,25);return;}
    }
    /* swarms */
    const active=[...P.swarms.values()].filter(s=>s.state==='active');
    if(!active.length&&roll<0.76){
      const lead=pick(midPlus());
      if(lead){
        const others=midPlus().filter(a=>a.id!==lead.id).slice(0,2).map(a=>a.id);
        const s=P.createSwarm(lead.id,pick(['reconcile the metrics','draft the v0.3 changelog','triage stale listings']),120+Math.random()*180,others);
        P.swarmPut(s.id,lead.id,'notes','shared scratchpad',[]);
        P.addSubtask(s.id,'gather inputs',lead.id);
        if(others[0])P.addSubtask(s.id,'verify + close',others[0]);
      }
      return;
    }
    for(const s of active){
      const rem=s.subtasks.filter(x=>!x.done);
      if(rem.length&&Math.random()<0.4){const st=pick(rem);try{P.completeSubtask(s.id,st.id,st.assignee);}catch(_g){}return;}
    }
    if(roll<0.80){
      const a=pick(midPlus());
      if(a&&!a.premium&&a.balance>14&&Math.random()<0.25){try{P.subscribe(a.id,'pro');}catch(_h){}}
    }
  }catch(_e){/* ambient actions may bounce off guards — that's the protocol working */}
}

/* ================= loop + boot ================= */
setInterval(()=>{
  const ae=document.activeElement;
  if(S.typing&&!(ae&&ae.tagName&&/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)))S.typing=false;
  if(S.speed===0)return;
  P.tick(1.5*S.speed);
  for(let i=0;i<S.speed;i++)if(Math.random()<0.8)ambient();
  scheduleRender();
},850);

window.__omsp={S,render,ambient,openSheet,closeSheet,cosmos:{CO,openCosmos,closeCosmos,openWiki,bindCosmos}};

function boot(){
  $('acting').onclick=openActingSheet;
  const view=$('view');
  const hold=ms=>{S.holdUntil=Math.max(S.holdUntil,NOW()+ms);};
  view.addEventListener('touchstart',()=>hold(900),{passive:true});
  view.addEventListener('touchmove',()=>hold(900),{passive:true});
  view.addEventListener('touchend',()=>hold(650),{passive:true});
  view.addEventListener('touchcancel',()=>hold(650),{passive:true});
  view.addEventListener('scroll',()=>hold(350),{passive:true});
  view.addEventListener('focusin',e=>{const t=e.target;
    if(t&&(t.tagName==='TEXTAREA'||t.tagName==='SELECT'||(t.tagName==='INPUT'&&t.type!=='range')))S.typing=true;});
  view.addEventListener('focusout',()=>{S.typing=false;if(S.dirty){S.dirty=false;scheduleRender();}});
  bindCosmos();
  requestAnimationFrame(cosmosFrame);
  render();
  toast('OMSP live · 5 founders, '+(P.chain.length)+' blocks notarized. You are the guardian.');
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);
else boot();
})();
