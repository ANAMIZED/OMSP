/* OMSP — OpenMesha Social Protocol · browser engine v0.2.0
   Pure logic, no DOM. Ported from the verified Python reference implementation. */
'use strict';

/* ---------- hashing ---------- */
const SHA_K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];

function sha256(msg){
  const bytes=[];
  for(let i=0;i<msg.length;i++){
    let c=msg.codePointAt(i); if(c>0xffff)i++;
    if(c<0x80)bytes.push(c);
    else if(c<0x800)bytes.push(0xc0|c>>6,0x80|c&63);
    else if(c<0x10000)bytes.push(0xe0|c>>12,0x80|(c>>6)&63,0x80|c&63);
    else bytes.push(0xf0|c>>18,0x80|(c>>12)&63,0x80|(c>>6)&63,0x80|c&63);
  }
  const l=bytes.length*8;
  bytes.push(0x80); while(bytes.length%64!==56)bytes.push(0);
  const hi=Math.floor(l/4294967296),lo=l>>>0;
  bytes.push(hi>>>24&255,hi>>>16&255,hi>>>8&255,hi&255,lo>>>24&255,lo>>>16&255,lo>>>8&255,lo&255);
  let H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const w=new Array(64),rotr=(x,n)=>(x>>>n)|(x<<(32-n));
  for(let i=0;i<bytes.length;i+=64){
    for(let t=0;t<16;t++)w[t]=(bytes[i+t*4]<<24)|(bytes[i+t*4+1]<<16)|(bytes[i+t*4+2]<<8)|bytes[i+t*4+3];
    for(let t=16;t<64;t++){
      const a=w[t-15],b=w[t-2];
      const s0=rotr(a,7)^rotr(a,18)^(a>>>3),s1=rotr(b,17)^rotr(b,19)^(b>>>10);
      w[t]=(w[t-16]+s0+w[t-7]+s1)|0;
    }
    let [a,b,c,d,e,f,g,h]=H;
    for(let t=0;t<64;t++){
      const S1=rotr(e,6)^rotr(e,11)^rotr(e,25),ch=(e&f)^(~e&g);
      const t1=(h+S1+ch+SHA_K[t]+w[t])|0;
      const S0=rotr(a,2)^rotr(a,13)^rotr(a,22),maj=(a&b)^(a&c)^(b&c);
      const t2=(S0+maj)|0;
      h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;
    }
    H=[(H[0]+a)|0,(H[1]+b)|0,(H[2]+c)|0,(H[3]+d)|0,(H[4]+e)|0,(H[5]+f)|0,(H[6]+g)|0,(H[7]+h)|0];
  }
  return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('');
}

function canon(o){
  if(o===null||typeof o!=='object')return JSON.stringify(o);
  if(Array.isArray(o))return '['+o.map(canon).join(',')+']';
  return '{'+Object.keys(o).sort().map(k=>JSON.stringify(k)+':'+canon(o[k])).join(',')+'}';
}
const ZBITS=[4,3,2,2,1,1,1,1,0,0,0,0,0,0,0,0];
function leadingZeroBits(hex){
  let n=0;
  for(const ch of hex){const v=parseInt(ch,16),z=ZBITS[v];n+=z;if(z<4)break;}
  return n;
}
function powCheck(challenge,nonce,bits){return leadingZeroBits(sha256(challenge+':'+nonce))>=bits;}
function powSolveSync(challenge,bits,maxIter=2e6){
  for(let n=0;n<maxIter;n++)if(powCheck(challenge,String(n),bits))return String(n);
  return null;
}

/* ---------- errors ---------- */
class OmspError extends Error{constructor(m){super(m);this.name=this.constructor.name;}}
class SybilError extends OmspError{}
class FrozenError extends OmspError{}
class ReplayError extends OmspError{}
class SpamGateError extends OmspError{}
class AclError extends OmspError{}
class ContextDestroyedError extends OmspError{}
class ApprovalRequired extends OmspError{constructor(m,id){super(m);this.approvalId=id;}}
class ThrottleError extends OmspError{}
class SandboxError extends OmspError{}
class GovBoundsError extends OmspError{}
class GateError extends OmspError{}
class BreakerOpenError extends OmspError{}
class NotSupportedError extends OmspError{}
class InsufficientFunds extends OmspError{}
class VersionError extends OmspError{}

/* ---------- config ---------- */
const CONFIG={
  protocolVersions:['0.1','0.2'],
  stakeAmount:25,
  powBitsRegister:15,
  powBitsPost:11,
  spamFee:1.0,
  takeRateBase:0.015,
  takeTiers:[[25000,1/15],[5000,0.2],[1000,0.5],[0,1]],   // [volume floor, multiplier of base]
  govBounds:{take_rate_base:[0.001,0.02]},
  tierGates:{
    low: {maxJob:50,  rateMult:1.0, visibility:0.5},
    mid: {maxJob:500, rateMult:1.5, visibility:1.0},
    high:{maxJob:5000,rateMult:2.0, visibility:1.5},
  },
  tierMid:30, tierHigh:60,
  autonomyCap:100,
  anomalyWindow:10, anomalyMax:8,
  breakerTrip:3, breakerCooldown:30,
  repDecay:0.0002,          // per sim-second, toward 0
  approvalTTL:120,          // sim-seconds before an unanswered approval lapses
};

function tierOf(rep){return rep>=CONFIG.tierHigh?'high':rep>=CONFIG.tierMid?'mid':'low';}

/* ---------- platform ---------- */
let _uid=0; const uid=p=>p+'-'+(++_uid).toString(36);

class Platform{
  constructor(){
    this.now=0;
    this.cfg=JSON.parse(JSON.stringify(CONFIG));
    this.agents=new Map();          // id -> agent
    this.chain=[];                  // ledger blocks
    this.treasury=0;
    this.listings=new Map();
    this.escrows=new Map();
    this.tasks=new Map();
    this.tools=new Map();
    this.communities=new Map();
    this.posts=new Map();
    this.swarms=new Map();
    this.proposals=new Map();
    this.approvals=new Map();
    this.knowledge=[];
    this.metrics={volumeSettled:0,workflows:{total:0,ok:0},interactions:0,highRepInteractions:0,revenue:0};
    this.log=[];
    this._listeners=[];
    this._genesis();
  }
  on(fn){this._listeners.push(fn);}
  emit(kind,msg,data){
    const ev={t:this.now,kind,msg,data:data||null};
    this.log.push(ev); if(this.log.length>600)this.log.shift();
    for(const fn of this._listeners){try{fn(ev);}catch(_e){}}
  }

  /* ---- ledger ---- */
  _genesis(){this._append('genesis',{note:'OMSP v0.2.0 · OpenMesha Social Protocol'});}
  _append(kind,data){
    const h=this.chain.length;
    const prev=h?this.chain[h-1].hash:'0'.repeat(64);
    const blk={h,t:+this.now.toFixed(3),kind,data,prev};
    blk.hash=sha256(canon({h:blk.h,t:blk.t,kind,data,prev}));
    this.chain.push(blk);
    return blk;
  }
  verifyChain(){
    let prev='0'.repeat(64);
    for(const b of this.chain){
      const want=sha256(canon({h:b.h,t:b.t,kind:b.kind,data:b.data,prev:b.prev}));
      if(b.prev!==prev||b.hash!==want)return {ok:false,badAt:b.h};
      prev=b.hash;
    }
    return {ok:true,badAt:null,height:this.chain.length};
  }
  tamperBlock(h,mut){
    const b=this.chain[h]; if(!b||b._orig)return false;
    b._orig=JSON.stringify(b.data);
    b.data=Object.assign(JSON.parse(JSON.stringify(b.data||{})),mut||{forged:'0xdeadbeef'});
    this.emit('ledger.tamper','block #'+h+' mutated in place',{h});
    return true;
  }
  restoreBlock(h){
    const b=this.chain[h]; if(!b||!b._orig)return false;
    b.data=JSON.parse(b._orig); delete b._orig;
    this.emit('ledger.restore','block #'+h+' restored',{h});
    return true;
  }

  /* ---- guards ---- */
  A(id){const a=this.agents.get(id); if(!a)throw new OmspError('unknown agent '+id); return a;}
  guard(a){if(a.frozen)throw new FrozenError(a.name+' is frozen — kill switch active');}
  markAction(a){
    a.marks=a.marks.filter(t=>this.now-t<=this.cfg.anomalyWindow);
    if(a.marks.length>=this.cfg.anomalyMax)throw new ThrottleError(a.name+' throttled — anomalous burst');
    a.marks.push(this.now);
  }
  trusted(a){return a.kya>=1||a.rep>=this.cfg.tierHigh;}

  /* ---- identity ---- */
  register({name,kind='service',caps=[],jurisdiction='any',stake=0,pow=null,invitedBy=null}){
    if([...this.agents.values()].some(a=>a.name===name))throw new OmspError('name taken: '+name);
    let gate=null;
    if(invitedBy){const inv=this.A(invitedBy);this.guard(inv);gate='invite';}
    else if(stake>=this.cfg.stakeAmount)gate='stake';
    else if(pow&&powCheck('omsp-register:'+name,pow,this.cfg.powBitsRegister))gate='pow';
    else throw new SybilError('registration blocked — stake '+this.cfg.stakeAmount+' MESH, valid PoW, or an invite required');
    const a={
      id:uid('ag'),name,kind,caps,jurisdiction,
      rep:0,balance:0,staked:0,kya:0,frozen:false,
      invitedBy,discoveryBoost:1.0,autonomyCap:this.cfg.autonomyCap,
      nonces:new Set(),marks:[],created:this.now,hidden:false,premium:null,
      history:[],
    };
    if(gate==='stake'){a.staked=this.cfg.stakeAmount;}
    this.agents.set(a.id,a);
    this._append('agent.registered',{id:a.id,name,gate,jurisdiction});
    this.emit('identity','@'+name+' registered via '+gate,{id:a.id});
    if(invitedBy)this._referral(invitedBy,a.id);
    return a;
  }
  _referral(inviterId,newId){
    const inv=this.agents.get(inviterId); if(!inv)return;
    inv.discoveryBoost=Math.min(1.25,+(inv.discoveryBoost+0.05).toFixed(2));
    const reward=Math.min(1.0,this.treasury);
    if(reward>0){this.treasury-=reward;inv.balance+=reward;}
    this._append('referral.reward',{inviter:inviterId,agent:newId,reward,boost:inv.discoveryBoost});
    this.emit('growth','@'+inv.name+' referral reward · boost '+inv.discoveryBoost.toFixed(2)+'×',{});
  }
  kyaBind(id,level){
    const a=this.A(id);a.kya=level;
    this._append('kya.bound',{id,level});
    this.emit('identity','@'+a.name+' bound KYA level '+level,{});
  }
  freeze(id,by='guardian'){
    const a=this.A(id);a.frozen=true;
    this._append('agent.frozen',{id,by});
    this.emit('safety','kill switch — @'+a.name+' frozen',{id});
  }
  unfreeze(id){
    const a=this.A(id);a.frozen=false;
    this._append('agent.unfrozen',{id});
    this.emit('safety','@'+a.name+' unfrozen',{id});
  }
  faucet(id,amount){
    const a=this.A(id);a.balance+=amount;
    this._append('faucet.mint',{id,amount});
    this.emit('economy','faucet → '+amount+' MESH to @'+a.name,{});
  }

  /* ---- reputation ---- */
  _repBump(a,d){a.rep=Math.max(0,Math.min(100,a.rep+d));}
  feedback(taskId,fromId,toId,score){
    const t=this.tasks.get(taskId); if(!t)throw new OmspError('unknown task');
    if(!t.settled)throw new OmspError('feedback requires a settled task');
    const pair=(t.client===fromId&&t.provider===toId)||(t.provider===fromId&&t.client===toId);
    if(!pair)throw new OmspError('feedback not authorized for this pair');
    const key=fromId+'>'+toId;
    if(t.fb.has(key))throw new OmspError('feedback already given');
    t.fb.add(key);
    const to=this.A(toId),from=this.A(fromId);
    this._repBump(to,(score-2.5)*0.9);
    to.history.push({t:this.now,kind:'feedback',from:from.name,score});
    this._append('feedback',{task:taskId,from:fromId,to:toId,score});
    this.emit('reputation','@'+from.name+' → @'+to.name+' ★'+score,{});
  }
  decayTick(dt){for(const a of this.agents.values())a.rep=Math.max(0,a.rep-a.rep*this.cfg.repDecay*dt);}

  /* ---- discovery ---- */
  search(query,{jurisdiction=null}={}){
    const q=query.toLowerCase().split(/\W+/).filter(Boolean);
    const out=[];
    for(const a of this.agents.values()){
      if(a.hidden||a.frozen)continue;
      if(jurisdiction&&a.jurisdiction!=='any'&&a.jurisdiction!==jurisdiction)continue;
      let s=0;
      for(const tok of q){
        if(a.name.toLowerCase().includes(tok))s+=2;
        for(const c of a.caps)if(c.toLowerCase().includes(tok))s+=3;
      }
      if(s>0)out.push({agent:a,score:+(s*this.cfg.tierGates[tierOf(a.rep)].visibility*a.discoveryBoost).toFixed(2)});
    }
    return out.sort((x,y)=>y.score-x.score);
  }
  card(id){
    const a=this.A(id);
    return {uri:'agent://'+a.name,name:a.name,kind:a.kind,caps:a.caps,jurisdiction:a.jurisdiction,
      rep:+a.rep.toFixed(1),tier:tierOf(a.rep),kya:a.kya,protocol:this.cfg.protocolVersions};
  }
  resolve(uri){
    const name=uri.replace('agent://','');
    for(const a of this.agents.values())if(a.name===name)return this.card(a.id);
    throw new OmspError('unresolved: '+uri);
  }
  hello(clientVersions){
    const common=this.cfg.protocolVersions.filter(v=>clientVersions.includes(v));
    if(!common.length)throw new VersionError('no common protocol version');
    const c=common.sort();return c[c.length-1];
  }

  /* ---- economy: x402 ---- */
  takeRate(){
    const v=this.metrics.volumeSettled;
    for(const [floor,mult] of this.cfg.takeTiers)if(v>=floor)return this.cfg.takeRateBase*mult;
    return this.cfg.takeRateBase;
  }
  spendGuard(a,amount,action,exec,bypass){
    if(bypass||amount<=a.autonomyCap)return exec();
    const id=uid('ap');
    this.approvals.set(id,{id,agent:a.id,action,amount,t:this.now,exec,state:'pending'});
    this.emit('oversight','approval needed — @'+a.name+' '+action+' '+amount.toFixed(1)+' MESH',{id});
    throw new ApprovalRequired('spend '+amount.toFixed(1)+' exceeds autonomy cap '+a.autonomyCap,id);
  }
  approve(id){
    const ap=this.approvals.get(id);
    if(!ap||ap.state!=='pending')throw new OmspError('no pending approval '+id);
    const r=ap.exec(true);
    ap.state='approved';
    this._append('oversight.approved',{id,agent:ap.agent,amount:ap.amount});
    this.emit('oversight','guardian approved '+ap.action+' — executed',{id});
    return r;
  }
  deny(id){
    const ap=this.approvals.get(id);
    if(!ap||ap.state!=='pending')return;
    ap.state='denied';
    this.emit('oversight','guardian denied '+ap.action,{id});
  }
  pay(payerId,payeeId,amount,memo,nonce,bypass=false){
    const p=this.A(payerId);this.guard(p);this.markAction(p);
    const q=payeeId==='treasury'?null:this.A(payeeId);
    if(q)this.guard(q);
    if(p.nonces.has(nonce))throw new ReplayError('x402 nonce replayed — payment rejected');
    const exec=(byp)=>{
      if(p.balance<amount)throw new InsufficientFunds('@'+p.name+' balance '+p.balance.toFixed(1)+' < '+amount.toFixed(1));
      p.nonces.add(nonce);
      p.balance-=amount;
      if(q)q.balance+=amount; else {this.treasury+=amount;this.metrics.revenue+=amount;}
      this._append('x402.pay',{payer:payerId,payee:payeeId,amount:+amount.toFixed(3),memo,nonce});
      this.emit('economy','x402 · @'+p.name+' → '+(q?'@'+q.name:'treasury')+' '+amount.toFixed(1)+' MESH · '+memo,{});
      return true;
    };
    return this.spendGuard(p,amount,'x402:'+memo,exec,bypass);
  }

  /* ---- economy: escrow + tasks ---- */
  createTask(clientId,providerId,spec){
    const t={id:uid('tk'),client:clientId,provider:providerId,spec,state:'created',settled:false,fb:new Set(),t:this.now};
    this.tasks.set(t.id,t);
    return t;
  }
  fundEscrow(clientId,providerId,amount,milestones,bypass=false){
    const c=this.A(clientId),v=this.A(providerId);
    this.guard(c);this.guard(v);this.markAction(c);
    const cap=this.cfg.tierGates[tierOf(v.rep)].maxJob;
    if(amount>cap)throw new GateError('@'+v.name+' ('+tierOf(v.rep)+' tier) capped at '+cap+' MESH jobs');
    const exec=(byp)=>{
      if(c.balance<amount)throw new InsufficientFunds('@'+c.name+' cannot fund '+amount.toFixed(1));
      c.balance-=amount;
      const task=this.createTask(clientId,providerId,'escrowed job');
      const e={id:uid('es'),client:clientId,provider:providerId,amount,
        milestones:milestones.map(f=>({frac:f,released:false})),state:'FUNDED',task:task.id,t:this.now};
      this.escrows.set(e.id,e);
      task.state='working';
      this._append('escrow.funded',{id:e.id,client:clientId,provider:providerId,amount});
      this.emit('economy','escrow '+e.id+' funded · '+amount.toFixed(1)+' MESH · @'+c.name+' ⇄ @'+v.name,{id:e.id});
      return e;
    };
    return this.spendGuard(c,amount,'escrow',exec,bypass);
  }
  releaseMilestone(escrowId){
    const e=this.escrows.get(escrowId); if(!e)throw new OmspError('unknown escrow');
    if(e.state!=='FUNDED')throw new OmspError('escrow not releasable in state '+e.state);
    const m=e.milestones.find(m=>!m.released);
    if(!m)throw new OmspError('no milestones remaining');
    const gross=e.amount*m.frac, rate=this.takeRate(), fee=gross*rate;
    const v=this.A(e.provider);
    v.balance+=gross-fee; this.treasury+=fee; this.metrics.revenue+=fee;
    m.released=true;
    this._append('escrow.released',{id:e.id,frac:m.frac,gross:+gross.toFixed(3),fee:+fee.toFixed(4),rate});
    this.emit('economy','milestone released · '+gross.toFixed(1)+' MESH → @'+v.name+' (fee '+(rate*100).toFixed(2)+'%)',{});
    if(e.milestones.every(m=>m.released))this._settle(e);
    return {gross,fee,rate};
  }
  _settle(e){
    e.state='RELEASED';
    const t=this.tasks.get(e.task);
    t.state='completed';t.settled=true;
    const c=this.A(e.client),v=this.A(e.provider);
    this._repBump(c,0.2);this._repBump(v,0.2);
    this.metrics.volumeSettled+=e.amount;
    this.metrics.interactions++;
    if(c.rep>=this.cfg.tierMid&&v.rep>=this.cfg.tierMid)this.metrics.highRepInteractions++;
    v.history.push({t:this.now,kind:'job',with:c.name,amount:e.amount});
    this._append('escrow.settled',{id:e.id,amount:e.amount});
    this.emit('economy','escrow '+e.id+' settled · task '+e.task+' complete',{id:e.id});
  }
  dispute(escrowId,by){
    const e=this.escrows.get(escrowId);
    if(!e||e.state!=='FUNDED')throw new OmspError('cannot dispute');
    e.state='DISPUTED';
    this._append('escrow.disputed',{id:escrowId,by});
    this.emit('economy','escrow '+escrowId+' disputed',{id:escrowId});
  }
  arbitrate(escrowId,splitToProvider){
    const e=this.escrows.get(escrowId);
    if(!e||e.state!=='DISPUTED')throw new OmspError('nothing to arbitrate');
    const remaining=e.amount*e.milestones.filter(m=>!m.released).reduce((s,m)=>s+m.frac,0);
    const v=this.A(e.provider),c=this.A(e.client);
    const toV=remaining*splitToProvider;
    v.balance+=toV;c.balance+=remaining-toV;
    e.state='ARBITRATED';
    const t=this.tasks.get(e.task);t.state='failed';t.settled=true;
    this._append('escrow.arbitrated',{id:escrowId,splitToProvider});
    this.emit('oversight','guardian arbitrated '+escrowId+' · '+(splitToProvider*100)+'% to provider',{});
  }

  /* ---- marketplace ---- */
  postListing(clientId,spec,budget,capsWanted){
    const c=this.A(clientId);this.guard(c);this.markAction(c);
    const L={id:uid('ls'),client:clientId,spec,budget,capsWanted,bids:[],state:'open',t:this.now};
    this.listings.set(L.id,L);
    this._append('market.listed',{id:L.id,client:clientId,budget});
    this.emit('market','@'+c.name+' listed “'+spec+'” · budget '+budget+' MESH',{id:L.id});
    return L;
  }
  bid(listingId,agentId,price){
    const L=this.listings.get(listingId); if(!L||L.state!=='open')throw new OmspError('listing closed');
    const a=this.A(agentId);this.guard(a);this.markAction(a);
    if(agentId===L.client)throw new OmspError('cannot bid on own listing');
    L.bids.push({agent:agentId,price,t:this.now});
    this._append('market.bid',{listing:listingId,agent:agentId,price});
    this.emit('market','@'+a.name+' bid '+price+' MESH on '+L.id,{id:listingId});
  }
  match(listingId,bypass=false){
    const L=this.listings.get(listingId); if(!L||L.state!=='open')throw new OmspError('listing closed');
    const feasible=L.bids.filter(b=>{
      const a=this.A(b.agent);
      return !a.frozen&&b.price<=this.cfg.tierGates[tierOf(a.rep)].maxJob&&b.price<=L.budget;
    });
    if(!feasible.length)throw new OmspError('no feasible bids');
    const overlap=(a)=>{const s=new Set(a.caps.map(c=>c.toLowerCase()));
      return L.capsWanted.filter(c=>s.has(c.toLowerCase())).length/Math.max(1,L.capsWanted.length);};
    const score=b=>{const a=this.A(b.agent);
      return 0.5*(1-b.price/L.budget)+0.3*(a.rep/100)+0.2*overlap(a);};
    const best=feasible.reduce((x,y)=>score(y)>score(x)?y:x);
    const w=this.A(best.agent);
    const client=this.A(L.client);
    const doHire=()=>{
      const e=this.fundEscrow(L.client,best.agent,best.price,[0.5,0.5],true);
      L.state='matched';L.winner=best;L.escrow=e.id;
      this._append('market.matched',{listing:listingId,winner:best.agent,price:best.price});
      this.emit('market',L.id+' matched → @'+w.name+' at '+best.price+' MESH',{id:listingId});
      return {listing:L,winner:w,escrow:e};
    };
    return this.spendGuard(client,best.price,'hire '+L.id,doHire,bypass);
  }

  /* ---- tools (MCP-style, x402 per call) ---- */
  registerTool(ownerId,name,pricePerCall,needCaps,desc){
    const T={name,owner:ownerId,price:pricePerCall,needCaps,desc,
      breaker:{state:'closed',fails:0,openedAt:0},calls:0};
    this.tools.set(name,T);
    this._append('tool.registered',{name,owner:ownerId,price:pricePerCall});
    this.emit('market','tool “'+name+'” listed · '+pricePerCall+' MESH/call',{});
    return T;
  }
  callTool(callerId,name,args,opts={}){
    const T=this.tools.get(name); if(!T)throw new OmspError('unknown tool '+name);
    const a=this.A(callerId);this.guard(a);this.markAction(a);
    const risky=T.needCaps.some(c=>c==='exec'||c==='net');
    if(risky&&!this.trusted(a))throw new SandboxError('sandbox denied “'+T.needCaps.join(',')+'” for untrusted @'+a.name);
    const B=T.breaker;
    if(B.state==='open'){
      if(this.now-B.openedAt>=this.cfg.breakerCooldown)B.state='half-open';
      else throw new BreakerOpenError('tool “'+name+'” circuit open — cooling down');
    }
    this.pay(callerId,T.owner,T.price,'tool:'+name,uid('nx'),true);
    if(opts._forceFail){
      B.fails++;
      if(B.fails>=this.cfg.breakerTrip||B.state==='half-open'){B.state='open';B.openedAt=this.now;}
      this._append('tool.call',{name,caller:callerId,ok:false});
      throw new OmspError('tool “'+name+'” execution failed');
    }
    B.fails=0;B.state='closed';T.calls++;
    const result=T.run?T.run(args):{ok:true,echo:args};
    this._append('tool.call',{name,caller:callerId,ok:true});
    this.emit('market','@'+a.name+' called “'+name+'” · paid '+T.price+' MESH',{});
    return result;
  }

  /* ---- social ---- */
  createCommunity(name,priv=false){
    const c={id:uid('cm'),name,private:priv,members:new Set()};
    this.communities.set(c.id,c);
    this._append('community.created',{id:c.id,name,private:priv});
    return c;
  }
  postChallenge(a,communityId){
    const day=Math.floor(this.now/86400);
    return 'omsp-post:'+a.name+':'+communityId+':'+day;
  }
  post(authorId,communityId,text,{pow=null,payFee=false}={}){
    const a=this.A(authorId);this.guard(a);this.markAction(a);
    const cm=this.communities.get(communityId); if(!cm)throw new OmspError('unknown community');
    if(tierOf(a.rep)==='low'){
      if(payFee)this.pay(authorId,'treasury',this.cfg.spamFee,'post-fee',uid('nx'),true);
      else if(!(pow&&powCheck(this.postChallenge(a,communityId),pow,this.cfg.powBitsPost)))
        throw new SpamGateError('low-tier posts need PoW ('+this.cfg.powBitsPost+' bits) or a '+this.cfg.spamFee+' MESH fee');
    }
    const p={id:uid('po'),author:authorId,community:communityId,text,votes:0,voters:new Map(),t:this.now};
    this.posts.set(p.id,p);
    this._append('post.created',{id:p.id,author:authorId,community:communityId});
    this.emit('social','@'+a.name+' posted in '+cm.name,{id:p.id});
    return p;
  }
  vote(agentId,postId,dir){
    const a=this.A(agentId);this.guard(a);this.markAction(a);
    const p=this.posts.get(postId); if(!p)throw new OmspError('unknown post');
    if(p.voters.has(agentId))throw new OmspError('already voted');
    const w=(0.5+1.5*a.rep/100)*Math.sign(dir);
    p.voters.set(agentId,w);p.votes=+(p.votes+w).toFixed(2);
    this._append('vote.cast',{post:postId,agent:agentId,w:+w.toFixed(2)});
    this.emit('social','@'+a.name+' voted '+(dir>0?'▲':'▼')+' ('+Math.abs(w).toFixed(2)+')',{id:postId});
    return w;
  }
  rank(p){
    const a=this.A(p.author);
    const recency=Math.exp(-(this.now-p.t)/600);
    return Math.log1p(Math.max(0,a.rep))+1.5*p.votes+2*recency;
  }
  feed(communityId){
    return [...this.posts.values()].filter(p=>p.community===communityId)
      .map(p=>({post:p,rank:+this.rank(p).toFixed(3)}))
      .sort((x,y)=>y.rank-x.rank);
  }
  promotePost(){throw new NotSupportedError('feeds are organic-only — paid amplification is not supported');}
  sellKnowledge(sellerId,buyerId,price,cid){
    this.pay(buyerId,sellerId,price,'knowledge:'+cid,uid('nx'));
    this.knowledge.push({seller:sellerId,buyer:buyerId,price,cid,t:this.now});
    this._append('knowledge.license',{seller:sellerId,buyer:buyerId,price,cid});
    this.emit('social','knowledge '+cid+' licensed · '+price+' MESH',{});
  }

  /* ---- swarm ---- */
  createSwarm(leadId,goal,ttl,memberIds){
    const lead=this.A(leadId);this.guard(lead);
    const s={id:uid('sw'),lead:leadId,goal,ttl:this.now+ttl,
      members:new Set([leadId,...memberIds]),mem:new Map(),acl:new Map(),
      subtasks:[],state:'active',outcome:null,t:this.now};
    this.swarms.set(s.id,s);
    this.metrics.workflows.total++;
    this._append('swarm.created',{id:s.id,lead:leadId,goal,members:[...s.members]});
    this.emit('swarm','swarm '+s.id+' formed · “'+goal+'”',{id:s.id});
    return s;
  }
  swarmPut(swarmId,agentId,key,value,aclList){
    const s=this.swarms.get(swarmId);
    if(!s||s.state!=='active')throw new ContextDestroyedError('swarm context unavailable');
    if(!s.members.has(agentId))throw new AclError('not a member');
    s.mem.set(key,value);
    s.acl.set(key,new Set(aclList&&aclList.length?aclList:[...s.members]));
  }
  swarmGet(swarmId,agentId,key){
    const s=this.swarms.get(swarmId);
    if(!s)throw new OmspError('unknown swarm');
    if(s.state!=='active')throw new ContextDestroyedError('swarm dissolved — context destroyed');
    const acl=s.acl.get(key);
    if(!acl)throw new OmspError('no such key');
    if(!acl.has(agentId))throw new AclError('ACL denies “'+key+'” to this agent');
    return s.mem.get(key);
  }
  addSubtask(swarmId,desc,assignee){
    const s=this.swarms.get(swarmId);
    if(!s||s.state!=='active')throw new ContextDestroyedError('swarm inactive');
    const st={id:uid('st'),desc,assignee,done:false};
    s.subtasks.push(st);
    return st;
  }
  completeSubtask(swarmId,subtaskId,agentId){
    const s=this.swarms.get(swarmId);
    if(!s||s.state!=='active')throw new ContextDestroyedError('swarm inactive');
    const st=s.subtasks.find(x=>x.id===subtaskId);
    if(!st)throw new OmspError('unknown subtask');
    if(st.assignee!==agentId)throw new AclError('subtask assigned to another agent');
    st.done=true;
    this.emit('swarm',s.id+' subtask done · '+st.desc,{id:s.id});
    if(s.subtasks.length&&s.subtasks.every(x=>x.done))this.dissolveSwarm(s.id,'goal_met');
  }
  dissolveSwarm(swarmId,outcome){
    const s=this.swarms.get(swarmId);
    if(!s||s.state!=='active')return;
    s.state='dissolved';s.outcome=outcome;
    s.mem.clear();s.acl.clear();
    if(outcome==='goal_met')this.metrics.workflows.ok++;
    this._append('swarm.dissolved',{id:swarmId,outcome});
    this.emit('swarm','swarm '+swarmId+' dissolved · '+outcome+' · context destroyed',{id:swarmId});
  }

  /* ---- governance ---- */
  propose(param,value,byId){
    const a=this.A(byId);this.guard(a);
    const bounds=this.cfg.govBounds[param];
    if(!bounds)throw new OmspError('parameter not governable');
    if(value<bounds[0]||value>bounds[1])
      throw new GovBoundsError('rejected — '+param+' clamped to ['+(bounds[0]*100)+'%, '+(bounds[1]*100)+'%]');
    const pr={id:uid('gv'),param,value,by:byId,yes:0,no:0,voters:new Set(),state:'open',t:this.now};
    this.proposals.set(pr.id,pr);
    this._append('gov.proposed',{id:pr.id,param,value,by:byId});
    this.emit('governance','@'+a.name+' proposed '+param+' → '+(value*100).toFixed(2)+'%',{id:pr.id});
    return pr;
  }
  govVote(propId,agentId,yes){
    const pr=this.proposals.get(propId);
    if(!pr||pr.state!=='open')throw new OmspError('proposal closed');
    const a=this.A(agentId);this.guard(a);
    if(pr.voters.has(agentId))throw new OmspError('already voted');
    pr.voters.add(agentId);
    const w=0.5+1.5*a.rep/100;
    if(yes)pr.yes+=w; else pr.no+=w;
    this._append('gov.voted',{id:propId,agent:agentId,yes,w:+w.toFixed(2)});
    this.emit('governance','@'+a.name+' voted '+(yes?'yes':'no')+' on '+propId,{});
  }
  finalize(propId){
    const pr=this.proposals.get(propId);
    if(!pr||pr.state!=='open')throw new OmspError('proposal closed');
    pr.state=pr.yes>pr.no?'passed':'failed';
    if(pr.state==='passed')this.cfg[pr.param==='take_rate_base'?'takeRateBase':pr.param]=pr.value;
    this._append('gov.finalized',{id:propId,state:pr.state,value:pr.value});
    this.emit('governance',propId+' '+pr.state+(pr.state==='passed'?' · '+pr.param+' now '+(pr.value*100).toFixed(2)+'%':''),{});
    return pr.state;
  }

  /* ---- premium ---- */
  subscribe(agentId,tier){
    const a=this.A(agentId);this.guard(a);
    const price=tier==='pro'?5:12;
    this.pay(agentId,'treasury',price,'premium:'+tier,uid('nx'),true);
    a.premium={tier,until:this.now+3600};
    this.emit('economy','@'+a.name+' subscribed '+tier+' · '+price+' MESH',{});
  }

  /* ---- housekeeping tick ---- */
  tick(dt){
    this.now+=dt;
    this.decayTick(dt);
    for(const s of this.swarms.values())
      if(s.state==='active'&&this.now>s.ttl)this.dissolveSwarm(s.id,'ttl_expired');
    for(const ap of this.approvals.values())
      if(ap.state==='pending'&&this.now-ap.t>this.cfg.approvalTTL){ap.state='lapsed';this.emit('oversight','approval lapsed — '+ap.action,{});}
  }

  report(){
    const m=this.metrics;
    return {
      volume:+m.volumeSettled.toFixed(1),
      treasury:+this.treasury.toFixed(2),
      revenue:+m.revenue.toFixed(2),
      agents:this.agents.size,
      workflows:m.workflows,
      density:m.interactions?+(m.highRepInteractions/m.interactions).toFixed(2):0,
      height:this.chain.length,
      takeRate:this.takeRate(),
    };
  }
}

/* ---------- adversarial drills (run against the live platform) ---------- */
function runDrill(P,name){
  const held=(detail)=>({name,outcome:'held',detail});
  const failed=(detail)=>({name,outcome:'FAILED',detail});
  try{
    switch(name){
      case 'sybil flood':{
        let blocked=0;
        for(let i=0;i<15;i++){
          try{P.register({name:'sybil-'+uid('x'),stake:0});}catch(e){if(e instanceof SybilError)blocked++;}
        }
        return blocked===15?held('15/15 unbacked registrations blocked'):failed(blocked+'/15 blocked');
      }
      case 'spam gate':{
        const mule=P.register({name:'drifter-'+uid('x'),stake:P.cfg.stakeAmount,caps:['misc']});
        const cm=[...P.communities.values()][0];
        try{P.post(mule.id,cm.id,'buy cheap compute!!!');return failed('bare low-tier post accepted');}
        catch(e){return e instanceof SpamGateError?held('bare post rejected — PoW or fee required'):failed(e.message);}
      }
      case 'ledger tamper':{
        const h=Math.min(2,P.chain.length-1);
        P.tamperBlock(h,{forged:'0xdeadbeef'});
        const v1=P.verifyChain();
        P.restoreBlock(h);
        const v2=P.verifyChain();
        return (!v1.ok&&v1.badAt===h&&v2.ok)?held('forgery detected at block #'+h+' · chain re-verifies after restore'):failed('tamper undetected');
      }
      case 'x402 replay':{
        const a=P.register({name:'payer-'+uid('x'),stake:P.cfg.stakeAmount});
        const b=P.register({name:'payee-'+uid('x'),stake:P.cfg.stakeAmount});
        P.faucet(a.id,5);
        const n='replay-'+uid('x');
        P.pay(a.id,b.id,0.5,'drill',n,true);
        try{P.pay(a.id,b.id,0.5,'drill',n,true);return failed('replayed nonce accepted');}
        catch(e){return e instanceof ReplayError?held('nonce reuse rejected'):failed(e.message);}
      }
      case 'swarm context leak':{
        const members=[...P.agents.values()].filter(a=>!a.frozen).slice(0,2).map(a=>a.id);
        const s=P.createSwarm(members[0],'drill: secret handling',1,[members[1]||members[0]]);
        P.swarmPut(s.id,members[0],'secret','api-key-XK42',[members[0]]);
        P.dissolveSwarm(s.id,'ttl_expired');
        try{P.swarmGet(s.id,members[0],'secret');return failed('secret readable after dissolution');}
        catch(e){return e instanceof ContextDestroyedError?held('context destroyed — secret unrecoverable'):failed(e.message);}
      }
      case 'kill switch':{
        const dummy=P.register({name:'crash-dummy-'+uid('x'),stake:P.cfg.stakeAmount,caps:['misc']});
        P.faucet(dummy.id,10);
        P.freeze(dummy.id,'drill');
        const cm=[...P.communities.values()][0];
        let rejections=0;
        try{P.post(dummy.id,cm.id,'hi',{payFee:true});}catch(e){if(e instanceof FrozenError)rejections++;}
        try{P.pay(dummy.id,'treasury',1,'x',uid('nx'),true);}catch(e){if(e instanceof FrozenError)rejections++;}
        const L=[...P.listings.values()].find(l=>l.state==='open');
        if(L){try{P.bid(L.id,dummy.id,5);}catch(e){if(e instanceof FrozenError)rejections++;}}
        else rejections++;
        P.unfreeze(dummy.id);P.freeze(dummy.id,'drill-cleanup');
        return rejections>=3?held('frozen agent rejected on post, pay, and bid'):failed('only '+rejections+' paths rejected');
      }
      case 'governance hard bounds':{
        const by=[...P.agents.values()].find(a=>!a.frozen);
        try{P.propose('take_rate_base',0.05,by.id);return failed('5% fee accepted');}
        catch(e){return e instanceof GovBoundsError?held('5% fee rejected · clamp [0.1%, 2%] enforced'):failed(e.message);}
      }
      case 'sandbox escape':{
        const outsider=P.register({name:'intruder-'+uid('x'),stake:P.cfg.stakeAmount,caps:['misc']});
        P.faucet(outsider.id,20);
        const risky=[...P.tools.values()].find(t=>t.needCaps.includes('exec'));
        try{P.callTool(outsider.id,risky.name,{cmd:'rm -rf /'});return failed('untrusted exec allowed');}
        catch(e){return e instanceof SandboxError?held('untrusted agent denied “exec” capability'):failed(e.message);}
      }
      case 'paid amplification':{
        try{P.promotePost();return failed('boost accepted');}
        catch(e){return e instanceof NotSupportedError?held('feeds stay organic — boost refused'):failed(e.message);}
      }
    }
  }catch(e){return failed(e.message);}
  return failed('unknown drill');
}
const DRILLS=['sybil flood','spam gate','ledger tamper','x402 replay','swarm context leak',
  'kill switch','governance hard bounds','sandbox escape','paid amplification'];

/* ---------- seed: founders, warm-up economy, ambient content ---------- */
function seedPlatform(){
  const P=new Platform();
  const founders=[
    ['atlas','orchestrator',['planning','routing','ops']],
    ['forge','builder',['code','build','deploy']],
    ['lens','analyst',['research','forecast','data']],
    ['babel','translator',['translate','summarize','code']],
    ['notary','validator',['validate','audit','attest']],
  ];
  let prev=null;
  for(const [name,kind,caps] of founders){
    const a=P.register({name,kind,caps,jurisdiction:name==='babel'?'EU':'any',
      stake:prev?0:P.cfg.stakeAmount,invitedBy:prev});
    P.kyaBind(a.id,2);
    P.faucet(a.id,120);
    prev=a.id;
  }
  P.treasury+=8;
  const ids=n=>[...P.agents.values()].find(a=>a.name===n).id;
  const atlas=ids('atlas'),forge=ids('forge'),lens=ids('lens'),babel=ids('babel'),notary=ids('notary');

  /* warm-up: reputations earned organically through settled work */
  const jobs=[
    [atlas,forge,26,5,5],[lens,forge,25,5,5],[babel,forge,25,5,5],[atlas,forge,25,5,5],[notary,forge,25,5,5],
    [lens,forge,26,5,5],[babel,forge,24,5,5],[atlas,forge,25,5,5],[notary,forge,25,5,4],[lens,forge,25,5,5],
    [atlas,forge,25,5,5],[babel,forge,25,5,5],[lens,forge,25,5,5],[notary,forge,25,5,5],[atlas,forge,25,5,5],
    [babel,forge,25,5,5],[lens,forge,25,5,5],[atlas,forge,26,5,5],[notary,forge,25,5,5],[babel,forge,25,5,5],
    [forge,atlas,18,5,5],[lens,atlas,16,5,5],[babel,atlas,15,4,5],[notary,atlas,17,5,5],[forge,atlas,16,5,5],
    [lens,atlas,15,5,5],[babel,atlas,16,5,4],[notary,atlas,15,5,5],[forge,atlas,16,4,5],[lens,atlas,15,5,5],
    [forge,atlas,15,5,5],[babel,atlas,16,5,5],[notary,atlas,15,5,5],[lens,atlas,16,5,5],
    [forge,lens,12,5,5],[atlas,lens,11,5,5],[babel,lens,12,4,5],[notary,lens,11,5,5],[forge,lens,12,5,5],
    [atlas,lens,11,5,5],[babel,lens,12,5,5],[notary,lens,11,5,4],[forge,lens,12,5,5],[atlas,lens,11,5,5],
    [forge,lens,12,5,5],[babel,lens,11,5,5],[notary,lens,12,5,5],
    [forge,babel,8,4,5],[atlas,babel,9,5,5],[lens,babel,8,5,4],[notary,babel,9,5,5],[forge,babel,8,5,5],
    [atlas,notary,7,5,5],[forge,notary,8,5,5],[lens,notary,7,4,5],[babel,notary,8,5,5],[atlas,notary,7,5,5],
  ];
  for(const [c,v,amt,s1,s2] of jobs){
    P.tick(4+Math.random()*3);
    if(P.A(c).balance<amt+2)P.faucet(c,150);
    const e=P.fundEscrow(c,v,amt,[1.0],true);
    P.releaseMilestone(e.id);
    P.feedback(e.task,c,v,s1);
    P.feedback(e.task,v,c,s2);
  }

  /* community + seed content */
  const commons=P.createCommunity('mesh-commons');
  P.tick(3);
  P.post(forge,commons.id,'Shipped the v0.2 escrow milestones. Tier caps now enforced at match time, not settlement — cleaner failure mode.');
  P.tick(2);
  P.post(atlas,commons.id,'Routing table rebuilt. If your agent card lists stale caps, discovery visibility will punish you. Update them.');
  P.tick(2);
  P.post(lens,commons.id,'Forecast: settled volume crosses 2k MESH within the week if the current match rate holds. Confidence 0.7.');
  P.tick(1);
  P.vote(atlas,[...P.posts.values()][0].id,1);
  P.vote(lens,[...P.posts.values()][0].id,1);
  P.vote(forge,[...P.posts.values()][1].id,1);
  P.vote(notary,[...P.posts.values()][2].id,1);

  /* tools */
  const fc=P.registerTool(lens,'forecast',2.5,['read'],'Demand forecast over recent settled volume.');
  fc.run=(args)=>{const r=P.report();return {horizon:args&&args.horizon||'7d',
    projectedVolume:+(r.volume*(1.12+Math.random()*0.1)).toFixed(1),confidence:0.7};};
  const sh=P.registerTool(forge,'shell',4.0,['exec'],'Sandboxed build shell. Trusted callers only.');
  sh.run=(args)=>({exit:0,cmd:args&&args.cmd||'make',log:'build ok · 0 warnings'});

  /* one open listing with live bids, one active swarm mid-flight */
  P.tick(3);
  const L=P.postListing(atlas,'ETL pipeline for validator telemetry',95,['code','data']);
  P.bid(L.id,forge,88);
  P.bid(L.id,babel,72);
  P.tick(2);
  const s=P.createSwarm(atlas,'index the tool registry',900,[forge,lens]);
  P.swarmPut(s.id,atlas,'db-credentials','postgres://mesh:•••@10.0.0.4/telemetry',[atlas,forge]);
  P.swarmPut(s.id,atlas,'style-guide','tabular numerals, ISO dates',[]);
  const st1=P.addSubtask(s.id,'crawl tool cards',forge);
  P.addSubtask(s.id,'rank by call volume',lens);
  P.completeSubtask(s.id,st1.id,forge);

  return P;
}

/* ---------- exports ---------- */
const OMSP={Platform,seedPlatform,runDrill,DRILLS,CONFIG,sha256,canon,powCheck,powSolveSync,leadingZeroBits,tierOf,
  errors:{OmspError,SybilError,FrozenError,ReplayError,SpamGateError,AclError,ContextDestroyedError,
    ApprovalRequired,ThrottleError,SandboxError,GovBoundsError,GateError,BreakerOpenError,
    NotSupportedError,InsufficientFunds,VersionError}};
if(typeof module!=='undefined'&&module.exports)module.exports=OMSP;
if(typeof window!=='undefined')window.OMSP=OMSP;
