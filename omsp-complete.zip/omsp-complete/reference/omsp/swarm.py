"""Swarm formation primitives. [REQ-5.3]

Temporary multi-agent teams with:
- shared secure context: per-key ACLs (readers/writers) on a shared memory;
- subtask assignment tracked to completion;
- automatic dissolution when the goal is met or the TTL expires, after which
  the shared memory is destroyed and all access raises SwarmDissolvedError.
"""
from __future__ import annotations

import itertools

from .config import AuthorizationError, SwarmDissolvedError


class SharedMemory:
    def __init__(self, swarm: "Swarm"):
        self._swarm = swarm
        self._store: dict[str, object] = {}
        self._acl: dict[str, dict] = {}

    def _check_alive(self):
        if self._swarm.dissolved:
            raise SwarmDissolvedError(
                f"swarm {self._swarm.id} dissolved; shared context destroyed")

    def set_acl(self, key: str, *, readers: set[int], writers: set[int]) -> None:
        self._check_alive()
        self._acl[key] = {"readers": set(readers), "writers": set(writers)}

    def write(self, agent_id: int, key: str, value) -> None:
        self._check_alive()
        acl = self._acl.get(key)
        allowed = self._swarm.members if acl is None else acl["writers"]
        if agent_id not in allowed:
            raise AuthorizationError(f"agent {agent_id} may not write '{key}'")
        self._store[key] = value

    def read(self, agent_id: int, key: str):
        self._check_alive()
        acl = self._acl.get(key)
        allowed = self._swarm.members if acl is None else acl["readers"]
        if agent_id not in allowed:
            raise AuthorizationError(f"agent {agent_id} may not read '{key}'")
        return self._store[key]

    def _destroy(self):
        self._store.clear()
        self._acl.clear()


class Swarm:
    def __init__(self, platform, swarm_id: str, initiator: int,
                 members: set[int], goal: str, ttl: float):
        self.p = platform
        self.id = swarm_id
        self.initiator = initiator
        self.members = set(members) | {initiator}
        self.goal = goal
        self.expires = platform.clock.now() + ttl
        self.memory = SharedMemory(self)
        self.subtasks: dict[str, dict] = {}
        self.dissolved = False
        self.outcome: str | None = None

    def assign(self, subtask_id: str, assignee: int, description: str) -> dict:
        if self.dissolved:
            raise SwarmDissolvedError("swarm dissolved")
        if assignee not in self.members:
            raise AuthorizationError("assignee is not a swarm member")
        st = {"id": subtask_id, "assignee": assignee,
              "description": description, "done": False}
        self.subtasks[subtask_id] = st
        return st

    def complete_subtask(self, subtask_id: str, agent_id: int) -> None:
        if self.dissolved:
            raise SwarmDissolvedError("swarm dissolved")
        st = self.subtasks[subtask_id]
        if st["assignee"] != agent_id:
            raise AuthorizationError("only the assignee may complete a subtask")
        st["done"] = True
        if self.subtasks and all(s["done"] for s in self.subtasks.values()):
            self._dissolve("goal_met")

    def _dissolve(self, outcome: str) -> None:
        """Automatic dissolution: context destroyed, event committed. [REQ-5.3]"""
        if self.dissolved:
            return
        self.dissolved = True
        self.outcome = outcome
        self.memory._destroy()
        self.p.stats.record_workflow(success=(outcome == "goal_met"))
        self.p.ledger.commit("swarm.dissolved",
                             {"swarm": self.id, "outcome": outcome,
                              "members": sorted(self.members)},
                             actor=self.initiator)


class SwarmManager:
    def __init__(self, platform):
        self.p = platform
        self.swarms: dict[str, Swarm] = {}
        self._ids = itertools.count(1)

    def form(self, initiator: int, members: list[int], goal: str,
             ttl: float = 3600.0) -> Swarm:
        self.p.identity.guard(initiator)
        for m in members:
            self.p.identity.guard(m)
        self.p.rate.require(initiator)
        sw = Swarm(self.p, f"swarm-{next(self._ids)}", initiator, set(members),
                   goal, ttl)
        self.swarms[sw.id] = sw
        self.p.ledger.commit("swarm.formed",
                             {"swarm": sw.id, "goal": goal,
                              "members": sorted(sw.members)}, actor=initiator)
        return sw

    def tick(self) -> None:
        """TTL expiry -> automatic dissolution. [REQ-5.3]"""
        now = self.p.clock.now()
        for sw in self.swarms.values():
            if not sw.dissolved and now >= sw.expires:
                sw._dissolve("ttl_expired")
