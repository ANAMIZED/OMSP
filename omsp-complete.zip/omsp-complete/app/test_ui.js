'use strict';
const fs=require('fs'),vm=require('vm');
const OMSP=require('./engine.js');
const CSTL=require('./constellation.js');

/* ---- minimal DOM stub ---- */
function recCtx(){
  const rec={ops:0};
  const fn=()=>{rec.ops++;};
  return new Proxy(rec,{
    get:(t,k)=>{
      if(k in t)return t[k];
      if(k==='createLinearGradient'||k==='createRadialGradient')return ()=>({addColorStop(){}});
      if(k==='measureText')return ()=>({width:10});
      return fn;
    },
    set:(t,k,v)=>{t[k]=v;return true;},
  });
}
const CTX=recCtx();
class FE{
  constructor(tag){this.tag=tag;this.children=[];this.style={};this.dataset={};this.parent=null;
    this._cls='';this._html='';this._text='';this.hidden=false;this.disabled=false;this.type='';
    this.scrollTop=0;this.scrollLeft=0;this.scrollWidth=200;this.clientWidth=320;this.clientHeight=190;
    this.width=0;this.height=0;this.value='';
    if(tag==='canvas')this.getContext=()=>CTX;
    this.classList={
      toggle:(c,on)=>{const has=this._cls.split(/\s+/).includes(c);
        const want=on===undefined?!has:on;
        if(want&&!has)this._cls=(this._cls+' '+c).trim();
        if(!want&&has)this._cls=this._cls.split(/\s+/).filter(x=>x!==c).join(' ');},
    };
  }
  set className(v){this._cls=v} get className(){return this._cls}
  set innerHTML(v){this._html=v;if(v==='')this.children=[]} get innerHTML(){return this._html}
  set textContent(v){this._text=String(v);} get textContent(){return this._text}
  append(...ks){for(const k of ks){if(k==null)continue;if(k.parent!==undefined)k.parent=this;this.children.push(k);}}
  get firstChild(){return this.children[0]||null}
  get lastChild(){return this.children[this.children.length-1]||null}
  remove(){if(this.parent){const i=this.parent.children.indexOf(this);if(i>=0)this.parent.children.splice(i,1);this.parent=null;}}
  querySelector(){return null}
  setAttribute(){}
  addEventListener(){}
  onclickAll(fn){
    if(this.onclick&&!this.disabled)fn(this);
    for(const c of this.children)if(c instanceof FE)c.onclickAll(fn);
  }
}
const ids={};
for(const id of ['height','acting','tape','view','tabs','toasts','sheet'])ids[id]=new FE('div');
ids.cosmoswrap=new FE('div');ids.cosmoswrap.hidden=true;
ids.cosmofs=new FE('canvas');ids.cosmoclose=new FE('button');ids.cosmohint=new FE('div');
ids.cosmos=null; // hero canvas is created by renderPulse; resolve dynamically

function findByIdInView(id){
  let out=null;
  (function walk(n){if(out||!(n instanceof FE))return;
    if(n.id===id)out=n;
    for(const c of n.children)walk(c);})(ids.view);
  return out;
}

let intervalFn=null;
const timeouts=[],rafQ=[];
function pump(n){n=n||1;while(n--){const q=rafQ.splice(0);for(const f of q){try{f();}catch(e){fail++;console.error('FAIL raf cb:',e.message);}}}}
const sandbox={
  OMSP,CSTL,
  window:{addEventListener(){}},
  document:{
    readyState:'complete',
    getElementById:id=>ids[id]!==undefined?(id==='cosmos'?findByIdInView('cosmos'):ids[id]):null,
    createElement:t=>{const n=new FE(t);return n;},
    createTextNode:t=>({text:t,parent:undefined}),
    createDocumentFragment:()=>new FE('#frag'),
    addEventListener(){},
    activeElement:null,
  },
  requestAnimationFrame:fn=>{rafQ.push(fn);return rafQ.length;},
  setInterval:(fn)=>{intervalFn=fn;return 1;},
  setTimeout:(fn,ms)=>{timeouts.push(fn);return timeouts.length;},
  clearTimeout:()=>{},
  performance:{now:()=>Date.now()},
  console,Math,JSON,Object,Array,Set,Map,Proxy,
};
sandbox.globalThis=sandbox;
sandbox.window.CSTL=CSTL;

let pass=0,fail=0;
const ok=(c,m)=>{c?pass++:(fail++,console.error('FAIL:',m));};

vm.createContext(sandbox);
vm.runInContext(fs.readFileSync('./ui.js','utf8'),sandbox,{filename:'ui.js'});
const dbg=sandbox.window.__omsp, P=sandbox.window.P;

ok(dbg&&P,'debug handles exposed');
ok(ids.view.children.length>0,'boot rendered pulse');
ok(ids.tabs.children.length===5,'five tabs built');
ok(ids.tape.children.length>0,'hash tape populated');
pump(4);
ok(dbg.cosmos&&dbg.cosmos.CO.G.nodes.size>=8,'constellation graph populated ('+dbg.cosmos.CO.G.nodes.size+' stars)');

function drain(cap,label){
  cap=cap||200000;let n=0;
  while(timeouts.length){
    if(++n>cap){fail++;console.error('FAIL: '+(label||'drain')+' exceeded '+cap);return;}
    const f=timeouts.shift();
    try{f();}catch(e){fail++;console.error('FAIL timeout cb ('+(label||'?')+'):',e.message);}
  }
}
function findBtn(root,pred){let out=null;
  (function walk(n){if(out||!(n instanceof FE))return;
    if(n.onclick&&!n.disabled&&pred(n))out=n;
    for(const c of n.children)walk(c);})(root);
  return out;}
function hasText(root,s){let hit=false;
  (function walk(n){if(hit)return;
    if(n instanceof FE){if(n._text&&n._text.includes(s))hit=true;for(const c of n.children)walk(c);}
    else if(n&&n.text&&n.text.includes(s))hit=true;})(root);
  return hit;}

for(const tab of ['feed','market','agents','system','pulse']){
  dbg.S.tab=tab;
  try{dbg.render();ok(ids.view.children.length>0,tab+' renders');}
  catch(e){fail++;console.error('FAIL render '+tab+':',e.stack.split('\n')[0]);}
}

const agents=[...P.agents.values()];
const tabs=['pulse','feed','market','agents','system'];
try{
  for(let i=0;i<600;i++){
    if(i%40===0)dbg.S.tab=tabs[(i/40)%5|0];
    if(i%90===0)dbg.S.acting=(i%180===0)?'guardian':agents[i%agents.length].id;
    dbg.S.speed=[1,4,1][i%3];
    intervalFn();
    pump(1);
    if(i%50===0)drain();
  }
  ok(true,'600 sim ticks + frames with tab/actor churn — no exceptions');
}catch(e){fail++;console.error('FAIL sim loop:',e.stack.split('\n').slice(0,3).join(' | '));}

ok(P.verifyChain().ok,'chain verifies after long ambient run ('+P.chain.length+' blocks)');
ok(P.chain.length>360,'ambient economy grew the chain');
ok([...P.escrows.values()].some(e=>e.state==='RELEASED'),'ambient escrows settled');
ok([...P.posts.values()].length>3,'ambient posts flowed');
ok(P.metrics.workflows.total>=1,'swarms ran');
ok(dbg.cosmos.CO.G.height===P.chain.length,'constellation synced to full chain height');
ok(CTX.ops>200,'constellation drew frames through the ctx ('+CTX.ops+' ops)');

function crawl(label){
  let clicks=0,errs=0;
  for(const tab of tabs){
    dbg.S.tab=tab;dbg.render();
    ids.view.onclickAll(n=>{clicks++;try{n.onclick();}catch(e){errs++;console.error('FAIL click['+label+'/'+tab+'] <'+n.tag+' '+n._cls+'>:',e.message);}});
    dbg.closeSheet();
  }
  drain();
  return {clicks,errs};
}
dbg.S.acting='guardian';
let r=crawl('guardian');
ok(r.errs===0,'guardian click-crawl: '+r.clicks+' handlers, '+r.errs+' errors');
dbg.S.acting=agents.find(a=>a.name==='forge').id;
r=crawl('forge');
ok(r.errs===0,'forge click-crawl: '+r.clicks+' handlers, '+r.errs+' errors');
const lowT=[...P.agents.values()].find(a=>OMSP.tierOf(a.rep)==='low'&&!a.frozen);
if(lowT){dbg.S.acting=lowT.id;r=crawl('low-tier');ok(r.errs===0,'low-tier click-crawl: '+r.clicks+' handlers, '+r.errs+' errors');}
dbg.cosmos.closeCosmos();

drain();drain();
const dr=Object.values(dbg.S.drillResults);
for(const x of dr)if(x.outcome!=='held')console.error('  drill not held →',x.name,'·',x.detail);
ok(dr.length===9,'all nine drills executed via UI ('+dr.length+')');
ok(dr.every(x=>x.outcome==='held'),'all drills HELD through the UI path');
ok(P.verifyChain().ok,'chain verifies after drills + crawl');

/* targeted flows */
dbg.S.acting='guardian';dbg.S.tab='agents';dbg.render();
dbg.S.regDraft.name='harness-miner';dbg.S.regDraft.caps='probe,audit';
dbg.render();
const mineBtn=findBtn(ids.view,n=>n._text&&n._text.indexOf('Mine PoW')===0);
ok(!!mineBtn,'register Mine PoW button found');
mineBtn.onclick();
ok(!ids.sheet.hidden,'mining sheet opened without throwing');
drain(400000,'mining-register');
ok([...P.agents.values()].some(a=>a.name==='harness-miner'),'PoW registration flow end-to-end');

const miner=[...P.agents.values()].find(a=>a.name==='harness-miner');
dbg.S.acting=miner.id;dbg.S.tab='feed';dbg.S.draft='harness gate probe';dbg.render();
const postBtn=findBtn(ids.view,n=>n._text==='Post');
postBtn.onclick();
const gateMine=findBtn(ids.sheet,n=>n._text&&n._text.indexOf('Mine PoW')===0);
ok(!!gateMine,'spam-gate sheet offers PoW');
gateMine.onclick();
drain(400000,'mining-gate');
ok([...P.posts.values()].some(p=>p.text==='harness gate probe'),'spam-gate PoW flow end-to-end');
ok(dbg.S.draft==='','draft cleared after gated post');

dbg.S.acting='guardian';dbg.S.tab='system';dbg.render();
const row1=findBtn(ids.view,n=>n._cls&&n._cls.indexOf('blockrow')===0);
row1.onclick();
const tamperBtn=findBtn(ids.sheet,n=>n._text==='Tamper this block');
ok(!!tamperBtn,'tamper control present for guardian');
tamperBtn.onclick();
ok(dbg.S.lastVerify&&!dbg.S.lastVerify.ok,'verification breaks after tap-tamper');
dbg.render();
const badRow=findBtn(ids.view,n=>n._cls&&n._cls.indexOf('tampered')>=0);
ok(!!badRow,'tampered block visibly flagged');
badRow.onclick();
const restoreBtn=findBtn(ids.sheet,n=>n._text==='Restore original');
restoreBtn.onclick();
ok(dbg.S.lastVerify&&dbg.S.lastVerify.ok,'verification repairs after tap-restore');

dbg.S.tab='agents';dbg.render();
const forge=[...P.agents.values()].find(a=>a.name==='forge');
const forgeCard=findBtn(ids.view,n=>n._cls==='card'&&hasText(n,'forge'));
forgeCard.onclick();
const before=forge.balance;
const faucetBtn=findBtn(ids.sheet,n=>n._text==='Faucet +50');
faucetBtn.onclick();
ok(Math.abs(forge.balance-(before+50))<1e-9,'agent sheet faucet +50');

ids.acting.onclick();
const lens=[...P.agents.values()].find(a=>a.name==='lens');
const lensRow=findBtn(ids.sheet,n=>hasText(n,'lens'));
lensRow.onclick();
ok(dbg.S.acting===lens.id,'acting sheet switches identity');
drain();

/* ---- constellation flows ---- */
dbg.S.tab='pulse';dbg.render();pump(4);
const hero=findBtn(ids.view,n=>n.tag==='canvas');
ok(!!hero,'pulse hero canvas present + tappable');
hero.onclick();
ok(dbg.cosmos.CO.open===true&&ids.cosmoswrap.hidden===false,'tapping the hero opens fullscreen constellation');
const opsBefore=CTX.ops;pump(4);
ok(CTX.ops>opsBefore,'fullscreen frames drawing ('+(CTX.ops-opsBefore)+' new ops)');

dbg.cosmos.openWiki('a:'+forge.id);
ok(hasText(ids.sheet,'forge')&&hasText(ids.sheet,'Backlinks'),'wiki card renders with backlinks');
ok(hasText(ids.sheet,'[['),'obsidian wikilink chrome present');
const link=findBtn(ids.sheet,n=>n._cls==='wl');
ok(!!link,'tappable wikilink present');
link.onclick();
ok(hasText(ids.sheet,'Backlinks')||hasText(ids.sheet,'Links'),'wikilink navigates to another card');
dbg.closeSheet();
dbg.cosmos.openWiki('k:cid:nope');
ok(true,'missing star handled gracefully');
dbg.cosmos.closeCosmos();
ok(ids.cosmoswrap.hidden===true,'constellation closes');

dbg.S.tab='agents';dbg.render();
const fc2=findBtn(ids.view,n=>n._cls==='card'&&hasText(n,'forge'));
fc2.onclick();
const consBtn=findBtn(ids.sheet,n=>n._text&&n._text.indexOf('Star map')>=0);
ok(!!consBtn,'agent sheet offers the star map');
consBtn.onclick();
ok(dbg.cosmos.CO.open&&dbg.cosmos.CO.sel==='a:'+forge.id,'agent deep-link focuses their star');
dbg.cosmos.closeCosmos();
drain();

ok(P.verifyChain().ok,'chain verifies at end');
console.log('\nui harness: '+pass+' passed, '+fail+' failed · final report:',JSON.stringify(P.report()));
process.exit(fail?1:0);
