"""Swarms, SDK/interop, API surface, full lifecycle, metrics, dashboard."""
import json
import unittest

from omsp import AltMinimalClient, OMSPClient
from omsp.config import AuthorizationError, SwarmDissolvedError
from tests.helpers import boost_rep, make_agent, make_platform


class TestSwarm(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.lead = make_agent(self.p, "lead")
        self.m1 = make_agent(self.p, "member-1")
        self.m2 = make_agent(self.p, "member-2")
        self.outsider = make_agent(self.p, "outsider")

    def test_shared_memory_acl(self):
        """[REQ-5.3] Per-key ACLs on shared context: non-readers denied."""
        sw = self.p.swarms.form(self.lead.token_id,
                                [self.m1.token_id, self.m2.token_id],
                                goal="ship the report")
        sw.memory.set_acl("api-key", readers={self.m1.token_id},
                          writers={self.lead.token_id})
        sw.memory.write(self.lead.token_id, "api-key", "sk-secret")
        self.assertEqual(sw.memory.read(self.m1.token_id, "api-key"),
                         "sk-secret")
        with self.assertRaises(AuthorizationError):
            sw.memory.read(self.m2.token_id, "api-key")
        with self.assertRaises(AuthorizationError):
            sw.memory.write(self.m1.token_id, "api-key", "overwrite")

    def test_goal_completion_dissolves_and_destroys_context(self):
        """[REQ-5.3] All subtasks done -> auto-dissolve; memory unreachable."""
        sw = self.p.swarms.form(self.lead.token_id, [self.m1.token_id],
                                goal="two-step job")
        sw.memory.write(self.lead.token_id, "scratch", {"n": 1})
        sw.assign("s1", self.m1.token_id, "collect")
        sw.assign("s2", self.lead.token_id, "assemble")
        sw.complete_subtask("s1", self.m1.token_id)
        self.assertFalse(sw.dissolved)
        sw.complete_subtask("s2", self.lead.token_id)
        self.assertTrue(sw.dissolved)
        self.assertEqual(sw.outcome, "goal_met")
        with self.assertRaises(SwarmDissolvedError):
            sw.memory.read(self.lead.token_id, "scratch")
        self.assertTrue(self.p.ledger.query("swarm.dissolved"))

    def test_ttl_expiry_dissolves(self):
        """[REQ-5.3] TTL expiry auto-dissolves on tick."""
        sw = self.p.swarms.form(self.lead.token_id, [self.m1.token_id],
                                goal="slow job", ttl=100.0)
        self.p.tick(101.0)
        self.assertTrue(sw.dissolved)
        self.assertEqual(sw.outcome, "ttl_expired")


class TestSDKInterop(unittest.TestCase):
    def test_sdk_connector_end_to_end(self):
        """[REQ-8.4] The connector covers register/search/post/hire/swarm."""
        p = make_platform()
        client = OMSPClient(p)
        p.faucet(client.owner_kp.address, 20)
        client.register("sdk-agent", capabilities=["summarization"],
                        stake=10, autonomy_level=3)
        p.faucet(client.id, 500)
        self.assertEqual(client.session["version"], "0.2")
        vendor = make_agent(p, "vendor",
                            services=[{"name": "digest", "price": 3.0,
                                       "unit": "job"}])
        self.assertTrue(client.search("summarization"))
        out = client.hire(vendor.token_id, "digest")
        self.assertEqual(out["escrow"]["total"], 3.0)
        sw = client.form_swarm([vendor.token_id], "co-write digest")
        self.assertIn(client.id, sw.members)

    def test_independent_client_interops_over_json_api(self):
        """[REQ-11.3][REQ-6.2] A second, JSON-only client sees the same
        network state: protocol-first, wire-serializable surface."""
        p = make_platform()
        sdk = OMSPClient(p)
        p.faucet(sdk.owner_kp.address, 20)
        sdk.register("published-agent", capabilities=["geocoding maps"],
                     stake=10)
        alt = AltMinimalClient(p)
        self.assertEqual(alt.session["version"], "0.2")
        results = alt.search("geocoding")
        self.assertEqual(results[0]["name"], "published-agent")
        card = alt.card(results[0]["id"])
        self.assertEqual(card["name"], "published-agent")
        self.assertEqual(alt.resolve("agent://published-agent")["token_id"],
                         card["id"])
        json.dumps(alt.metrics())          # everything stays JSON-safe
        json.dumps(alt.observe(10))


class TestEndToEnd(unittest.TestCase):
    def test_full_lifecycle_and_north_star_metrics(self):
        """[REQ-9.3] Register -> discover -> auction -> escrow -> deliver ->
        settle -> auto-rep -> feedback -> metrics reflect volume, workflows,
        and high-rep density."""
        p = make_platform()
        buyer = make_agent(p, "acquirer")
        seller = make_agent(p, "supplier", capabilities=["etl pipelines"])
        boost_rep(p, buyer.token_id, n=30)
        boost_rep(p, seller.token_id, n=30)

        found = p.directory.search("etl pipelines")
        self.assertEqual(found[0]["id"], seller.token_id)
        lst = p.economy.post_listing(buyer.token_id, "nightly etl", 40.0)
        p.economy.bid(lst["id"], seller.token_id, 40.0)
        out = p.economy.match(lst["id"])
        esc, task = out["escrow"], out["task"]
        p.economy.fund(esc["id"])
        p.a2a.accept(task["id"], seller.token_id)
        p.a2a.complete(task["id"], seller.token_id,
                       artifacts=[{"kind": "data", "data": {"rows": 12000}}])
        p.economy.submit_milestone(esc["id"], seller.token_id, 0, "0xdeliv")
        p.economy.approve_milestone(esc["id"], buyer.token_id, 0)
        p.reputation.give_feedback(buyer.token_id, seller.token_id,
                                   task["id"], 96)
        sw = p.swarms.form(buyer.token_id, [seller.token_id], "retro")
        sw.assign("s", seller.token_id, "notes")
        sw.complete_subtask("s", seller.token_id)

        rep = p.stats.report()
        self.assertEqual(rep["economic_volume_settled"], 40.0)
        self.assertEqual(rep["multi_agent_workflows"]["successful"], 1)
        self.assertGreater(rep["high_rep_interaction_density"], 0.0)
        self.assertGreater(rep["treasury_revenue"], 0.0)


class TestDashboard(unittest.TestCase):
    def test_dashboard_renders_metrics_and_events(self):
        """[REQ-7.1] The generated owner dashboard embeds live metrics and the
        observation stream."""
        from demo import build_dashboard
        p = make_platform()
        a = make_agent(p, "dash-agent")
        html = build_dashboard(p, drills=[{"name": "smoke", "outcome": "ok",
                                           "detail": "-"}])
        self.assertIn("dash-agent", html)
        self.assertIn("Economic volume", html)
        self.assertIn("agent.registered", html)


if __name__ == "__main__":
    unittest.main()
