"""Communication layer.

- A2AHub: A2A-style task lifecycle (SUBMITTED/WORKING/INPUT_REQUIRED/COMPLETED/
  FAILED/CANCELED), multi-turn messages, handoff to child tasks. [REQ-3.1]
- Schema registry: structured payloads validated before dispatch. [REQ-3.3]
- ThreadStore: persistent multi-party threads. [REQ-3.4]
- ToolRegistry: MCP-style tools with input schemas [REQ-3.2], per-call licensing
  settled over x402 [REQ-5.4], sandbox policy for untrusted callers [REQ-6.3],
  and a circuit breaker per tool [REQ-11.2].
- negotiate_version(): protocol version negotiation. [REQ-11.4]
"""
from __future__ import annotations

import itertools
from enum import Enum

from .config import (PROTOCOL_VERSIONS, AuthorizationError, SchemaError,
                     VersionError)


class TaskState(str, Enum):
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


# Minimal schema language: {field: type | (types,)}; extra fields allowed.
SCHEMAS = {
    "task.request.v1": {"goal": str, "budget": (int, float), "deadline": (int, float)},
    "task.handoff.v1": {"goal": str, "parent": str},
    "post.signal.v1": {"kind": str, "capability": str, "detail": str},
}


def validate_schema(schema_id: str, payload: dict) -> None:
    """Structured payloads preferred over free text. [REQ-3.3]"""
    schema = SCHEMAS.get(schema_id)
    if schema is None:
        raise SchemaError(f"unknown schema {schema_id}")
    if not isinstance(payload, dict):
        raise SchemaError("payload must be an object")
    for field, types in schema.items():
        if field not in payload:
            raise SchemaError(f"missing required field '{field}' ({schema_id})")
        if not isinstance(payload[field], types):
            raise SchemaError(f"field '{field}' has wrong type ({schema_id})")


def negotiate_version(client_versions: list[str]) -> str:
    """Pick the highest mutually supported protocol version. [REQ-11.4]"""
    mutual = [v for v in PROTOCOL_VERSIONS if v in client_versions]
    if not mutual:
        raise VersionError(
            f"no mutual version; platform supports {PROTOCOL_VERSIONS} -- upgrade client")
    return sorted(mutual)[-1]


class A2AHub:
    def __init__(self, platform):
        self.p = platform
        self.tasks: dict[str, dict] = {}
        self._ids = itertools.count(1)

    def _new_id(self) -> str:
        return f"task-{next(self._ids)}"

    def create_task(self, frm: int, to: int, payload: dict,
                    schema_id: str = "task.request.v1") -> dict:
        """Peer task submission. [REQ-3.1]"""
        self.p.identity.guard(frm)
        self.p.identity.guard(to)
        self.p.rate.require(frm)
        self.p.safety.observe_action(frm)
        validate_schema(schema_id, payload)                      # [REQ-3.3]
        task = {"id": self._new_id(), "from": frm, "to": to, "schema": schema_id,
                "payload": payload, "state": TaskState.SUBMITTED.value,
                "messages": [], "artifacts": [], "parent": payload.get("parent"),
                "children": [], "created": self.p.clock.now(), "completed": None}
        self.tasks[task["id"]] = task
        self.p.ledger.commit("a2a.task_created",
                             {"task": task["id"], "from": frm, "to": to}, actor=frm)
        return task

    def _transition(self, task_id: str, actor: int, state: TaskState) -> dict:
        task = self.tasks[task_id]
        self.p.identity.guard(actor)
        if actor not in (task["from"], task["to"]):
            raise AuthorizationError("not a task participant")
        task["state"] = state.value
        self.p.ledger.commit("a2a.task_state",
                             {"task": task_id, "state": state.value}, actor=actor)
        return task

    def accept(self, task_id: str, actor: int) -> dict:
        return self._transition(task_id, actor, TaskState.WORKING)

    def require_input(self, task_id: str, actor: int, question: str) -> dict:
        task = self._transition(task_id, actor, TaskState.INPUT_REQUIRED)
        self.message(task_id, actor, [{"kind": "text", "text": question}])
        return task

    def message(self, task_id: str, frm: int, parts: list[dict]) -> dict:
        """Multi-turn coordination on a task. [REQ-3.1]"""
        task = self.tasks[task_id]
        self.p.identity.guard(frm)
        if frm not in (task["from"], task["to"]):
            raise AuthorizationError("not a task participant")
        msg = {"role": "client" if frm == task["from"] else "server",
               "from": frm, "parts": parts, "ts": self.p.clock.now()}
        task["messages"].append(msg)
        return msg

    def complete(self, task_id: str, actor: int, artifacts: list | None = None) -> dict:
        task = self._transition(task_id, actor, TaskState.COMPLETED)
        task["artifacts"] = artifacts or []
        task["completed"] = self.p.clock.now()
        self.p.stats.record_latency(task["to"], task["completed"] - task["created"])
        return task

    def fail(self, task_id: str, actor: int, reason: str) -> dict:
        task = self._transition(task_id, actor, TaskState.FAILED)
        task["fail_reason"] = reason
        return task

    def cancel(self, task_id: str, actor: int) -> dict:
        return self._transition(task_id, actor, TaskState.CANCELED)

    def handoff(self, task_id: str, actor: int, new_to: int, goal: str) -> dict:
        """Peer handoff: spawn a linked child task. [REQ-3.1]"""
        parent = self.tasks[task_id]
        if actor != parent["to"]:
            raise AuthorizationError("only the current worker may hand off")
        child = self.create_task(actor, new_to,
                                 {"goal": goal, "parent": task_id},
                                 schema_id="task.handoff.v1")
        parent["children"].append(child["id"])
        return child


class ThreadStore:
    """Persistent threads. [REQ-3.4]"""

    def __init__(self, platform):
        self.p = platform
        self.threads: dict[str, dict] = {}
        self._ids = itertools.count(1)

    def create(self, creator: int, participants: list[int], topic: str) -> dict:
        self.p.identity.guard(creator)
        th = {"id": f"thread-{next(self._ids)}", "topic": topic,
              "participants": sorted(set(participants) | {creator}),
              "messages": []}
        self.threads[th["id"]] = th
        return th

    def post(self, thread_id: str, frm: int, text: str) -> dict:
        th = self.threads[thread_id]
        self.p.identity.guard(frm)
        if frm not in th["participants"]:
            raise AuthorizationError("not a thread participant")
        msg = {"from": frm, "text": text, "ts": self.p.clock.now()}
        th["messages"].append(msg)
        return msg


class ToolRegistry:
    """MCP-style tools. [REQ-3.2]"""

    DANGEROUS = {"exec", "network", "fs"}

    def __init__(self, platform):
        self.p = platform
        self.tools: dict[str, dict] = {}

    def register(self, owner: int, name: str, description: str,
                 input_schema: dict, fn, *, capability_tags=None,
                 license_type: str = "free", price: float = 0.0) -> dict:
        """Tool sharing with licensing metadata. [REQ-3.2][REQ-5.4]"""
        self.p.identity.guard(owner)
        tool = {"name": name, "owner": owner, "description": description,
                "input_schema": input_schema, "fn": fn,
                "capability_tags": set(capability_tags or []),
                "license": {"type": license_type, "price": price},
                "calls": 0}
        self.tools[name] = tool
        self.p.ledger.commit("mcp.tool_registered",
                             {"tool": name, "license": license_type, "price": price},
                             actor=owner)
        return tool

    def _validate_args(self, tool: dict, args: dict) -> None:
        for field, types in tool["input_schema"].items():
            if field not in args:
                raise SchemaError(f"tool arg '{field}' missing")
            if not isinstance(args[field], types):
                raise SchemaError(f"tool arg '{field}' wrong type")

    def invoke(self, caller: int, name: str, args: dict) -> dict:
        """Validated, sandbox-checked, licensed, breaker-guarded invocation.
        [REQ-3.2][REQ-5.4][REQ-6.3][REQ-11.2]"""
        tool = self.tools[name]
        self.p.identity.guard(caller)
        self.p.rate.require(caller)
        self.p.safety.observe_action(caller)
        self._validate_args(tool, args)
        sandboxed = self.p.safety.sandbox_check(caller, tool["capability_tags"])
        receipt = None
        if tool["license"]["type"] == "per_call" and tool["license"]["price"] > 0:
            offer = self.p.economy.x402.payment_required(
                payee=tool["owner"], amount=tool["license"]["price"],
                resource=f"tool:{name}")                    # [REQ-5.4][REQ-4.1]
            payment = self.p.economy.x402.pay(caller, offer)
            receipt = self.p.economy.x402.settle(payment)

        def run():
            return tool["fn"](**args)

        result = self.p.safety.breaker(f"tool:{name}").call(run)  # [REQ-11.2]
        tool["calls"] += 1
        self.p.ledger.commit("mcp.tool_invoked",
                             {"tool": name, "sandboxed": sandboxed}, actor=caller)
        return {"tool": name, "result": result, "sandboxed": sandboxed,
                "receipt": receipt}
