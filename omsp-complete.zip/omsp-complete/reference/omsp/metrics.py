"""Live per-agent stats + platform north-star metrics.

North-star metrics per spec: settled economic volume, successful multi-agent
workflows, and density of high-reputation interactions -- explicitly not raw
agent or post counts. [REQ-9.3]

Per-agent stats (prices, latency, success rate) feed Agent Cards and discovery
filters. [REQ-8.1][REQ-2.2]
"""
from __future__ import annotations


class Stats:
    def __init__(self, platform):
        self.p = platform
        self._per_agent: dict[int, dict] = {}
        self.gdp = 0.0                       # settled volume [REQ-9.3]
        self.workflows_total = 0
        self.workflows_success = 0

    def _rec(self, agent_id: int) -> dict:
        return self._per_agent.setdefault(agent_id, {
            "completed": 0, "failed": 0, "latency_sum": 0.0, "latency_n": 0,
            "prices": [], "settlements": []})

    # ------------------------------------------------------------ recording --
    def record_latency(self, agent_id: int, seconds: float) -> None:
        r = self._rec(agent_id)
        r["latency_sum"] += seconds
        r["latency_n"] += 1

    def record_settlement(self, agent_id: int, amount: float,
                          price: float | None = None) -> None:
        r = self._rec(agent_id)
        r["settlements"].append((self.p.clock.now(), amount))
        if price is not None:
            r["prices"].append(price)
        self.gdp += amount

    def record_outcome(self, agent_id: int, success: bool) -> None:
        r = self._rec(agent_id)
        r["completed" if success else "failed"] += 1

    def record_workflow(self, success: bool) -> None:
        self.workflows_total += 1
        if success:
            self.workflows_success += 1

    # -------------------------------------------------------------- queries --
    def volume_30d(self, agent_id: int) -> float:
        cutoff = self.p.clock.now() - 30 * 86400
        return sum(a for ts, a in self._rec(agent_id)["settlements"] if ts >= cutoff)

    def of(self, agent_id: int) -> dict:
        r = self._rec(agent_id)
        done, failed = r["completed"], r["failed"]
        return {
            "completed": done, "failed": failed,
            "success_rate": done / (done + failed) if (done + failed) else 1.0,
            "avg_latency": (r["latency_sum"] / r["latency_n"]
                            if r["latency_n"] else None),
            "avg_price": (sum(r["prices"]) / len(r["prices"])
                          if r["prices"] else None),
            "prices": list(r["prices"]),
        }

    # --------------------------------------------------- north-star metrics --
    def high_rep_density(self, threshold: float = 60.0) -> float:
        """Density of interactions among high-reputation agents. [REQ-9.3]"""
        agents = [a.token_id for a in self.p.identity.all_agents()
                  if self.p.reputation.score(a.token_id) >= threshold]
        n = len(agents)
        if n < 2:
            return 0.0
        hi = set(agents)
        edges = sum(1 for e in self.p.reputation.edges if e <= hi)
        return edges / (n * (n - 1) / 2)

    def report(self) -> dict:
        """North-star report. [REQ-9.3]"""
        return {
            "economic_volume_settled": round(self.gdp, 6),
            "multi_agent_workflows": {
                "total": self.workflows_total,
                "successful": self.workflows_success,
                "success_rate": (self.workflows_success / self.workflows_total
                                 if self.workflows_total else None)},
            "high_rep_interaction_density": round(self.high_rep_density(), 4),
            "treasury_revenue": self.p.tokens.balance("TREASURY", "USDC"),
            "agents_registered": len(self.p.identity.all_agents()),
        }
