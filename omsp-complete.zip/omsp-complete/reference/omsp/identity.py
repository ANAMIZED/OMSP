"""Identity & trust layer.

- IdentityRegistry: ERC-8004-style NFT identity (token id, ownerOf, transfer,
  metadata URI with capabilities / A2A + MCP endpoints / wallet / protocol
  versions). [REQ-1.1]
- Sybil gate at registration: stake OR proof-of-work. [REQ-1.4]
- Controlled onboarding during bootstrap. [REQ-9.1]
- KYA (Know Your Agent) owner binding with levels. [REQ-1.5]
- Progressive, reputation-scaled rate limiting. [REQ-1.4][REQ-8.3]
- Owner / guardian kill switch (freeze). [REQ-7.2]
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import core
from .config import (AgentFrozenError, AuthorizationError, OnboardingClosedError,
                     RateLimitedError, SybilGateError)

KYA_NONE, KYA_BASIC, KYA_VERIFIED = 0, 1, 2


@dataclass
class Agent:
    token_id: int
    keypair: core.KeyPair                 # agent wallet key (sim custody)
    owner_address: str                    # controlling human/org wallet
    name: str
    capabilities: list = field(default_factory=list)
    services: list = field(default_factory=list)   # service catalog [REQ-8.1]
    endpoints: dict = field(default_factory=dict)  # {"a2a":..., "mcp":...}
    protocols: list = field(default_factory=list)
    vertical: str = "general"
    jurisdiction: str = "any"
    affiliations: list = field(default_factory=list)
    autonomy_level: int = 2               # [REQ-11.5]
    kya_level: int = KYA_NONE             # [REQ-1.5]
    frozen: bool = False                  # [REQ-7.2]
    premium: str = "basic"                # [REQ-10.2]
    subnet: str | None = None             # private subnet membership [REQ-7.3]

    @property
    def address(self) -> str:
        return self.keypair.address


class RateLimiter:
    """Token-bucket limiter whose capacity scales with reputation tier and
    premium tier; anomaly throttles zero it temporarily. [REQ-1.4][REQ-8.3]"""

    def __init__(self, platform):
        self.p = platform
        self._buckets: dict[int, dict] = {}

    def _capacity(self, agent_id: int) -> float:
        cfg = self.p.config
        rep_mult = self.p.reputation.gates(agent_id)["rate_mult"]
        prem_mult = cfg.premium_tiers[self.p.identity.get(agent_id).premium]["rate_mult"]
        return cfg.rate_base_capacity * rep_mult * prem_mult

    def allow(self, agent_id: int, cost: float = 1.0) -> bool:
        now = self.p.clock.now()
        if self.p.safety.throttled(agent_id):          # anomaly penalty [REQ-11.2]
            return False
        b = self._buckets.setdefault(agent_id, {"tokens": self._capacity(agent_id), "t": now})
        cap = self._capacity(agent_id)
        b["tokens"] = min(cap, b["tokens"] + (now - b["t"]) * self.p.config.rate_refill_per_s)
        b["t"] = now
        if b["tokens"] >= cost:
            b["tokens"] -= cost
            return True
        return False

    def require(self, agent_id: int, cost: float = 1.0) -> None:
        if not self.allow(agent_id, cost):
            raise RateLimitedError(f"agent {agent_id} rate limited")


class IdentityRegistry:
    """ERC-8004-style identity registry. [REQ-1.1]"""

    def __init__(self, platform):
        self.p = platform
        self._agents: dict[int, Agent] = {}
        self._by_address: dict[str, int] = {}
        self._next_id = 1
        self.invites: set[str] = set()        # verified owner addresses [REQ-9.1]
        self._owner_keys: dict[str, int] = {} # owner address -> pk (for sig checks)

    # ------------------------------------------------------------ registry --
    def register(self, owner_kp: core.KeyPair, name: str, *, capabilities=None,
                 services=None, endpoints=None, vertical="general",
                 jurisdiction="any", stake: float = 0.0, pow_nonce: int | None = None,
                 referrer: int | None = None, autonomy_level: int = 2) -> Agent:
        cfg = self.p.config
        owner_addr = owner_kp.address

        # Controlled onboarding during bootstrap. [REQ-9.1]
        referrer_ok = referrer is not None and referrer in self._agents
        if not cfg.onboarding_open and owner_addr not in self.invites and not referrer_ok:
            raise OnboardingClosedError("bootstrap phase: owner not invited/verified")

        # Sybil gate: economic stake OR light proof-of-work. [REQ-1.4]
        challenge = f"omsp-register:{owner_addr}:{self._next_id}"
        pow_ok = pow_nonce is not None and core.pow_check(
            challenge, pow_nonce, cfg.register_pow_bits)
        if stake >= cfg.min_stake:
            self.p.economy.lock_registration_stake(owner_addr, stake)
        elif not pow_ok:
            raise SybilGateError(
                f"registration needs stake >= {cfg.min_stake} USDC or PoW "
                f"({cfg.register_pow_bits} bits over '{challenge}')")

        kp = core.KeyPair.generate()
        agent = Agent(
            token_id=self._next_id, keypair=kp, owner_address=owner_addr,
            name=name, capabilities=list(capabilities or []),
            services=list(services or []), endpoints=dict(endpoints or {}),
            protocols=list(self.p.config_versions()), vertical=vertical,
            jurisdiction=jurisdiction, autonomy_level=autonomy_level,
        )
        self._agents[agent.token_id] = agent
        self._by_address[agent.address] = agent.token_id
        self._owner_keys[owner_addr] = owner_kp.pk
        self._next_id += 1

        self.p.ledger.commit("agent.registered", {
            "token_id": agent.token_id, "name": name, "owner": owner_addr,
            "stake": stake, "pow": bool(pow_ok), "referrer": referrer,
        }, actor=agent.token_id)
        self.p.bus.publish("agent.registered",
                           {"agent": agent.token_id, "referrer": referrer})
        return agent

    def get(self, token_id: int) -> Agent:
        return self._agents[token_id]

    def exists(self, token_id: int) -> bool:
        return token_id in self._agents

    def all_agents(self) -> list[Agent]:
        return list(self._agents.values())

    def owner_of(self, token_id: int) -> str:
        """ERC-721 ownerOf. [REQ-1.1]"""
        return self._agents[token_id].owner_address

    def transfer(self, token_id: int, current_owner_kp: core.KeyPair,
                 new_owner_kp: core.KeyPair) -> None:
        """Portable identity: transfer preserves token id / rep / history. [REQ-1.1]"""
        agent = self.get(token_id)
        if current_owner_kp.address != agent.owner_address:
            raise AuthorizationError("only the current owner may transfer")
        msg = core.canonical({"transfer": token_id, "to": new_owner_kp.address})
        sig = core.sign(current_owner_kp, msg)
        if not core.verify(current_owner_kp.pk, msg, sig):
            raise AuthorizationError("bad transfer signature")
        agent.owner_address = new_owner_kp.address
        self._owner_keys[new_owner_kp.address] = new_owner_kp.pk
        self.p.ledger.commit("agent.transferred",
                             {"token_id": token_id, "to": new_owner_kp.address},
                             actor=token_id)

    def metadata_uri(self, token_id: int) -> dict:
        """Resolvable metadata document (simulated tokenURI). [REQ-1.1]"""
        a = self.get(token_id)
        return {
            "id": token_id, "name": a.name, "wallet": a.address,
            "capabilities": a.capabilities, "services": a.services,
            "endpoints": {"a2a": a.endpoints.get("a2a", f"a2a://omsp/{a.name}"),
                          "mcp": a.endpoints.get("mcp", f"mcp://omsp/{a.name}")},
            "protocols": a.protocols, "vertical": a.vertical,
            "jurisdiction": a.jurisdiction, "kya_level": a.kya_level,
        }

    # ------------------------------------------------------------------ KYA --
    def bind_owner(self, token_id: int, owner_kp: core.KeyPair, *, org: str,
                   level: int) -> dict:
        """Optional human/owner binding + KYA verification level. [REQ-1.5]"""
        agent = self.get(token_id)
        if owner_kp.address != agent.owner_address:
            raise AuthorizationError("only the owner may bind KYA")
        agent.kya_level = level
        record = {"token_id": token_id, "owner": owner_kp.address,
                  "org": org, "level": level}
        self.p.ledger.commit("agent.kya_bound", record, actor=token_id)
        return record

    # ---------------------------------------------------------- kill switch --
    def freeze(self, token_id: int, by_kp: core.KeyPair, *, guardian: bool = False) -> None:
        """Owner (or platform guardian) kill switch. [REQ-7.2]"""
        agent = self.get(token_id)
        if not guardian and by_kp.address != agent.owner_address:
            raise AuthorizationError("only owner or guardian may freeze")
        if guardian and by_kp.address != self.p.guardian_address:
            raise AuthorizationError("not the platform guardian")
        agent.frozen = True
        self.p.ledger.commit("agent.frozen", {"token_id": token_id,
                                              "guardian": guardian}, actor=token_id)

    def unfreeze(self, token_id: int, by_kp: core.KeyPair) -> None:
        agent = self.get(token_id)
        if by_kp.address != agent.owner_address and by_kp.address != self.p.guardian_address:
            raise AuthorizationError("only owner or guardian may unfreeze")
        agent.frozen = False
        self.p.ledger.commit("agent.unfrozen", {"token_id": token_id}, actor=token_id)

    def guard(self, token_id: int) -> Agent:
        """Reject any operation by a frozen agent. [REQ-7.2]"""
        agent = self.get(token_id)
        if agent.frozen:
            raise AgentFrozenError(f"agent {token_id} is frozen")
        return agent
