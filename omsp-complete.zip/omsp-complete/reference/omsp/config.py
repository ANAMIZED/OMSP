"""OMSP protocol configuration, parameter bounds, and error types.

Governance may retune parameters, but only inside PARAM_BOUNDS -- the spec's
hard limits (e.g. take-rate clamped to [0.1%, 2%]). [REQ-10.1][REQ-10.3]
"""
from __future__ import annotations

from dataclasses import dataclass, field

PROTOCOL_VERSIONS = ["0.1", "0.2"]  # [REQ-11.4]

DAY = 86_400.0


# ------------------------------------------------------------------ errors ---

class OMSPError(Exception):
    """Base class for protocol errors."""


class AgentFrozenError(OMSPError):
    """Agent is frozen by owner/guardian kill switch. [REQ-7.2]"""


class RateLimitedError(OMSPError):
    """Progressive rate limit or anomaly throttle hit. [REQ-1.4][REQ-11.2]"""


class SybilGateError(OMSPError):
    """Registration lacked stake and valid proof-of-work. [REQ-1.4]"""


class OnboardingClosedError(OMSPError):
    """Bootstrap phase: owner not on the verified invite list. [REQ-9.1]"""


class SchemaError(OMSPError):
    """Structured payload failed schema validation. [REQ-3.3]"""


class SpamGateError(OMSPError):
    """Low-rep post lacked proof-of-work / anti-spam fee. [REQ-11.1]"""


class ReplayError(OMSPError):
    """x402 payment nonce reuse. [REQ-4.1]"""


class PaymentError(OMSPError):
    """Bad signature / insufficient funds in settlement."""


class EscrowStateError(OMSPError):
    """Illegal escrow state transition. [REQ-4.2]"""


class AuthorizationError(OMSPError):
    """Caller lacks rights for this action."""


class SandboxViolation(OMSPError):
    """Untrusted agent attempted a dangerous capability. [REQ-6.3]"""


class ComplianceError(OMSPError):
    """Regulated-vertical requirements not met. [REQ-11.6]"""


class ApprovalRequired(OMSPError):
    """Action exceeds autonomy-level cap; human approval recorded. [REQ-11.5]"""

    def __init__(self, request):
        super().__init__(f"human approval required: {request['id']}")
        self.request = request


class CircuitOpenError(OMSPError):
    """Circuit breaker is open for this target. [REQ-11.2]"""


class SwarmDissolvedError(OMSPError):
    """Swarm context was destroyed at dissolution. [REQ-5.3]"""


class VersionError(OMSPError):
    """No mutually supported protocol version. [REQ-11.4]"""


class NotSupportedError(OMSPError):
    """Deliberately unsupported (e.g. paid feed placement). [REQ-10.4]"""


class ProposalRejectedError(OMSPError):
    """Governance proposal outside hard parameter bounds. [REQ-10.3]"""


class GateError(OMSPError):
    """Reputation-capital gate: job value above tier maximum. [REQ-8.3]"""


# ------------------------------------------------------------------ config ---

@dataclass
class Config:
    # registration / sybil [REQ-1.4][REQ-9.1]
    onboarding_open: bool = False
    min_stake: float = 10.0          # USDC stake alternative to PoW
    register_pow_bits: int = 12

    # rate limiting (token bucket) [REQ-1.4]
    rate_base_capacity: float = 5.0
    rate_refill_per_s: float = 0.05

    # anti-spam posting [REQ-11.1]
    spam_free_rep: float = 25.0      # below this, PoW or fee required to post
    post_fee: float = 0.05
    post_pow_bits: int = 10

    # reputation [REQ-1.2][REQ-8.3]
    rep_base: float = 10.0
    rep_half_life: float = 30 * DAY

    # fees [REQ-10.1]
    fee_base_rate: float = 0.015
    fee_floor: float = 0.001
    fee_cap: float = 0.02

    # feed [REQ-5.2]
    feed_half_life: float = 6 * 3600.0

    # referrals [REQ-9.2]
    referral_reward_om: float = 5.0
    referral_boost: float = 1.2
    referral_boost_half_life: float = 7 * DAY

    # premium [REQ-10.2]  tier -> (monthly price USDC, rate mult, discovery boost)
    premium_tiers: dict = field(default_factory=lambda: {
        "basic": {"price": 0.0, "rate_mult": 1.0, "boost": 1.0,
                  "analytics": False, "private_subnets": False},
        "pro": {"price": 50.0, "rate_mult": 2.0, "boost": 1.1,
                "analytics": True, "private_subnets": False},
        "enterprise": {"price": 500.0, "rate_mult": 4.0, "boost": 1.2,
                       "analytics": True, "private_subnets": True},
    })
    discovery_boost_cap: float = 1.25  # bounded paid influence in discovery only

    # autonomy spend caps per level [REQ-11.5]
    autonomy_caps: dict = field(default_factory=lambda: {0: 0.0, 1: 10.0, 2: 100.0, 3: 1000.0})

    # anomaly detection [REQ-11.2]
    anomaly_window: float = 60.0
    anomaly_max_actions: int = 30
    anomaly_cooldown: float = 300.0

    # circuit breaker [REQ-11.2]
    breaker_threshold: int = 3
    breaker_cooldown: float = 120.0

    # governance [REQ-10.3]
    governance_quorum_om: float = 20.0


# Hard bounds governance can never exceed. [REQ-10.1][REQ-10.3]
PARAM_BOUNDS = {
    "fee_base_rate": (0.001, 0.02),
    "fee_floor": (0.001, 0.02),
    "fee_cap": (0.001, 0.02),
    "min_stake": (1.0, 1000.0),
    "post_fee": (0.0, 1.0),
    "rate_base_capacity": (1.0, 100.0),
}

# Regulated verticals -> requirements. [REQ-11.6]
VERTICAL_RULES = {
    "finance": {"min_kya": 2, "require_owner": True},
    "healthcare": {"min_kya": 2, "require_owner": True},
    "legal": {"min_kya": 1, "require_owner": True},
}
