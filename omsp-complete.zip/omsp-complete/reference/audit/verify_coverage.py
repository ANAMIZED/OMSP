"""No-omissions audit gate.

Parses every [REQ-x.y] declared in SPEC.md, scans omsp/ (+ demo.py) for
implementation tags and tests/ for verification tags, writes TRACEABILITY.md,
and exits non-zero if ANY requirement lacks either an implementation or a
test -- the machine-checked "no omissions" guarantee.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TAG = re.compile(r"\[REQ-(\d+\.\d+)\]")


def spec_requirements() -> dict[str, str]:
    reqs: dict[str, str] = {}
    for line in (ROOT / "SPEC.md").read_text().splitlines():
        m = re.match(r"- \*\*\[REQ-(\d+\.\d+)\]\*\*\s*(.+)", line)
        if m:
            desc = m.group(2).strip()
            reqs[m.group(1)] = (desc[:88] + "…") if len(desc) > 90 else desc
    return reqs


def scan(paths: list[Path]) -> dict[str, set[str]]:
    hits: dict[str, set[str]] = {}
    for path in paths:
        rel = str(path.relative_to(ROOT))
        for req in TAG.findall(path.read_text()):
            hits.setdefault(req, set()).add(rel)
    return hits


def main() -> int:
    reqs = spec_requirements()
    impl = scan(sorted((ROOT / "omsp").glob("*.py")) + [ROOT / "demo.py"])
    tests = scan(sorted((ROOT / "tests").glob("test_*.py")))

    rows, missing = [], []
    for rid in sorted(reqs, key=lambda r: tuple(map(int, r.split(".")))):
        i = sorted(impl.get(rid, []))
        t = sorted(tests.get(rid, []))
        status = "✅ verified" if i and t else "❌ MISSING"
        if not (i and t):
            missing.append((rid, bool(i), bool(t)))
        rows.append(f"| REQ-{rid} | {reqs[rid]} | {', '.join(i) or '—'} "
                    f"| {', '.join(t) or '—'} | {status} |")

    orphan_impl = sorted(set(impl) - set(reqs))
    orphan_test = sorted(set(tests) - set(reqs))

    table = "\n".join([
        "# OMSP Requirements Traceability Matrix",
        "",
        f"Spec requirements: **{len(reqs)}** · implemented+tested: "
        f"**{len(reqs) - len(missing)}** · missing: **{len(missing)}**",
        "",
        "| Requirement | Summary | Implementation | Tests | Status |",
        "|---|---|---|---|---|",
        *rows,
        "",
        f"Orphan tags (in code/tests but not in SPEC): "
        f"{orphan_impl + orphan_test or 'none'}",
    ])
    (ROOT / "TRACEABILITY.md").write_text(table + "\n")

    print(f"requirements in SPEC.md ........ {len(reqs)}")
    print(f"with implementation tags ....... {len([r for r in reqs if r in impl])}")
    print(f"with test tags ................. {len([r for r in reqs if r in tests])}")
    if missing:
        for rid, has_i, has_t in missing:
            print(f"  MISSING REQ-{rid}: impl={has_i} test={has_t}")
        print("AUDIT: FAIL — omissions detected")
        return 1
    if orphan_impl or orphan_test:
        print(f"note: orphan tags {orphan_impl + orphan_test}")
    print("AUDIT: PASS — every requirement is implemented and tested")
    return 0


if __name__ == "__main__":
    sys.exit(main())
