"""OMSP core primitives.

Simulation-grade building blocks shared by every subsystem:
- SimClock: deterministic time source (seconds).
- canonical()/sha256_hex(): canonical JSON hashing.
- KeyPair/sign/verify: Schnorr-style signatures over the RFC 3526 group-14 prime
  (squared generator -> prime-order subgroup; `s` kept unreduced so verification
  is unconditional). NOT production crypto -- a stand-in for wallet keys.
- EventBus: in-process pub/sub -- the off-chain event-driven runtime. [REQ-6.1]
- Ledger: append-only hash-chained block log simulating on-chain commitments;
  tamper-evident and queryable -> full audit trail. [REQ-6.1][REQ-6.4]
- pow_check/pow_solve: light proof-of-work puzzles. [REQ-1.4][REQ-11.1]
"""
from __future__ import annotations

import hashlib
import json
import secrets
from dataclasses import dataclass


# ---------------------------------------------------------------- hashing ----

def canonical(obj) -> bytes:
    """Canonical JSON bytes (sorted keys, no whitespace)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str).encode()


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ------------------------------------------------------------------ clock ----

class SimClock:
    """Deterministic simulated clock (seconds since epoch 0)."""

    def __init__(self, start: float = 0.0):
        self.t = float(start)

    def now(self) -> float:
        return self.t

    def advance(self, dt: float) -> float:
        self.t += float(dt)
        return self.t


# ------------------------------------------------------------- signatures ----

# RFC 3526 MODP group 14 prime (2048-bit).
_P_HEX = (
    "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74"
    "020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437"
    "4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
    "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05"
    "98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB"
    "9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
    "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718"
    "3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF"
)
P = int(_P_HEX, 16)
G = pow(2, 2, P)  # squared generator -> lives in the prime-order subgroup


@dataclass(frozen=True)
class KeyPair:
    sk: int
    pk: int

    @staticmethod
    def generate() -> "KeyPair":
        sk = secrets.randbits(256) | 1
        return KeyPair(sk=sk, pk=pow(G, sk, P))

    @property
    def address(self) -> str:
        pk_bytes = self.pk.to_bytes(256, "big")
        return "0x" + sha256_hex(pk_bytes)[:40]


def _challenge(r: int, msg: bytes) -> int:
    return int.from_bytes(hashlib.sha256(r.to_bytes(256, "big") + msg).digest(), "big")


def sign(kp: KeyPair, msg: bytes) -> dict:
    k = secrets.randbits(256) | 1
    r = pow(G, k, P)
    e = _challenge(r, msg)
    s = k + e * kp.sk  # unreduced on purpose: identity g^s == r*pk^e always holds
    return {"r": r, "s": s}


def verify(pk: int, msg: bytes, sig: dict) -> bool:
    try:
        r, s = int(sig["r"]), int(sig["s"])
    except (KeyError, TypeError, ValueError):
        return False
    e = _challenge(r, msg)
    return pow(G, s, P) == (r * pow(pk, e, P)) % P


def address_of(pk: int) -> str:
    return "0x" + sha256_hex(pk.to_bytes(256, "big"))[:40]


# -------------------------------------------------------------- event bus ----

class EventBus:
    """Synchronous in-process pub/sub. The off-chain messaging spine. [REQ-6.1]"""

    def __init__(self):
        self._subs: dict[str, list] = {}

    def subscribe(self, etype: str, fn) -> None:
        self._subs.setdefault(etype, []).append(fn)

    def publish(self, etype: str, data: dict) -> None:
        for fn in list(self._subs.get(etype, [])):
            fn(data)
        for fn in list(self._subs.get("*", [])):
            fn({"type": etype, **data})


# ----------------------------------------------------------------- ledger ----

class Ledger:
    """Append-only, hash-chained event log.

    Simulates on-chain commitments: every consequential platform event is
    committed as a block whose hash covers its content and the previous block's
    hash, so any retroactive edit is detectable. [REQ-6.1][REQ-6.4]
    """

    def __init__(self, clock: SimClock):
        self.clock = clock
        self.blocks: list[dict] = []
        self._append([{"type": "genesis", "data": {}, "actor": None, "ts": clock.now()}])

    @staticmethod
    def _block_hash(block: dict) -> str:
        body = {k: block[k] for k in ("index", "ts", "events", "prev")}
        return sha256_hex(canonical(body))

    def _append(self, events: list[dict]) -> dict:
        prev_hash = self.blocks[-1]["hash"] if self.blocks else "0" * 64
        block = {
            "index": len(self.blocks),
            "ts": self.clock.now(),
            "events": events,
            "prev": prev_hash,
        }
        block["hash"] = self._block_hash(block)
        self.blocks.append(block)
        return block

    def commit(self, etype: str, data: dict, actor=None) -> dict:
        ev = {"type": etype, "data": data, "actor": actor, "ts": self.clock.now()}
        return self._append([ev])

    def verify_chain(self) -> tuple[bool, int | None]:
        """Return (ok, first_bad_index). Detects any tampering. [REQ-6.4]"""
        for i, block in enumerate(self.blocks):
            if self._block_hash(block) != block["hash"]:
                return False, i
            if i > 0 and block["prev"] != self.blocks[i - 1]["hash"]:
                return False, i
        return True, None

    def query(self, etype: str | None = None, actor=None) -> list[dict]:
        """Queryable audit trail. [REQ-6.4]"""
        out = []
        for block in self.blocks:
            for ev in block["events"]:
                if etype is not None and ev.get("type") != etype:
                    continue
                if actor is not None and ev.get("actor") != actor:
                    continue
                out.append(ev)
        return out


# ---------------------------------------------------------- proof-of-work ----

def pow_check(challenge: str, nonce: int, bits: int) -> bool:
    """True iff sha256(challenge:nonce) has `bits` leading zero bits."""
    digest = hashlib.sha256(f"{challenge}:{nonce}".encode()).digest()
    return int.from_bytes(digest, "big") >> (256 - bits) == 0


def pow_solve(challenge: str, bits: int, limit: int = 5_000_000) -> int:
    nonce = 0
    while nonce < limit:
        if pow_check(challenge, nonce, bits):
            return nonce
        nonce += 1
    raise RuntimeError("proof-of-work search limit exceeded")
