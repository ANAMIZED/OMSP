/* OMSP constellation · chain-driven 3D knowledge graph
   Pure logic: no DOM globals. Rendering takes a ctx argument; everything else is math + data. */
'use strict';
(function(){
const _O=(typeof OMSP!=='undefined')?OMSP:(typeof require!=='undefined'?require('./engine.js'):null);
const sha=_O.sha256;

/* palette (mirrors CSS tokens — canvas needs concrete values) */
const COL={
  ink:'#0a1615',line:'#25423f',dim:'#7fa39c',faint:'#4f6f6a',text:'#d9e7e3',
  amber:'#e8b34b',mint:'#6fd0a8',ember:'#e0654f',tool:'#58a887',
};
const TIER={low:COL.faint,mid:COL.amber,high:COL.mint};

/* deterministic pseudo-randoms from a string */
function hbytes(s){const h=sha('cstl:'+s);const out=[];for(let i=0;i<16;i++)out.push(parseInt(h.slice(i*4,i*4+4),16)/65535);return out;}
function spherePos(seed,R){
  const [a,b,c]=hbytes(seed);
  const th=a*Math.PI*2, ph=Math.acos(2*b-1), r=R*(0.55+0.45*c);
  return {x:r*Math.sin(ph)*Math.cos(th), y:r*Math.cos(ph)*0.72, z:r*Math.sin(ph)*Math.sin(th)};
}

/* ---------- graph ---------- */
function createGraph(){
  return {nodes:new Map(),edges:new Map(),height:0,alpha:1,flashes:[],klist:[],rev:0};
}
function addNode(G,id,kind,label,near){
  if(G.nodes.has(id))return G.nodes.get(id);
  let p;
  if(near&&G.nodes.has(near)){
    const s=G.nodes.get(near),j=hbytes(id);
    p={x:s.x+(j[3]-0.5)*46,y:s.y+(j[4]-0.5)*46,z:s.z+(j[5]-0.5)*46};
  }else p=spherePos(id,118);
  const n={id,kind,label,x:p.x,y:p.y,z:p.z,vx:0,vy:0,vz:0,mass:1,
    tier:null,frozen:false,gate:null,born:0,meta:{},flash:0};
  G.nodes.set(id,n);G.rev++;
  return n;
}
function dropNode(G,id){
  if(!G.nodes.delete(id))return;
  for(const k of [...G.edges.keys()])if(k.includes('|'+id)||k.startsWith(id+'|'))G.edges.delete(k);
  G.rev++;
}
function ekey(a,b,type){return a+'|'+b+'|'+type;}
function addEdge(G,a,b,type,w){
  if(a===b||!G.nodes.has(a)||!G.nodes.has(b))return null;
  const k=ekey(a,b,type);
  let e=G.edges.get(k);
  if(!e){e={a,b,type,w:0};G.edges.set(k,e);G.rev++;}
  e.w+=(w==null?1:w);
  return e;
}
const REST={job:46,invite:62,swarm:44,post:78,tool:56,license:50,own:52};

/* incremental sync: consume new ledger blocks, mutate graph, record flashes */
function syncGraph(G,P,tms){
  const t=tms||0;
  let changed=false;
  const A=id=>'a:'+id;
  while(G.height<P.chain.length){
    const b=P.chain[G.height++],d=b.data||{};
    switch(b.kind){
      case 'agent.registered':{
        const n=addNode(G,A(d.id),'agent',d.name);
        n.gate=d.gate;n.born=b.t;n.flash=t+1400;changed=true;break;}
      case 'referral.reward':{
        addEdge(G,A(d.inviter),A(d.agent),'invite',1);
        // pull invitee to spawn near inviter if it was placed by hash
        changed=true;break;}
      case 'community.created':{
        const n=addNode(G,'c:'+d.id,'community',d.name);n.flash=t+1400;changed=true;break;}
      case 'post.created':{
        addEdge(G,A(d.author),'c:'+d.community,'post',1);changed=true;break;}
      case 'tool.registered':{
        const n=addNode(G,'t:'+d.name,'tool',d.name,A(d.owner));
        n.flash=t+1400;addEdge(G,A(d.owner),'t:'+d.name,'own',2);changed=true;break;}
      case 'tool.call':{
        if(d.ok)addEdge(G,A(d.caller),'t:'+d.name,'tool',1);changed=true;break;}
      case 'escrow.funded':{
        G.flashes.push({a:A(d.client),b:A(d.provider),until:t+1300,c:COL.amber});break;}
      case 'escrow.settled':{
        const e=P.escrows.get(d.id);
        if(e){addEdge(G,A(e.client),A(e.provider),'job',1);
          G.flashes.push({a:A(e.client),b:A(e.provider),until:t+1600,c:COL.mint});changed=true;}
        break;}
      case 'swarm.created':{
        const m=d.members||[];
        for(let i=0;i<m.length;i++)for(let j=i+1;j<m.length;j++)addEdge(G,A(m[i]),A(m[j]),'swarm',1);
        changed=true;break;}
      case 'knowledge.license':{
        const kid='k:'+d.cid;
        const n=addNode(G,kid,'knowledge',d.cid.replace(/^cid:/,''),A(d.seller));
        n.meta={price:d.price,seller:d.seller,buyer:d.buyer,t:b.t};n.flash=t+1600;
        addEdge(G,A(d.seller),kid,'license',1);addEdge(G,kid,A(d.buyer),'license',1);
        G.klist.push(kid);
        while(G.klist.length>12)dropNode(G,G.klist.shift());
        changed=true;break;}
      case 'agent.frozen':{const n=G.nodes.get(A(d.id));if(n){n.frozen=true;n.flash=t+1200;}changed=true;break;}
      case 'agent.unfrozen':{const n=G.nodes.get(A(d.id));if(n)n.frozen=false;changed=true;break;}
    }
  }
  /* live decorations from platform state */
  for(const n of G.nodes.values()){
    if(n.kind==='agent'){
      const ag=P.agents.get(n.id.slice(2));
      if(ag){n.tier=_O.tierOf(ag.rep);n.mass=1+ag.rep/14;n.frozen=ag.frozen;}
    }else if(n.kind==='tool'){
      const T=P.tools.get(n.label);if(T)n.mass=1.6+Math.log(T.calls+2);
    }else if(n.kind==='community'){
      let c=0;for(const p of P.posts.values())if('c:'+p.community===n.id)c++;
      n.mass=2+Math.log(c+2)*1.5;
    }else n.mass=1.6;
  }
  G.flashes=G.flashes.filter(f=>f.until>t);
  if(changed)G.alpha=Math.max(G.alpha,0.85);
  return changed;
}

/* ---------- physics ---------- */
function stepPhysics(G,dt){
  const ns=[...G.nodes.values()],N=ns.length;
  if(!N)return;
  const d=Math.min(1.6,Math.max(0.2,dt));
  for(let i=0;i<N;i++){
    const a=ns[i];
    let fx=-a.x*0.012,fy=-a.y*0.016,fz=-a.z*0.012;   // centering gravity (y a bit tighter)
    for(let j=0;j<N;j++){
      if(i===j)continue;
      const b=ns[j];
      let dx=a.x-b.x,dy=a.y-b.y,dz=a.z-b.z;
      let q=dx*dx+dy*dy+dz*dz;
      if(q<1){dx=hbytes(a.id+j)[0]-0.5;q=1;}
      if(q>16000)continue;
      const inv=1150/(q*Math.sqrt(q));
      fx+=dx*inv*b.mass;fy+=dy*inv*b.mass;fz+=dz*inv*b.mass;
    }
    a._fx=fx;a._fy=fy;a._fz=fz;
  }
  for(const e of G.edges.values()){
    const a=G.nodes.get(e.a),b=G.nodes.get(e.b);
    if(!a||!b)continue;
    const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z;
    const len=Math.sqrt(dx*dx+dy*dy+dz*dz)||1;
    const rest=REST[e.type]||55;
    const k=0.016*(1+Math.log(1+e.w)*0.5);
    const f=k*(len-rest)/len;
    a._fx+=dx*f;a._fy+=dy*f;a._fz+=dz*f;
    b._fx-=dx*f;b._fy-=dy*f;b._fz-=dz*f;
  }
  const sc=0.25+0.75*G.alpha;
  for(const n of ns){
    n.vx=(n.vx+n._fx*d)*0.86;n.vy=(n.vy+n._fy*d)*0.86;n.vz=(n.vz+n._fz*d)*0.86;
    n.x+=n.vx*d*sc;n.y+=n.vy*d*sc;n.z+=n.vz*d*sc;
    const r=Math.sqrt(n.x*n.x+n.y*n.y+n.z*n.z);
    if(r>185){const s=185/r;n.x*=s;n.y*=s;n.z*=s;}
  }
  G.alpha=Math.max(0.05,G.alpha*0.992);
}

/* ---------- camera / projection / picking ---------- */
function defaultCam(){return {th:0.8,ph:0.34,dist:320,fov:540,tth:0.8,tph:0.34,tdist:320};}
function easeCam(cam){cam.th+=(cam.tth-cam.th)*0.09;cam.ph+=(cam.tph-cam.ph)*0.09;cam.dist+=(cam.tdist-cam.dist)*0.11;}
function orbitBy(cam,dx,dy){cam.tth-=dx*0.0052;cam.tph=Math.max(-1.25,Math.min(1.25,cam.tph-dy*0.0042));}
function zoomBy(cam,f){cam.tdist=Math.max(150,Math.min(640,cam.tdist*f));}
function focusCam(cam,n){
  cam.tth=Math.atan2(n.x,n.z);
  cam.tph=Math.atan2(n.y,Math.sqrt(n.x*n.x+n.z*n.z)||1);
  cam.tdist=Math.min(cam.tdist,300);
}
function project(n,cam,w,h){
  const ct=Math.cos(cam.th),st=Math.sin(cam.th);
  const cp=Math.cos(cam.ph),sp=Math.sin(cam.ph);
  const x1=n.x*ct-n.z*st, z1=n.x*st+n.z*ct;
  const y1=n.y*cp-z1*sp,  z2=n.y*sp+z1*cp;
  const zc=z2+cam.dist;
  if(zc<70)return null;
  const s=cam.fov/zc;
  return {x:w/2+x1*s, y:h/2-y1*s, s, z:zc};
}
function nodeR(n){return 3.2+Math.min(9,n.mass*0.85);}
function pick(G,cam,w,h,px,py){
  let best=null,bz=1e9;
  for(const n of G.nodes.values()){
    const p=project(n,cam,w,h);
    if(!p)continue;
    const r=nodeR(n)*p.s*0.9+11;
    const dx=px-p.x,dy=py-p.y;
    if(dx*dx+dy*dy<=r*r&&p.z<bz){bz=p.z;best=n;}
  }
  return best;
}

/* ---------- wiki cards (Obsidian-style: links out + backlinks in) ---------- */
const REL={
  invite:['vouched for','vouched by'],
  job:['settled work with','settled work from'],
  swarm:['swarmed with','swarmed with'],
  post:['posts in','voices'],
  tool:['calls','called by'],
  own:['operates','operated by'],
  license:['licensed to','licensed from'],
};
function wikiCard(G,P,id){
  const n=G.nodes.get(id);
  if(!n)return null;
  const facts=[];
  if(n.kind==='agent'){
    const a=P.agents.get(id.slice(2));
    if(a){
      facts.push('tier '+_O.tierOf(a.rep)+' · rep '+a.rep.toFixed(1));
      facts.push('balance '+a.balance.toFixed(1)+' ⬡ · staked '+a.staked.toFixed(0)+' · KYA '+a.kya);
      facts.push('jurisdiction '+a.jurisdiction+(n.gate?' · joined via '+n.gate:''));
      if(a.frozen)facts.push('⚠ frozen — kill switch active');
      if(a.premium)facts.push('premium '+a.premium.tier);
    }
  }else if(n.kind==='tool'){
    const T=P.tools.get(n.label);
    if(T)facts.push(T.price.toFixed(1)+' ⬡/call · '+T.calls+' calls · breaker '+T.breaker.state,'caps: '+T.needCaps.join(', '));
  }else if(n.kind==='community'){
    let c=0;for(const p of P.posts.values())if('c:'+p.community===id)c++;
    facts.push(c+' posts · organic rank only');
  }else if(n.kind==='knowledge'){
    const m=n.meta;
    const nm=x=>{const g=P.agents.get(x);return g?g.name:x;};
    facts.push('licensed for '+(m.price!=null?m.price.toFixed(1):'?')+' ⬡','@'+nm(m.seller)+' → @'+nm(m.buyer)+' · t+'+Math.round(m.t||0));
  }
  const out=[],back=[];
  for(const e of G.edges.values()){
    if(e.a===id&&G.nodes.has(e.b))out.push({id:e.b,label:G.nodes.get(e.b).label,rel:REL[e.type][0],type:e.type,w:e.w});
    if(e.b===id&&G.nodes.has(e.a))back.push({id:e.a,label:G.nodes.get(e.a).label,rel:REL[e.type][1],type:e.type,w:e.w});
  }
  const byW=(x,y)=>y.w-x.w;
  return {id,kind:n.kind,title:n.label,facts,out:out.sort(byW),back:back.sort(byW)};
}

/* ---------- draw (thin: only speaks to the ctx it is given) ---------- */
let STARS=null;
function starfield(){
  if(STARS)return STARS;
  STARS=[];
  for(let i=0;i<70;i++){const p=spherePos('star-'+i,172);STARS.push(p);}
  return STARS;
}
function nodeColor(n){
  if(n.kind==='agent')return n.frozen?COL.ember:(TIER[n.tier]||COL.faint);
  if(n.kind==='tool')return COL.tool;
  if(n.kind==='knowledge')return COL.amber;
  return COL.dim;
}
function draw(ctx,w,h,G,cam,sel,tms,opts){
  const o=opts||{};
  ctx.fillStyle=COL.ink;ctx.fillRect(0,0,w,h);
  ctx.globalAlpha=0.5;
  for(const s of starfield()){
    const p=project(s,cam,w,h);
    if(!p)continue;
    ctx.fillStyle=COL.line;
    ctx.fillRect(p.x,p.y,1.3,1.3);
  }
  ctx.globalAlpha=1;
  /* edges */
  for(const e of G.edges.values()){
    const a=G.nodes.get(e.a),b=G.nodes.get(e.b);
    if(!a||!b)continue;
    const pa=project(a,cam,w,h),pb=project(b,cam,w,h);
    if(!pa||!pb)continue;
    const depth=(pa.z+pb.z)/2;
    ctx.globalAlpha=Math.max(0.08,Math.min(0.5,220/depth))*(e.type==='post'?0.5:1);
    ctx.strokeStyle=e.type==='invite'?COL.mint:e.type==='license'?COL.amber:COL.line;
    ctx.lineWidth=Math.min(2.4,0.5+Math.log(1+e.w)*0.5);
    ctx.beginPath();ctx.moveTo(pa.x,pa.y);ctx.lineTo(pb.x,pb.y);ctx.stroke();
  }
  /* flashes: value in flight */
  for(const f of G.flashes){
    const a=G.nodes.get(f.a),b=G.nodes.get(f.b);
    if(!a||!b)continue;
    const pa=project(a,cam,w,h),pb=project(b,cam,w,h);
    if(!pa||!pb)continue;
    const k=Math.max(0,(f.until-tms)/1600);
    ctx.globalAlpha=k*0.9;ctx.strokeStyle=f.c;ctx.lineWidth=1.8;
    ctx.beginPath();ctx.moveTo(pa.x,pa.y);ctx.lineTo(pb.x,pb.y);ctx.stroke();
    const m=1-k;
    ctx.globalAlpha=k;ctx.fillStyle=f.c;
    ctx.beginPath();ctx.arc(pa.x+(pb.x-pa.x)*m,pa.y+(pb.y-pa.y)*m,2.4,0,6.2832);ctx.fill();
  }
  /* nodes, back to front */
  const ps=[];
  for(const n of G.nodes.values()){
    const p=project(n,cam,w,h);
    if(p)ps.push([n,p]);
  }
  ps.sort((x,y)=>y[1].z-x[1].z);
  for(const [n,p] of ps){
    const r=nodeR(n)*p.s*(o.boost||1);
    const c=nodeColor(n);
    ctx.globalAlpha=Math.max(0.35,Math.min(1,300/p.z));
    ctx.fillStyle=c;ctx.strokeStyle=c;ctx.lineWidth=1.4;
    ctx.beginPath();
    if(n.kind==='community'){ctx.arc(p.x,p.y,r,0,6.2832);ctx.stroke();}
    else if(n.kind==='knowledge'){
      ctx.moveTo(p.x,p.y-r);ctx.lineTo(p.x+r,p.y);ctx.lineTo(p.x,p.y+r);ctx.lineTo(p.x-r,p.y);
      ctx.closePath();ctx.fill();
    }else if(n.kind==='tool'){ctx.fillRect(p.x-r*0.8,p.y-r*0.8,r*1.6,r*1.6);}
    else {ctx.arc(p.x,p.y,r,0,6.2832);ctx.fill();}
    if(n.flash>tms){
      const k=(n.flash-tms)/1600;
      ctx.globalAlpha=k;ctx.strokeStyle=c;
      ctx.beginPath();ctx.arc(p.x,p.y,r+(1-k)*16,0,6.2832);ctx.stroke();
    }
    if(sel===n.id){
      ctx.globalAlpha=1;ctx.strokeStyle=COL.text;ctx.lineWidth=1.2;
      ctx.beginPath();ctx.arc(p.x,p.y,r+3.5,0,6.2832);ctx.stroke();
    }
    if(o.labels&&(sel===n.id||r>6.5)){
      ctx.globalAlpha=sel===n.id?1:0.75;
      ctx.fillStyle=sel===n.id?COL.text:COL.dim;
      ctx.font='10px ui-monospace,Menlo,monospace';ctx.textAlign='center';
      ctx.fillText(n.label,p.x,p.y+r+11);
    }
  }
  ctx.globalAlpha=1;
}

const CSTL={createGraph,syncGraph,stepPhysics,defaultCam,easeCam,orbitBy,zoomBy,focusCam,
  project,pick,nodeR,wikiCard,draw,COL,spherePos};
if(typeof module!=='undefined'&&module.exports)module.exports=CSTL;
if(typeof window!=='undefined')window.CSTL=CSTL;
})();
