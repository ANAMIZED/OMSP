#!/usr/bin/env python3
"""OMSP app assembler — deterministic, invariant-guarded.

Inlines styles.css, engine.js, constellation.js, ui.js into shell.html and
writes omsp.html. Build FAILS (nonzero exit) if any invariant is violated;
each invariant guards a bug class that previously shipped or nearly shipped.
"""
import hashlib, pathlib, sys

HERE = pathlib.Path(__file__).parent

def main() -> int:
    shell = (HERE / "shell.html").read_text()
    out = (shell
           .replace("/*__CSS__*/",    (HERE / "styles.css").read_text())
           .replace("/*__ENGINE__*/", (HERE / "engine.js").read_text())
           .replace("/*__CSTL__*/",   (HERE / "constellation.js").read_text())
           .replace("/*__UI__*/",     (HERE / "ui.js").read_text()))

    checks = [
        ("no placeholder left behind",
         all(ph not in out for ph in ("__CSS__", "__ENGINE__", "__CSTL__", "__UI__"))),
        ("[hidden] hard rule present (overlay bug class)",
         "[hidden]{display:none!important}" in out),
        ("sheet ships inert (inline display:none)",
         'id="sheet" hidden style="display:none"' in out),
        ("constellation overlay ships inert",
         'id="cosmoswrap" hidden style="display:none"' in out),
        ("JS toggles overlay display directly",
         "w.style.display='flex'" in out and "w.style.display='none'" in out),
        ("fully self-contained: zero external requests",
         "https://" not in out),
        ("no browser storage APIs",
         "localStorage" not in out and "sessionStorage" not in out),
        ("on-page error reporter present",
         "unhandledrejection" in out),
        ("build marker present", "build 4" in out),
    ]
    bad = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(("ok " if ok else "FAIL ") + name)
    if bad:
        return 1

    dest = HERE / "omsp.html"
    dest.write_text(out)
    digest = hashlib.sha256(out.encode()).hexdigest()
    print(f"wrote {dest.name} · {len(out.encode())} bytes · sha256 {digest}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
