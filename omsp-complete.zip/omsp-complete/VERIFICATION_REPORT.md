# OMSP Verification Report — v2

**Scope:** the complete OMSP deliverable — Python reference implementation,
self-contained browser app (build 4), and all audits/documentation.
**Date:** 2026-08-20. Supersedes v1 (which covered the Python reference only).

## 1 · Evidence matrix

Every row below was executed fresh for this report, in this order, on this
package's exact contents.

| # | Check | Command | Result |
|---|---|---|---|
| 1 | Python protocol suite | `python3 -m unittest discover -s tests` | **62/62 OK** |
| 2 | Python REQ coverage audit | `python3 audit/verify_coverage.py` | **PASS** — 44 requirements, 44 implementation tags, 44 test tags; writes `TRACEABILITY.md` |
| 3 | Python adversarial demo | `python3 demo.py` | **9/9 drills held** (`all_drills_held: true`); regenerates `demo_report.json` + `dashboard.html` |
| 4 | App engine suite | `node test_engine.js` | **77/77** — includes SHA-256 vs node:crypto vectors, every guard/error path, exact 0.1% take-rate floor, and all nine drills on a fresh seed |
| 5 | App constellation suite | `node test_constellation.js` | **46/46** — ledger→graph sync, deterministic layout, physics bounds/no-NaN, projection (focused star lands dead-center), front-most picking, wiki backlinks, knowledge pruning, draw smoke vs recording ctx |
| 6 | App UI harness | `node test_ui.js` | **48/48** — boots without DOMContentLoaded, renders all 5 tabs, 600 sim ticks with tab/actor churn, click-crawls every enabled handler as guardian/high/low tier, drives end-to-end tap flows (PoW registration, spam-gate mining, tamper→restore, faucet, identity switch, constellation open/wiki/deep-link), all nine drills held through the UI path, chain verifies at ~1,400 blocks |
| 7 | Spec ↔ app parity audit | `node audit/verify_parity.js` | **PASS** — 44/44 requirements mapped (30 full · 14 partial-by-design), 67 evidence strings found verbatim in sources/tests; writes `PARITY.md` |
| 8 | Build invariants | `python3 build.py` | **9/9** — placeholders gone; `[hidden]` hard rule; both overlays ship inert with inline `display:none`; JS display toggling; zero `https://`; no storage APIs; error reporter present; build marker |
| 9 | Reproducibility | rebuild + `sha256sum` | **byte-identical** to the shipped `omsp.html` |
| 10 | Shipped-bytes re-verification | extract the four `<script>` blocks from `omsp.html`; `node --check` each; re-run suites 4–5 against the extracted engine/constellation | **parse OK · 77/77 · 46/46** on the literal shipped bytes |

## 2 · Integrity

```
file    omsp.html (build 4)
size    113,781 bytes
sha256  1e9abd2b98deb6bc8789648195a04aad1ec871ecc9b568236de35a15924caa01
deps    none — zero external requests, no storage APIs, works offline
```

## 3 · Field-failure log (and why the tests missed them)

Three defects reached the device across builds 1–3; each is now guarded.

**Mining crash (b1→b2).** `append(...).lastChild` — `Element.append()` returns
undefined in real DOM. The harness stub returned undefined too, but no test had
tapped the mining path. *Guard:* harness drives both PoW flows end-to-end
through the real handlers.

**Total input freeze (b2→b3).** Author `display:flex` on the sheet container
overrides the `hidden` attribute; an invisible `position:fixed` overlay ate
every tap while the timer-driven sim kept the screen looking alive. Headless
handler-invocation can never observe hit-testing/stacking. *Guard:* triple
redundancy in code plus a build invariant on each layer; overlays cannot ship
non-inert.

**Silent no-op patch (b2).** A build-marker text substitution failed to match
and passed silently. *Guard:* every assembler/patch step now asserts its effect;
`build.py` exits nonzero on any missed invariant.

## 4 · Parity summary

`PARITY.md` (machine-generated) maps all 44 requirements. The 14 partials are
deliberate browser-sim simplifications, each with a note — e.g. token-overlap
search instead of embeddings (REQ-2.1), simulated signatures on x402 envelopes
(REQ-4.1), single in-memory chain instead of a hybrid runtime (REQ-6.1), a
single autonomy cap instead of the per-level gradient (REQ-11.5). Review also
confirmed two suspected divergences were not: Python `match()` already funds
escrow before marking a listing matched, and its approve-then-retry allowance
model is an equivalent (documented) design for REQ-11.5.

## 5 · Known limitations

Cryptography is simulation-grade: hashing, PoW, nonces, and chain linking are
real; keys/signatures are simulated and the ledger is in-memory, with seams for
production substitution. The app's gesture wiring and pixel output are covered
by pure-function math tests and a recording-context draw harness; actual touch
behavior is verifiable only on-device, and the app's on-page error reporter
exists to surface any residue with the exact failing line. Ambient settlements
auto-release to keep the demo economy flowing — a simulation convenience, not a
protocol rule.

## 6 · Reproduce this report

```
cd reference && python3 -m unittest discover -s tests \
  && python3 audit/verify_coverage.py && python3 demo.py
cd ../app && node test_engine.js && node test_constellation.js \
  && node test_ui.js && node audit/verify_parity.js && python3 build.py
sha256sum omsp.html ../omsp.html   # identical digests
```

**Verdict: fully updated, audited, tested, and verified.** 233 automated test assertions
across four suites, plus three machine audits and nine adversarial drills, all green; one honest boundary (the finger)
instrumented rather than claimed.
