"""Discovery: semantic search, structured filters, agent cards, resolution."""
import unittest

from tests.helpers import boost_rep, make_agent, make_platform


class TestDiscovery(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.translator = make_agent(
            self.p, "polyglot", capabilities=["translation", "french", "german"],
            services=[{"name": "translate-doc", "price": 4.0, "unit": "doc"}])
        self.coder = make_agent(
            self.p, "forge", capabilities=["code generation", "python"],
            services=[{"name": "build-script", "price": 12.0, "unit": "job"}])
        self.analyst = make_agent(
            self.p, "lens", capabilities=["data analysis", "charts"],
            jurisdiction="EU", vertical="finance")

    def test_semantic_search_matches_capabilities(self):
        """[REQ-2.1] Embedding similarity surfaces the right agent."""
        res = self.p.directory.search("french translation")
        self.assertEqual(res[0]["name"], "polyglot")
        res = self.p.directory.search("python code generation")
        self.assertEqual(res[0]["name"], "forge")

    def test_structured_filters(self):
        """[REQ-2.2] Filters on reputation, price, latency, success rate,
        jurisdiction, vertical."""
        boost_rep(self.p, self.coder.token_id, n=30)
        res = self.p.directory.search("anything useful", min_rep=60)
        self.assertEqual([r["name"] for r in res], ["forge"])
        us_only = make_agent(self.p, "stateside",
                             capabilities=["data analysis"],
                             jurisdiction="US")
        res = self.p.directory.search("data analysis", jurisdiction="EU")
        names = [r["name"] for r in res]
        self.assertIn("lens", names)          # declared EU
        self.assertNotIn("stateside", names)  # US-only excluded
        res = self.p.directory.search("analysis", vertical="finance")
        self.assertEqual([r["name"] for r in res], ["lens"])
        # price filter uses live avg price stats
        self.p.stats.record_settlement(self.translator.token_id, 4.0, price=4.0)
        self.p.stats.record_settlement(self.coder.token_id, 12.0, price=12.0)
        res = self.p.directory.search("service", max_price=5.0)
        names = [r["name"] for r in res]
        self.assertIn("polyglot", names)
        self.assertNotIn("forge", names)
        # latency + success-rate filters
        self.p.stats.record_latency(self.coder.token_id, 120.0)
        res = self.p.directory.search("service", max_latency=60.0)
        self.assertNotIn("forge", [r["name"] for r in res])
        self.p.stats.record_outcome(self.translator.token_id, success=False)
        res = self.p.directory.search("service", min_success=0.9)
        self.assertNotIn("polyglot", [r["name"] for r in res])

    def test_agent_card_is_living_resume(self):
        """[REQ-8.1] Card carries services, pricing, history, live stats,
        affiliations."""
        self.translator.affiliations = ["babel-guild"]
        self.p.stats.record_settlement(self.translator.token_id, 4.0, price=4.0)
        self.p.stats.record_outcome(self.translator.token_id, success=True)
        card = self.p.directory.agent_card(self.translator.token_id)
        self.assertEqual(card["services"][0]["name"], "translate-doc")
        self.assertEqual(card["avg_price"], 4.0)
        self.assertEqual(card["price_history"], [4.0])
        self.assertEqual(card["jobs_completed"], 1)
        self.assertEqual(card["affiliations"], ["babel-guild"])
        self.assertIn("reputation", card)

    def test_aid_style_resolution(self):
        """[REQ-2.3] agent://name resolves to endpoints + wallet."""
        rec = self.p.directory.resolve("agent://polyglot")
        self.assertEqual(rec["token_id"], self.translator.token_id)
        self.assertTrue(rec["endpoints"]["a2a"].startswith("a2a://"))
        with self.assertRaises(KeyError):
            self.p.directory.resolve("agent://ghost")

    def test_ranking_prefers_reputation_visibility(self):
        """[REQ-8.3] Higher-rep agents rank above equal-similarity peers."""
        twin_a = make_agent(self.p, "twin-a", capabilities=["ocr scanning"])
        twin_b = make_agent(self.p, "twin-b", capabilities=["ocr scanning"])
        boost_rep(self.p, twin_b.token_id, n=30)
        res = self.p.directory.search("ocr scanning")
        names = [r["name"] for r in res]
        self.assertLess(names.index("twin-b"), names.index("twin-a"))


if __name__ == "__main__":
    unittest.main()
