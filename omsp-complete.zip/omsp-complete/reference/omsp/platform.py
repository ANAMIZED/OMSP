"""OMSPPlatform: composition root wiring every subsystem together.

- Event-driven runtime: bus + hash-chained ledger. [REQ-6.1]
- api(): JSON-serializable API surface (API-first) used by independent
  clients. [REQ-6.2][REQ-11.3]
- hello(): protocol version negotiation. [REQ-11.4]
- tick(): clock advance -> subscriptions charged, swarm TTLs enforced.
"""
from __future__ import annotations

import json

from . import comms, core, discovery, economy, identity, metrics, reputation, \
    safety, social, swarm
from .config import PROTOCOL_VERSIONS, Config


class OMSPPlatform:
    def __init__(self, config: Config | None = None):
        self.config = config or Config()
        self.clock = core.SimClock()
        self.ledger = core.Ledger(self.clock)                 # [REQ-6.1][REQ-6.4]
        self.bus = core.EventBus()                            # [REQ-6.1]

        self.guardian_kp = core.KeyPair.generate()
        self.guardian_address = self.guardian_kp.address

        self.tokens = economy.TokenLedger(self)
        self.stats = metrics.Stats(self)
        self.identity = identity.IdentityRegistry(self)
        self.reputation = reputation.ReputationRegistry(self)
        self.validation = reputation.ValidationRegistry(self)
        self.safety = safety.Safety(self)
        self.rate = identity.RateLimiter(self)
        self.economy = economy.Economy(self)
        self.directory = discovery.Directory(self)
        self.a2a = comms.A2AHub(self)
        self.threads = comms.ThreadStore(self)
        self.tools = comms.ToolRegistry(self)
        self.social = social.Social(self)
        self.swarms = swarm.SwarmManager(self)

        # Auto reputation on settlement [REQ-4.3]; referral rewards [REQ-9.2].
        self.bus.subscribe("settlement.completed", lambda e: self.reputation
                           .auto_settlement(e["task"], e["buyer"], e["seller"], True))
        self.bus.subscribe("settlement.failed", lambda e: self.reputation
                           .auto_settlement(e["task"], e["buyer"], e["seller"], False))
        self.bus.subscribe("agent.registered", self.economy.on_agent_registered)

    # ------------------------------------------------------------- helpers --
    def config_versions(self) -> list[str]:
        return list(PROTOCOL_VERSIONS)

    def faucet(self, account, amount: float, asset: str = "USDC") -> None:
        """Test/demo mint (stands in for on-ramp)."""
        self.tokens.mint(account, amount, asset)

    def invite(self, owner_address: str) -> None:
        """Verified-owner invite during bootstrap. [REQ-9.1]"""
        self.identity.invites.add(owner_address)

    def tick(self, dt: float = 0.0) -> None:
        if dt:
            self.clock.advance(dt)
        self.economy.tick()
        self.swarms.tick()

    # ------------------------------------------------------------ API-first --
    def hello(self, client_versions: list[str]) -> dict:
        """Version negotiation handshake. [REQ-11.4]"""
        return {"protocol": "omsp",
                "version": comms.negotiate_version(client_versions),
                "supported": PROTOCOL_VERSIONS}

    API_METHODS = ("hello", "search", "card", "resolve", "feed", "metrics",
                   "observe")

    def api(self, method: str, params: dict) -> dict:
        """JSON-in / JSON-out dispatcher: every value crossing this boundary is
        serialized, proving the surface is wire-safe. [REQ-6.2][REQ-11.3]"""
        params = json.loads(json.dumps(params))     # force wire round-trip
        if method not in self.API_METHODS:
            raise KeyError(f"unknown API method {method}")
        if method == "hello":
            result = self.hello(params["versions"])
        elif method == "search":
            result = {"results": self.directory.search(
                params["query"], requester=params.get("requester"),
                min_rep=params.get("min_rep", 0.0),
                max_price=params.get("max_price"),
                max_latency=params.get("max_latency"),
                min_success=params.get("min_success", 0.0),
                jurisdiction=params.get("jurisdiction"),
                vertical=params.get("vertical"),
                limit=params.get("limit", 10))}
        elif method == "card":
            result = self.directory.agent_card(params["token_id"])
        elif method == "resolve":
            result = self.directory.resolve(params["handle"])
        elif method == "feed":
            posts = self.social.feed(params["viewer"],
                                     params.get("community"),
                                     params.get("limit", 20))
            result = {"posts": [{k: v for k, v in p.items()} for p in posts]}
        elif method == "metrics":
            result = self.stats.report()
        elif method == "observe":
            result = {"events": self.safety.observation_stream(
                params.get("limit", 50))}
        return json.loads(json.dumps(result, default=list))  # wire-safe out
