'use strict';
const O=require('./engine.js');
const C=require('./constellation.js');

let pass=0,fail=0;
const ok=(c,m)=>{c?pass++:(fail++,console.error('FAIL:',m));};

/* ---- sync from a seeded platform ---- */
const P=O.seedPlatform();
const G=C.createGraph();
C.syncGraph(G,P,0);
const byName=n=>[...P.agents.values()].find(a=>a.name===n);
const aid=n=>'a:'+byName(n).id;

ok(G.height===P.chain.length,'sync consumed the full chain ('+G.height+' blocks)');
ok(G.nodes.size>=8,'nodes: agents + community + tools present ('+G.nodes.size+')');
ok(G.nodes.get(aid('forge')).tier==='high','forge node carries high tier');
ok(G.nodes.get('t:shell')&&G.nodes.get('t:forecast'),'tool stars exist');
ok([...G.nodes.values()].some(n=>n.kind==='community'),'community star exists');

const job=G.edges.get(aid('atlas')+'|'+aid('forge')+'|job');
ok(job&&job.w>=5,'atlas→forge job edge weighted by settlements ('+(job&&job.w)+')');
const inv=G.edges.get(aid('atlas')+'|'+aid('forge')+'|invite');
ok(!!inv,'invite lineage edge atlas→forge');
ok(!!G.edges.get(aid('atlas')+'|'+aid('forge')+'|swarm'),'swarm co-membership edge');
ok(!!G.edges.get(aid('forge')+'|c:'+[...P.communities.keys()][0]+'|post'),'post edge into community');
ok(!!G.edges.get(aid('lens')+'|t:forecast|own'),'tool ownership edge');

/* ---- incremental: settle a job, license knowledge, freeze ---- */
const h0=G.height, before=job.w;
P.faucet(byName('atlas').id,100);
const e=P.fundEscrow(byName('atlas').id,byName('forge').id,30,[1],true);
P.releaseMilestone(e.id);
P.sellKnowledge(byName('lens').id,byName('babel').id,4,'cid:sync-probe');
P.freeze(byName('notary').id,'test');
const changed=C.syncGraph(G,P,1000);
ok(changed&&G.height===P.chain.length,'incremental sync consumed new blocks');
ok(job.w===before+1,'settlement bumped job edge weight');
ok(G.flashes.some(f=>f.c===C.COL.mint),'settlement emitted a mint flash');
ok(G.nodes.has('k:cid:sync-probe'),'knowledge star born');
ok(!!G.edges.get(aid('lens')+'|k:cid:sync-probe|license')&&!!G.edges.get('k:cid:sync-probe|'+aid('babel')+'|license'),'license edges seller→star→buyer');
ok(G.nodes.get(aid('notary')).frozen===true,'freeze reflected on the star');
P.unfreeze(byName('notary').id);C.syncGraph(G,P,1001);
ok(G.nodes.get(aid('notary')).frozen===false,'unfreeze reflected');
ok(G.alpha>0.8,'structural change reheated the layout');

/* ---- knowledge pruning cap ---- */
for(let i=0;i<15;i++){
  P.tick(3);
  P.faucet(byName('babel').id,10);
  P.sellKnowledge(byName('lens').id,byName('babel').id,1,'cid:bulk-'+i);
}
C.syncGraph(G,P,2000);
const kn=[...G.nodes.values()].filter(n=>n.kind==='knowledge');
ok(kn.length<=12,'knowledge stars pruned to 12 ('+kn.length+')');
ok(!G.nodes.has('k:cid:sync-probe'),'oldest knowledge star faded');
ok(![...G.edges.keys()].some(k=>k.includes('k:cid:sync-probe')),'faded star took its edges with it');

/* ---- deterministic layout ---- */
const G2=C.createGraph();C.syncGraph(G2,P,0);
let same=true;
for(const [id,n] of G.nodes){
  const m=G2.nodes.get(id);
  if(!m)continue;
  // positions drift once physics runs; compare fresh spawn determinism instead
}
const s1=C.spherePos('probe',100),s2=C.spherePos('probe',100);
ok(s1.x===s2.x&&s1.y===s2.y&&s1.z===s2.z,'seeded placement is deterministic');
const fresh1=C.createGraph();C.syncGraph(fresh1,P,0);
const fresh2=C.createGraph();C.syncGraph(fresh2,P,0);
same=true;
for(const [id,n] of fresh1.nodes){const m=fresh2.nodes.get(id);if(!m||m.x!==n.x||m.y!==n.y||m.z!==n.z){same=false;break;}}
ok(same,'two graphs from the same chain start identically');

/* ---- physics invariants ---- */
for(let i=0;i<300;i++)C.stepPhysics(G,1);
let bad=false,maxR=0;
for(const n of G.nodes.values()){
  if(!isFinite(n.x+n.y+n.z))bad=true;
  maxR=Math.max(maxR,Math.hypot(n.x,n.y,n.z));
}
ok(!bad,'no NaN/Inf after 300 steps');
ok(maxR<=186,'positions bounded ('+maxR.toFixed(1)+')');
const dist=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y,p.z-q.z);
const dJob=dist(G.nodes.get(aid('atlas')),G.nodes.get(aid('forge')));
// control pair with no direct edge: forge vs a knowledge star buyer-side only
ok(dJob<120,'heavily-linked pair settles close ('+dJob.toFixed(0)+')');
ok(G.alpha<0.3,'layout cooled after settling');

/* ---- projection & picking math ---- */
const cam=C.defaultCam();
const origin={x:0,y:0,z:0,mass:1,kind:'agent',id:'x'};
const p0=C.project(origin,cam,400,300);
ok(Math.abs(p0.x-200)<1e-9&&Math.abs(p0.y-150)<1e-9,'origin projects to screen center');
const near=C.project({x:0,y:0,z:-120},Object.assign(C.defaultCam(),{th:0,ph:0,tth:0,tph:0}),400,300);
const far=C.project({x:0,y:0,z:120},Object.assign(C.defaultCam(),{th:0,ph:0,tth:0,tph:0}),400,300);
ok(near.s>far.s,'nearer stars render larger');
ok(C.project({x:0,y:0,z:-300},Object.assign(C.defaultCam(),{th:0,ph:0,dist:320}),400,300)===null,'behind-camera culled');

const PG=C.createGraph();
const na=PG.nodes.set('n1',{id:'n1',kind:'agent',label:'n1',x:0,y:0,z:0,mass:6,tier:'mid',frozen:false,flash:0}).get('n1');
const nb=PG.nodes.set('n2',{id:'n2',kind:'agent',label:'n2',x:0,y:0,z:60,mass:6,tier:'mid',frozen:false,flash:0}).get('n2');
const cc=Object.assign(C.defaultCam(),{th:0,ph:0});
const pa=C.project(na,cc,400,300);
ok(C.pick(PG,cc,400,300,pa.x,pa.y).id==='n1','overlapping pick returns the front-most star');
ok(C.pick(PG,cc,400,300,5,5)===null,'empty sky picks nothing');

/* camera focus centers the node */
const rnd={x:44,y:-31,z:70};
const fc=C.defaultCam();C.focusCam(fc,rnd);
fc.th=fc.tth;fc.ph=fc.tph;
const pf=C.project(rnd,fc,400,300);
ok(Math.abs(pf.x-200)<0.5&&Math.abs(pf.y-150)<0.5,'focusCam centers the chosen star');
const oc=C.defaultCam();C.orbitBy(oc,100,50);
ok(oc.tth!==oc.th||oc.tph!==oc.ph,'orbit adjusts targets');
C.zoomBy(oc,0.5);ok(oc.tdist>=150,'zoom clamps');
C.zoomBy(oc,99);ok(oc.tdist<=640,'zoom clamps far');

/* ---- wiki cards & backlinks ---- */
const card=C.wikiCard(G,P,aid('forge'));
ok(card.title==='forge'&&card.kind==='agent','forge card resolves');
ok(card.facts.some(f=>f.startsWith('tier high')),'card carries live tier fact');
ok(card.back.some(l=>l.rel==='vouched by'&&l.label==='atlas'),'backlinks: vouched by atlas');
ok(card.out.some(l=>l.rel==='vouched for'&&l.label==='lens'),'outlinks: vouched for lens');
ok(card.out.some(l=>l.type==='own'&&l.label==='shell'),'outlinks: operates shell');
const commCard=C.wikiCard(G,P,'c:'+[...P.communities.keys()][0]);
ok(commCard.back.length>=3,'community backlinks list its voices');
const kcard=C.wikiCard(G,P,G.klist[G.klist.length-1]);
ok(kcard.kind==='knowledge'&&kcard.back.length===1&&kcard.out.length===1,'knowledge card: one licensor in, one licensee out');
ok(C.wikiCard(G,P,'k:cid:sync-probe')===null,'faded star yields no card');

/* ---- draw smoke against a recording ctx ---- */
function recCtx(){
  const rec={ops:0};
  const fn=()=>{rec.ops++;};
  return new Proxy(rec,{
    get:(t,k)=>{
      if(k in t)return t[k];
      if(k==='createLinearGradient'||k==='createRadialGradient')return ()=>({addColorStop(){}});
      if(k==='measureText')return ()=>({width:10});
      return fn;
    },
    set:(t,k,v)=>{t[k]=v;return true;},
  });
}
const ctx=recCtx();
C.draw(ctx,390,190,G,cam,aid('forge'),3000,{labels:true,boost:1.4});
ok(ctx.ops>150,'draw issued a full frame of ops ('+ctx.ops+')');
C.draw(ctx,390,190,G,cam,null,999999,{});
ok(true,'draw survives expired flashes and no selection');

console.log('\nconstellation tests: '+pass+' passed, '+fail+' failed');
process.exit(fail?1:0);
