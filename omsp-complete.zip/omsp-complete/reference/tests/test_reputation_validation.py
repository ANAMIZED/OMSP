"""Reputation + validation registries."""
import unittest

from omsp.config import AuthorizationError
from tests.helpers import boost_rep, make_agent, make_platform


class TestReputation(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.a = make_agent(self.p, "buyer")
        self.b = make_agent(self.p, "seller")

    def _settle(self, task="t1"):
        self.p.reputation.auto_settlement(task, self.a.token_id,
                                          self.b.token_id, success=True)

    def test_feedback_requires_settlement_authorization(self):
        """[REQ-1.2] Feedback only after a completed settlement for the pair."""
        with self.assertRaises(AuthorizationError):
            self.p.reputation.give_feedback(self.a.token_id, self.b.token_id,
                                            "never-happened", 90)
        self._settle()
        entry = self.p.reputation.give_feedback(self.a.token_id,
                                                self.b.token_id, "t1", 90)
        self.assertEqual(entry["score"], 90)

    def test_feedback_is_bidirectional_and_once_per_direction(self):
        """[REQ-1.2] Both parties may rate each other once per task."""
        self._settle()
        self.p.reputation.give_feedback(self.a.token_id, self.b.token_id, "t1", 95)
        self.p.reputation.give_feedback(self.b.token_id, self.a.token_id, "t1", 80)
        with self.assertRaises(AuthorizationError):
            self.p.reputation.give_feedback(self.a.token_id, self.b.token_id,
                                            "t1", 10)

    def test_auto_settlement_bumps_reputation(self):
        """[REQ-4.3] Successful settlement raises the seller's score
        automatically; failed settlement lowers it."""
        base = self.p.reputation.score(self.b.token_id)
        self._settle()
        up = self.p.reputation.score(self.b.token_id)
        self.assertGreater(up, base)
        self.p.reputation.auto_settlement("t2", self.a.token_id,
                                          self.b.token_id, success=False)
        self.assertLess(self.p.reputation.score(self.b.token_id), up)

    def test_scores_decay_over_time(self):
        """[REQ-1.2] Old feedback decays (half-life)."""
        self._settle()
        self.p.reputation.give_feedback(self.a.token_id, self.b.token_id, "t1", 100)
        fresh = self.p.reputation.score(self.b.token_id)
        self.p.clock.advance(self.p.config.rep_half_life * 3)
        aged = self.p.reputation.score(self.b.token_id)
        self.assertLess(aged, fresh)
        self.assertGreater(aged, self.p.config.rep_base - 0.01)

    def test_reputation_as_capital_gates(self):
        """[REQ-8.3] Tiers gate visibility, rate multiplier and max job value."""
        low = self.p.reputation.gates(self.a.token_id)
        boost_rep(self.p, self.b.token_id, n=30)
        high = self.p.reputation.gates(self.b.token_id)
        self.assertLess(low["visibility"], high["visibility"])
        self.assertLess(low["rate_mult"], high["rate_mult"])
        self.assertLess(low["max_job_value"], high["max_job_value"])
        self.assertEqual(high["max_job_value"], 5000.0)


class TestValidation(unittest.TestCase):
    def test_stake_backed_attestation_and_slashing(self):
        """[REQ-1.3] Validators stake; confirmed fraud slashes stake + rep."""
        p = make_platform()
        worker = make_agent(p, "prover")
        validator = make_agent(p, "notary", om=50.0)
        rec = p.validation.request("job-9", worker.token_id,
                                   validator.token_id, stake=20.0)
        self.assertEqual(p.economy.stakes[validator.token_id], 20.0)
        before = p.reputation.score(worker.token_id)
        p.validation.respond("job-9", validator.token_id, valid=True,
                             proof_hash="0xproof")
        self.assertGreater(p.reputation.score(worker.token_id), before)

        rep_before = p.reputation.score(validator.token_id)
        out = p.validation.challenge("job-9", worker.token_id,
                                     counter_proof="0xcounter",
                                     fraud_confirmed=True)
        self.assertEqual(out["slashed"], 20.0)
        self.assertEqual(p.economy.stakes[validator.token_id], 0.0)
        self.assertLess(p.reputation.score(validator.token_id), rep_before)
        self.assertEqual(p.tokens.balance("TREASURY", "OM"), 20.0)


if __name__ == "__main__":
    unittest.main()
